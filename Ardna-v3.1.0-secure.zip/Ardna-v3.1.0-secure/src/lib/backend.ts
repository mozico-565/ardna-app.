import {friendlyError} from './ux';
import { createClient } from '@supabase/supabase-js';
import { Capacitor } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const configured = Boolean(url && key);
const storage = {
 async getItem(key: string) { return (await Preferences.get({ key })).value; },
 async setItem(key: string, value: string) { await Preferences.set({ key, value }); },
 async removeItem(key: string) { await Preferences.remove({ key }); },
};
export const supabase = configured ? createClient(url, key, { auth: {
 flowType: 'pkce', persistSession: true, autoRefreshToken: true,
 detectSessionInUrl: !Capacitor.isNativePlatform(), storage,
} }) : null;
export function db() { if (!supabase) throw new Error('الخدمة غير متاحة مؤقتًا.'); return supabase; }
export type Row = { id: string; [key: string]: any };
export function check<R extends {data?:unknown;error:{message:string}|null}>(result:R): R extends {data:infer D} ? NonNullable<D> : void {
 if (result.error) throw new Error(friendlyError(result.error));
 return result.data as R extends {data:infer D} ? NonNullable<D> : void;
}
export async function rpc(name: string, args: Record<string, unknown>) { return check(await db().rpc(name, args)); }
export const publicBase = import.meta.env.VITE_PUBLIC_APP_URL || (!Capacitor.isNativePlatform() ? location.origin + location.pathname : '');
export const authRedirect = () => Capacitor.isNativePlatform() ? 'com.ardna.app://auth/callback' : location.origin + location.pathname;
export function link(path: string) { if (!publicBase) throw new Error('رابط المشاركة غير متاح.'); return publicBase + '#/' + path; }
export async function share(path: string, title: string) {
 const url = link(path);
 if (navigator.share) { await navigator.share({ title, url }); return; }
 await navigator.clipboard.writeText(url);
}
export const paymentProvider = { enabled: false, async checkout(): Promise<never> { throw new Error('الدفع الإلكتروني غير متاح. استخدم طلب شراء.'); } };
