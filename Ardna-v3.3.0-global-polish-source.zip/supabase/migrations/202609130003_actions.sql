create function public.choose_role(chosen text, details jsonb default '{}') returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.active(auth.uid()) then raise exception 'الحساب غير متاح'; end if;
 if chosen not in ('customer','engineer') then raise exception 'نوع الحساب غير مسموح'; end if;
 if chosen='engineer' then
 if length(trim(coalesce(details->>'professional_name','')))<2 or length(trim(coalesce(details->>'specialization','')))<2 then raise exception 'أكمل الاسم والتخصص'; end if;
 insert into public.engineer_profiles(user_id,professional_name,specialization,city,country,years_experience,bio,professional_license,starting_price)
 values(auth.uid(),details->>'professional_name',details->>'specialization',details->>'city',details->>'country',coalesce((details->>'years_experience')::int,0),details->>'bio',details->>'professional_license',coalesce((details->>'starting_price')::numeric,0)) on conflict(user_id) do nothing;
 end if;
 insert into public.user_roles(user_id,role) values(auth.uid(),chosen) on conflict do nothing;
end $$;

create function public.start_conversation(recipient uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare cid uuid; pair text;
begin
 if not private.active(auth.uid()) or not private.active(recipient) or recipient=auth.uid() then raise exception 'تعذر بدء المحادثة'; end if;
 pair:=least(auth.uid()::text,recipient::text)||':'||greatest(auth.uid()::text,recipient::text);
 insert into public.conversations(pair_key) values(pair) on conflict(pair_key) do update set pair_key=excluded.pair_key returning id into cid;
 insert into public.conversation_members(conversation_id,user_id) values(cid,auth.uid()),(cid,recipient) on conflict do nothing;
 return cid;
end $$;
create function public.mark_messages_read(thread uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.member(thread) then raise exception 'غير مسموح'; end if;
 update public.messages set read_at=now() where conversation_id=thread and sender_id<>auth.uid() and read_at is null;
end $$;
create function public.order_design(license uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare lic public.design_licenses; d public.engineering_designs; oid uuid;
begin
 if not private.active(auth.uid()) then raise exception 'سجّل الدخول'; end if;
 select * into lic from public.design_licenses where id=license;
 select * into d from public.engineering_designs where id=lic.design_id;
 if d.id is null or d.status<>'approved' or d.engineer_id=auth.uid() or not private.active(d.engineer_id) or lic.type='preview' then raise exception 'التصميم غير متاح للطلب'; end if;
 insert into public.design_orders(customer_id,engineer_id,design_id,license_id,agreed_price,license_snapshot)
 values(auth.uid(),d.engineer_id,d.id,lic.id,lic.price,jsonb_build_object('type',lic.type,'description',lic.description,'allowed_usage',lic.allowed_usage,'currency',d.currency)) returning id into oid;
 return oid;
end $$;

create function public.listing_action(kind text, target uuid, action text) returns void language plpgsql security definer set search_path='' as $$
declare t text; owner_col text; row_owner uuid; old_status text; next_status text;
begin
 if not private.active(auth.uid()) then raise exception 'غير مسموح'; end if;
 if kind not in ('property','design') then raise exception 'نوع غير صالح'; end if;
 t:=case when kind='property' then 'properties' else 'engineering_designs' end;
 owner_col:=case when kind='property' then 'owner_id' else 'engineer_id' end;
 execute format('select %I,status from public.%I where id=$1 for update',owner_col,t) into row_owner,old_status using target;
 if row_owner is distinct from auth.uid() then raise exception 'غير مسموح'; end if;
 next_status:=case action when 'submit' then 'pending' when 'edit' then 'draft' when 'archive' then 'archived' when 'sold' then 'sold' when 'rented' then 'rented' end;
 if next_status is null or (action='submit' and old_status not in ('draft','rejected')) or (action in ('sold','rented') and (kind<>'property' or old_status<>'approved')) then raise exception 'انتقال غير مسموح'; end if;
 if action='submit' then
 if kind='property' and not exists(select 1 from public.property_images where property_id=target) then raise exception 'أضف صورة واحدة على الأقل'; end if;
 if kind='design' and (not exists(select 1 from public.design_images where design_id=target) or not exists(select 1 from public.design_licenses where design_id=target)) then raise exception 'أضف معاينة وترخيصًا'; end if;
 end if;
 execute format('update public.%I set status=$1,featured=false where id=$2',t) using next_status,target;
end $$;

create function public.request_action(kind text, target uuid, next_status text) returns void language plpgsql security definer set search_path='' as $$
declare t text; customer uuid; engineer uuid; old_status text; allowed boolean:=false;
begin
 if not private.active(auth.uid()) then raise exception 'غير مسموح'; end if;
 t:=case kind when 'order' then 'design_orders' when 'custom' then 'custom_design_requests' when 'modification' then 'design_modification_requests' end;
 if t is null then raise exception 'نوع غير صالح'; end if;
 execute format('select customer_id,engineer_id,status from public.%I where id=$1 for update',t) into customer,engineer,old_status using target;
 if auth.uid()=customer then
 allowed:=(next_status='cancelled' and old_status in ('requested','submitted','accepted','awaiting_payment','in_discussion')) or (next_status='completed' and old_status='delivered') or (kind='order' and next_status='disputed' and old_status in ('paid','in_progress','delivered','completed'));
 elsif auth.uid()=engineer then
 allowed:=(next_status='accepted' and old_status in ('requested','submitted')) or
 (next_status='rejected' and kind<>'order' and old_status='submitted') or
 (next_status='awaiting_payment' and kind='order' and old_status='accepted') or
 (next_status='in_discussion' and kind='custom' and old_status in ('submitted','accepted')) or
 (next_status='in_progress' and old_status in ('accepted','paid','in_discussion')) or
 (next_status='delivered' and old_status='in_progress');
 end if;
 -- No client, including an administrator, may fabricate a paid event.
 if not allowed then raise exception 'انتقال غير مسموح'; end if;
 execute format('update public.%I set status=$1 where id=$2',t) using next_status,target;
end $$;

create function public.admin_action(kind text,target uuid,action text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.admin() then raise exception 'للإدارة فقط'; end if;
 if kind='property' and action in ('approved','rejected','archived') then update public.properties set status=action where id=target;
 elsif kind='design' and action in ('approved','rejected','archived') then update public.engineering_designs set status=action where id=target;
 elsif kind='property' and action in ('feature','unfeature') then update public.properties set featured=(action='feature') where id=target and status='approved';
 elsif kind='design' and action in ('feature','unfeature') then update public.engineering_designs set featured=(action='feature') where id=target and status='approved';
 elsif kind='engineer' and action in ('verified','rejected') then update public.engineer_profiles set verification_status=action where user_id=target;
 elsif kind='user' and action in ('suspend','unsuspend') and target<>auth.uid() then update public.profiles set suspended=(action='suspend') where id=target;
 elsif kind='report' and action in ('reviewed','resolved') then update public.reports set status=action where id=target;
 elsif kind='service' and action in ('in_progress','completed','cancelled') then update public.service_requests set status=action where id=target;
 else raise exception 'عملية غير مسموحة'; end if;
 insert into public.audit_logs(actor_id,action,entity_id,entity_type) values(auth.uid(),action,target,kind);
end $$;

create function public.record_view(kind text,target uuid) returns bigint language plpgsql security definer set search_path='' as $$
declare n bigint;
begin
 if not private.active(auth.uid()) then return 0; end if;
 if kind='property' then
 if not exists(select 1 from public.properties where id=target and (status='approved' or owner_id=auth.uid())) then raise exception 'غير متاح'; end if;
 insert into public.property_views(property_id,viewer_id) values(target,auth.uid()) on conflict do nothing;
 select count(*) into n from public.property_views where property_id=target;
 elsif kind='design' then
 if not exists(select 1 from public.engineering_designs where id=target and (status='approved' or engineer_id=auth.uid())) then raise exception 'غير متاح'; end if;
 insert into public.design_views(design_id,viewer_id) values(target,auth.uid()) on conflict do nothing;
 select count(*) into n from public.design_views where design_id=target;
 end if; return n;
end $$;

create function private.engineer_recheck() returns trigger language plpgsql set search_path='' as $$
begin
 if (new.professional_name,new.specialization,new.professional_license) is distinct from (old.professional_name,old.specialization,old.professional_license) then new.verification_status='pending'; end if;
 return new;
end $$;
create trigger engineer_recheck before update on engineer_profiles for each row execute function private.engineer_recheck();

create function private.events() returns trigger language plpgsql security definer set search_path='' as $$
declare recipient uuid; eid uuid; s text; prev text; label text;
begin
 eid:=coalesce((to_jsonb(new)->>'id')::uuid,(to_jsonb(new)->>'user_id')::uuid);
 s:=coalesce(to_jsonb(new)->>'status',to_jsonb(new)->>'verification_status');
 if tg_op='UPDATE' then
 prev:=coalesce(to_jsonb(old)->>'status',to_jsonb(old)->>'verification_status');
 if s is not distinct from prev then return new; end if;
 end if;
 label:=case tg_table_name when 'properties' then 'تحديث حالة العقار' when 'engineering_designs' then 'تحديث حالة التصميم' when 'engineer_profiles' then 'تحديث التحقق المهني' when 'messages' then 'رسالة جديدة' when 'reviews' then 'تقييم جديد' when 'design_files' then 'رفع ملف تصميم' else 'تحديث طلب' end;
 if tg_table_name='messages' then
 insert into public.notifications(user_id,title,body,type,related_id) select user_id,label,'لديك رسالة جديدة','conversation',new.conversation_id from public.conversation_members where conversation_id=new.conversation_id and user_id<>new.sender_id;
 return new;
 end if;
 if tg_table_name in ('properties','engineering_designs','engineer_profiles') and tg_op='INSERT' then return new; end if;
 if tg_table_name in ('design_orders','custom_design_requests','design_modification_requests') then
 insert into public.notifications(user_id,title,body,type,related_id) values(new.engineer_id,label,'افتح الطلب للاطلاع على التفاصيل','requests',eid),(new.customer_id,label,'افتح الطلب للاطلاع على التفاصيل','requests',eid);
 else
 recipient:=coalesce((to_jsonb(new)->>'owner_id')::uuid,(to_jsonb(new)->>'engineer_id')::uuid,(to_jsonb(new)->>'user_id')::uuid);
 if recipient is not null then insert into public.notifications(user_id,title,body,type,related_id) values(recipient,label,'افتح أرضنا للاطلاع على التفاصيل',tg_table_name,eid); end if;
 end if;
 insert into public.audit_logs(actor_id,action,entity_type,entity_id,old_status,new_status) values(auth.uid(),tg_op,tg_table_name,eid,prev,s);
 return new;
end $$;
do $$ declare t text; begin
 foreach t in array array['properties','engineering_designs','engineer_profiles','design_orders','custom_design_requests','design_modification_requests','messages','reviews','design_files','service_requests'] loop
 execute format('create trigger events after insert or update on public.%I for each row execute function private.events()',t);
 end loop;
end $$;
-- Explicit RPC allowlist: future functions do not accidentally become public.
revoke execute on all functions in schema private from public;
grant execute on function private.active(uuid),private.admin(),private.member(uuid),private.is_engineer(),private.owns_listing(text,uuid),private.can_upload(text,text) to authenticated,anon;
revoke execute on function public.choose_role(text,jsonb),public.start_conversation(uuid),public.mark_messages_read(uuid),public.order_design(uuid),public.listing_action(text,uuid,text),public.request_action(text,uuid,text),public.admin_action(text,uuid,text),public.record_view(text,uuid) from public;
grant execute on function public.choose_role(text,jsonb),public.start_conversation(uuid),public.mark_messages_read(uuid),public.order_design(uuid),public.listing_action(text,uuid,text),public.request_action(text,uuid,text),public.admin_action(text,uuid,text),public.record_view(text,uuid) to authenticated;
