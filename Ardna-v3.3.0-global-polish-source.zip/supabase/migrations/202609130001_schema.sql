-- Ardna V1. Apply in a dedicated Supabase project, in filename order.
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated, anon;

create table public.profiles (
 id uuid primary key references auth.users on delete cascade,
 full_name text not null default '', email text, phone text, avatar_url text,
 city text, country text default 'السودان', suspended boolean not null default false,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.user_roles (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade,
 role text not null check(role in ('customer','engineer','service_provider','admin')),
 created_at timestamptz not null default now(), unique(user_id,role)
);
create table public.engineer_profiles (
 user_id uuid primary key references profiles on delete cascade,
 professional_name text not null, specialization text not null, bio text, city text, country text,
 avatar_url text, professional_license text, years_experience integer not null default 0 check(years_experience between 0 and 80),
 verification_status text not null default 'pending' check(verification_status in ('unverified','pending','verified','rejected')),
 starting_price numeric not null default 0 check(starting_price >= 0), is_available boolean not null default true,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.properties (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references profiles,
 title text not null check(length(title) between 3 and 160), description text not null default '',
 category text not null check(category in ('land','house','apartment','commercial','farm')),
 listing_type text not null check(listing_type in ('sale','rent','not_listed')),
 price numeric not null default 0 check(price>=0), currency text not null default 'SDG', state text not null,
 city text not null, district text, area numeric not null check(area>0), area_unit text not null default 'm2' check(area_unit in ('m2','feddan')),
 width numeric check(width>0), length numeric check(length>0), latitude double precision check(latitude between -90 and 90),
 longitude double precision check(longitude between -180 and 180),
 status text not null default 'draft' check(status in ('draft','pending','approved','rejected','sold','rented','archived')),
 featured boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
-- Registration identifiers are private to the owner and administrators.
create table public.property_records (property_id uuid primary key references properties on delete cascade, registration_number text);
create table public.property_images (
 id uuid primary key default gen_random_uuid(), property_id uuid not null references properties on delete cascade,
 path text not null unique, thumbnail_path text not null unique, position integer not null check(position between 0 and 9),
 created_at timestamptz not null default now(), unique(property_id,position)
);
create table public.engineering_designs (
 id uuid primary key default gen_random_uuid(), engineer_id uuid not null references engineer_profiles(user_id),
 title text not null check(length(title) between 3 and 160), description text not null default '', category text not null,
 architectural_style text, floors integer not null default 1 check(floors>0), bedrooms integer default 0 check(bedrooms>=0),
 bathrooms integer default 0 check(bathrooms>=0), building_area numeric not null check(building_area>0),
 min_land_width numeric not null check(min_land_width>0), min_land_length numeric not null check(min_land_length>0),
 recommended_land_area numeric not null check(recommended_land_area>0), price numeric not null check(price>=0), currency text not null default 'SDG',
 status text not null default 'draft' check(status in ('draft','pending','approved','rejected','archived')),
 featured boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.design_images (
 id uuid primary key default gen_random_uuid(), design_id uuid not null references engineering_designs on delete cascade,
 path text not null unique, thumbnail_path text not null unique, position integer not null check(position between 0 and 9),
 created_at timestamptz not null default now(), unique(design_id,position)
);
create table public.design_files (
 id uuid primary key default gen_random_uuid(), design_id uuid not null references engineering_designs on delete cascade,
 engineer_id uuid not null references profiles, path text not null unique, original_filename text not null,
 file_size bigint not null check(file_size between 1 and 52428800), file_hash text not null check(file_hash ~ '^[a-f0-9]{64}$'),
 uploaded_at timestamptz not null default now()
);
create table public.design_licenses (
 id uuid primary key default gen_random_uuid(), design_id uuid not null references engineering_designs on delete cascade,
 type text not null check(type in ('preview','personal_use','purchase_with_modification','full_rights','commercial_use')),
 price numeric not null check(price>=0), description text not null, allowed_usage text not null, created_at timestamptz not null default now(),
 unique(design_id,type)
);
create table public.design_orders (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references profiles,
 engineer_id uuid not null references engineer_profiles(user_id), design_id uuid not null references engineering_designs,
 license_id uuid not null references design_licenses, agreed_price numeric not null, license_snapshot jsonb not null,
 status text not null default 'requested' check(status in ('requested','accepted','awaiting_payment','paid','in_progress','delivered','completed','cancelled','disputed')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create unique index one_open_order on design_orders(customer_id,design_id) where status not in ('cancelled','completed','disputed');
create table public.custom_design_requests (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references profiles,
 engineer_id uuid not null references engineer_profiles(user_id), property_id uuid references properties,
 title text not null, description text not null, land_width numeric check(land_width>0), land_length numeric check(land_length>0),
 land_area numeric check(land_area>0), floors integer check(floors>0), budget numeric check(budget>=0),
 status text not null default 'submitted' check(status in ('submitted','accepted','rejected','in_discussion','in_progress','delivered','completed','cancelled')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.design_modification_requests (
 id uuid primary key default gen_random_uuid(), order_id uuid not null references design_orders,
 customer_id uuid not null references profiles, engineer_id uuid not null references engineer_profiles(user_id), description text not null,
 status text not null default 'submitted' check(status in ('submitted','accepted','rejected','in_progress','delivered','completed','cancelled')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.favorites (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade,
 property_id uuid references properties on delete cascade, design_id uuid references engineering_designs on delete cascade,
 created_at timestamptz not null default now(), check(num_nonnulls(property_id,design_id)=1), unique(user_id,property_id), unique(user_id,design_id)
);
create table public.property_views (
 id uuid primary key default gen_random_uuid(), property_id uuid not null references properties on delete cascade,
 viewer_id uuid not null references profiles on delete cascade, created_at timestamptz not null default now(), unique(property_id,viewer_id)
);
create table public.design_views (
 id uuid primary key default gen_random_uuid(), design_id uuid not null references engineering_designs on delete cascade,
 viewer_id uuid not null references profiles on delete cascade, created_at timestamptz not null default now(), unique(design_id,viewer_id)
);
create table public.conversations (id uuid primary key default gen_random_uuid(), pair_key text not null unique, created_at timestamptz not null default now());
create table public.conversation_members (
 id uuid primary key default gen_random_uuid(), conversation_id uuid not null references conversations on delete cascade,
 user_id uuid not null references profiles, created_at timestamptz not null default now(), unique(conversation_id,user_id)
);
create table public.messages (
 id uuid primary key default gen_random_uuid(), conversation_id uuid not null references conversations on delete cascade,
 sender_id uuid not null references profiles, body text not null check(length(trim(body)) between 1 and 4000),
 created_at timestamptz not null default now(), read_at timestamptz
);
create table public.reviews (
 id uuid primary key default gen_random_uuid(), reviewer_id uuid not null references profiles, engineer_id uuid not null references engineer_profiles(user_id),
 order_id uuid not null unique references design_orders, rating integer not null check(rating between 1 and 5), comment text not null check(length(comment)<=2000), created_at timestamptz not null default now()
);
create table public.documents (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles,
 name text not null, path text not null unique, mime_type text not null check(mime_type in ('application/pdf','image/jpeg','image/png')),
 file_size bigint not null check(file_size between 1 and 10485760), created_at timestamptz not null default now()
);
create table public.service_requests (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles, title text not null, description text not null,
 status text not null default 'submitted' check(status in ('submitted','in_progress','completed','cancelled')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, title text not null,
 body text not null, type text not null, related_id uuid, read boolean not null default false, created_at timestamptz not null default now()
);
create table public.reports (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles, property_id uuid references properties,
 design_id uuid references engineering_designs, engineer_id uuid references engineer_profiles(user_id),
 reason text not null check(reason in ('incorrect_information','possible_fraud','copyright','duplicate','inappropriate','other')), description text,
 status text not null default 'open' check(status in ('open','reviewed','resolved')), created_at timestamptz not null default now(),
 check(num_nonnulls(property_id,design_id,engineer_id)=1)
);
create table public.audit_logs (
 id uuid primary key default gen_random_uuid(), actor_id uuid, action text not null, entity_id uuid, entity_type text not null,
 old_status text, new_status text, created_at timestamptz not null default now()
);
create index properties_explore on properties(status,created_at desc);
create index designs_explore on engineering_designs(status,created_at desc);
create index properties_owner on properties(owner_id);
create index designs_engineer on engineering_designs(engineer_id);
create index messages_thread on messages(conversation_id,created_at);
create index member_user on conversation_members(user_id);
create index notifications_user on notifications(user_id,created_at desc);
create index orders_customer on design_orders(customer_id);
create index orders_engineer on design_orders(engineer_id);

create function private.active(uid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=uid and not suspended)
$$;
create function private.admin() returns boolean language sql stable security definer set search_path='' as $$
 select private.active(auth.uid()) and exists(select 1 from public.user_roles where user_id=auth.uid() and role='admin')
$$;
create function private.member(cid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select private.active(auth.uid()) and exists(select 1 from public.conversation_members where conversation_id=cid and user_id=auth.uid())
$$;
create function private.is_engineer() returns boolean language sql stable security definer set search_path='' as $$
 select private.active(auth.uid()) and exists(select 1 from public.user_roles where user_id=auth.uid() and role='engineer')
$$;
create function private.new_user() returns trigger language plpgsql security definer set search_path='' as $$
 begin insert into public.profiles(id,email,full_name) values(new.id,new.email,left(coalesce(new.raw_user_meta_data->>'full_name',''),160)); return new; end
$$;
create trigger ardna_new_user after insert on auth.users for each row execute function private.new_user();
create function private.touch() returns trigger language plpgsql set search_path='' as $$ begin new.updated_at=now(); return new; end $$;
do $$ declare t text; begin
 foreach t in array array['profiles','engineer_profiles','properties','engineering_designs','design_orders','custom_design_requests','design_modification_requests','service_requests'] loop
 execute format('create trigger touch before update on public.%I for each row execute function private.touch()',t);
 end loop;
end $$;
