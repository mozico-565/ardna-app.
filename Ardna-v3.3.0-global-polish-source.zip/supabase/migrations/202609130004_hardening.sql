-- Bind preview references to the uploader and listing; a row may not point at another user's private media.
create function private.media_path_guard() returns trigger language plpgsql set search_path='' as $$
declare lid uuid; begin
 lid:=coalesce((to_jsonb(new)->>'property_id')::uuid,(to_jsonb(new)->>'design_id')::uuid);
 if new.path not like auth.uid()::text||'/'||lid::text||'/%' or new.thumbnail_path not like auth.uid()::text||'/'||lid::text||'/%' then raise exception 'مسار صورة غير مسموح'; end if;
 return new;
end $$;
create trigger media_path_guard before insert or update on property_images for each row execute function private.media_path_guard();
create trigger media_path_guard before insert or update on design_images for each row execute function private.media_path_guard();
-- Preserve immutable identity and ownership on auxiliary rows.
create function private.immutable_identity() returns trigger language plpgsql set search_path='' as $$
declare k text; begin
 foreach k in array array['id','property_id','design_id','user_id','created_at'] loop
 if to_jsonb(new)->k is distinct from to_jsonb(old)->k then raise exception 'لا يمكن تغيير هوية السجل'; end if;
 end loop; return new;
end $$;
do $$ declare t text; begin foreach t in array array['property_records','property_images','design_images','design_licenses'] loop
 execute format('create trigger immutable_identity before update on public.%I for each row execute function private.immutable_identity()',t);
end loop; end $$;
-- Serialize per-sender checks to bound message bursts under concurrent clients.
create function private.message_limit() returns trigger language plpgsql security definer set search_path='' as $$
begin
 perform pg_advisory_xact_lock(hashtext(new.sender_id::text));
 if (select count(*) from public.messages where sender_id=new.sender_id and created_at>now()-interval '1 minute')>=30 then raise exception 'أرسلت رسائل كثيرة. انتظر دقيقة.'; end if;
 return new;
end $$;
create trigger message_limit before insert on messages for each row execute function private.message_limit();
revoke execute on function private.media_path_guard(),private.immutable_identity(),private.message_limit() from public;
