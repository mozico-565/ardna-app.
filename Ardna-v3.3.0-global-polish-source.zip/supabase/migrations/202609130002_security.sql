do $$ declare t text; begin
 foreach t in array array['profiles','user_roles','engineer_profiles','properties','property_records','property_images','engineering_designs','design_images','design_files','design_licenses','design_orders','custom_design_requests','design_modification_requests','favorites','property_views','design_views','conversations','conversation_members','messages','reviews','documents','service_requests','notifications','reports','audit_logs'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('revoke all on public.%I from anon, authenticated',t);
 execute format('grant select on public.%I to authenticated',t);
 -- Suspended users are denied even when another permissive policy matches.
 execute format('create policy active_account on public.%I as restrictive to authenticated using (private.active(auth.uid())) with check (private.active(auth.uid()))',t);
 end loop;
end $$;
create policy profile_self on profiles for select to authenticated using(id=auth.uid() or private.admin());
grant update(full_name,phone,avatar_url,city,country) on profiles to authenticated;
create policy profile_edit on profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy roles_self on user_roles for select to authenticated using(user_id=auth.uid() or private.admin());
create policy engineer_self on engineer_profiles for select to authenticated using(user_id=auth.uid() or private.admin());
grant update(professional_name,specialization,bio,city,country,avatar_url,professional_license,years_experience,starting_price,is_available) on engineer_profiles to authenticated;
create policy engineer_edit on engineer_profiles for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

grant select on properties,engineering_designs,property_images,design_images,design_licenses,reviews to anon;
create policy property_read on properties for select using((status='approved' and private.active(owner_id)) or owner_id=auth.uid() or private.admin());
create policy design_read on engineering_designs for select using((status='approved' and private.active(engineer_id)) or engineer_id=auth.uid() or private.admin());
grant insert(owner_id,title,description,category,listing_type,price,currency,state,city,district,area,area_unit,width,length,latitude,longitude),
 update(title,description,category,listing_type,price,currency,state,city,district,area,area_unit,width,length,latitude,longitude),delete on properties to authenticated;
create policy property_insert on properties for insert to authenticated with check(owner_id=auth.uid() and status='draft' and not featured);
create policy property_update on properties for update to authenticated using(owner_id=auth.uid() and status in ('draft','rejected')) with check(owner_id=auth.uid() and status in ('draft','rejected'));
create policy property_delete on properties for delete to authenticated using(owner_id=auth.uid() and status in ('draft','rejected'));
grant insert(engineer_id,title,description,category,architectural_style,floors,bedrooms,bathrooms,building_area,min_land_width,min_land_length,recommended_land_area,price,currency),
 update(title,description,category,architectural_style,floors,bedrooms,bathrooms,building_area,min_land_width,min_land_length,recommended_land_area,price,currency),delete on engineering_designs to authenticated;
create policy design_insert on engineering_designs for insert to authenticated with check(engineer_id=auth.uid() and private.is_engineer() and status='draft' and not featured);
create policy design_update on engineering_designs for update to authenticated using(engineer_id=auth.uid() and status in ('draft','rejected')) with check(engineer_id=auth.uid() and status in ('draft','rejected'));
create policy design_delete on engineering_designs for delete to authenticated using(engineer_id=auth.uid() and status in ('draft','rejected'));

create function private.owns_listing(kind text,lid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select private.active(auth.uid()) and case when kind='property' then exists(select 1 from public.properties where id=lid and owner_id=auth.uid() and status in ('draft','rejected'))
 else exists(select 1 from public.engineering_designs where id=lid and engineer_id=auth.uid() and status in ('draft','rejected')) end
$$;
grant insert,update,delete on property_records to authenticated;
create policy record_owner on property_records for all to authenticated using(exists(select 1 from properties where id=property_id and owner_id=auth.uid()) or private.admin()) with check(private.owns_listing('property',property_id));
do $$ declare t text; k text; fk text; parent text; begin
 foreach t in array array['property_images','design_images','design_licenses'] loop
 k:=case when t='property_images' then 'property' else 'design' end;
 fk:=k||'_id'; parent:=case when k='property' then 'properties' else 'engineering_designs' end;
 execute format('create policy parent_read on public.%I for select using(exists(select 1 from public.%I p where p.id=%I))',t,parent,fk);
 execute format('grant insert,update,delete on public.%I to authenticated',t);
 execute format('create policy owner_write on public.%I for all to authenticated using(private.owns_listing(%L,%I)) with check(private.owns_listing(%L,%I))',t,k,fk,k,fk);
 end loop;
end $$;
create policy files_access on design_files for select to authenticated using(engineer_id=auth.uid() or private.admin() or exists(select 1 from design_orders o where o.design_id=design_files.design_id and o.customer_id=auth.uid() and o.status in ('delivered','completed')));
grant insert(design_id,engineer_id,path,original_filename,file_size,file_hash),delete on design_files to authenticated;
create policy files_insert on design_files for insert to authenticated with check(engineer_id=auth.uid() and private.owns_listing('design',design_id) and path like auth.uid()::text||'/'||design_id::text||'/%');
create policy files_delete on design_files for delete to authenticated using(private.owns_listing('design',design_id));
grant insert(user_id,property_id,design_id),delete on favorites to authenticated;
create policy favorites_self on favorites for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy order_read on design_orders for select to authenticated using(customer_id=auth.uid() or engineer_id=auth.uid() or private.admin());
create policy custom_read on custom_design_requests for select to authenticated using(customer_id=auth.uid() or engineer_id=auth.uid() or private.admin());
grant insert(customer_id,engineer_id,property_id,title,description,land_width,land_length,land_area,floors,budget) on custom_design_requests to authenticated;
create policy custom_insert on custom_design_requests for insert to authenticated with check(customer_id=auth.uid() and engineer_id<>auth.uid() and private.active(engineer_id) and (property_id is null or exists(select 1 from properties where id=property_id and owner_id=auth.uid())));
create policy modification_read on design_modification_requests for select to authenticated using(customer_id=auth.uid() or engineer_id=auth.uid() or private.admin());
grant insert(order_id,customer_id,engineer_id,description) on design_modification_requests to authenticated;
create policy modification_insert on design_modification_requests for insert to authenticated with check(customer_id=auth.uid() and exists(select 1 from design_orders o where o.id=order_id and o.customer_id=auth.uid() and o.engineer_id=design_modification_requests.engineer_id and o.status not in ('cancelled','disputed')));
create policy threads_read on conversations for select to authenticated using(private.member(id));
create policy members_read on conversation_members for select to authenticated using(private.member(conversation_id));
create policy messages_read on messages for select to authenticated using(private.member(conversation_id));
grant insert(conversation_id,sender_id,body) on messages to authenticated;
create policy messages_send on messages for insert to authenticated with check(sender_id=auth.uid() and private.member(conversation_id));
create policy reviews_read on reviews for select using(private.active(engineer_id));
grant insert(reviewer_id,engineer_id,order_id,rating,comment) on reviews to authenticated;
create policy review_eligible on reviews for insert to authenticated with check(reviewer_id=auth.uid() and exists(select 1 from design_orders o where o.id=order_id and o.customer_id=auth.uid() and o.engineer_id=reviews.engineer_id and o.status='completed'));
grant insert(user_id,name,path,mime_type,file_size),delete on documents to authenticated;
create policy document_self on documents for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid() and path like auth.uid()::text||'/%');
create policy service_self on service_requests for select to authenticated using(user_id=auth.uid() or private.admin());
grant insert(user_id,title,description) on service_requests to authenticated;
create policy service_insert on service_requests for insert to authenticated with check(user_id=auth.uid());
create policy notification_self on notifications for select to authenticated using(user_id=auth.uid());
grant update(read) on notifications to authenticated;
create policy notification_read on notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy reports_read on reports for select to authenticated using(user_id=auth.uid() or private.admin());
grant insert(user_id,property_id,design_id,engineer_id,reason,description) on reports to authenticated;
create policy reports_insert on reports for insert to authenticated with check(user_id=auth.uid());
create policy audit_admin on audit_logs for select to authenticated using(private.admin());
create policy property_view_read on property_views for select to authenticated using(viewer_id=auth.uid() or exists(select 1 from properties where id=property_id and owner_id=auth.uid()) or private.admin());
create policy design_view_read on design_views for select to authenticated using(viewer_id=auth.uid() or exists(select 1 from engineering_designs where id=design_id and engineer_id=auth.uid()) or private.admin());
-- Deliberate security-definer public projection: no license number, email or phone.
create view public.public_engineers as select e.user_id,e.professional_name,e.specialization,e.bio,e.city,e.country,e.avatar_url,e.years_experience,e.verification_status,e.starting_price,e.is_available,e.created_at,
 coalesce((select avg(r.rating)::numeric(3,2) from public.reviews r where r.engineer_id=e.user_id),0) as average_rating,
 (select count(*) from public.design_orders o where o.engineer_id=e.user_id and o.status='completed') as completed_projects
 from public.engineer_profiles e where private.active(e.user_id);
grant select on public.public_engineers to anon,authenticated;

-- All buckets are private, including previews, so rejected/unpublished media stay private.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('property-images','property-images',false,5242880,array['image/webp','image/jpeg','image/png']),
 ('design-previews','design-previews',false,5242880,array['image/webp','image/jpeg','image/png']),
 ('design-originals','design-originals',false,52428800,array['application/pdf','application/zip','application/octet-stream','image/vnd.dwg','image/vnd.dxf']),
 ('documents','documents',false,10485760,array['application/pdf','image/jpeg','image/png']);
create policy ardna_media_read on storage.objects for select to anon,authenticated using(
 (bucket_id='property-images' and exists(select 1 from public.property_images i where name in (i.path,i.thumbnail_path))) or
 (bucket_id='design-previews' and exists(select 1 from public.design_images i where name in (i.path,i.thumbnail_path))) or
 (bucket_id='design-originals' and private.active(auth.uid()) and exists(select 1 from public.design_files f where f.path=name)) or
 (bucket_id='documents' and private.active(auth.uid()) and (storage.foldername(name))[1]=auth.uid()::text)
);
create function private.can_upload(bucket text,path text) returns boolean language plpgsql stable security definer set search_path='' as $$
 declare bits text[]:=string_to_array(path,'/'); begin
 if not private.active(auth.uid()) or bits[1]<>auth.uid()::text then return false; end if;
 if bucket='documents' then return array_length(bits,1)=2; end if;
 if bucket not in ('property-images','design-previews','design-originals') then return false; end if;
 return private.owns_listing(case when bucket='property-images' then 'property' else 'design' end,bits[2]::uuid);
 exception when invalid_text_representation then return false; end
$$;
create policy ardna_upload on storage.objects for insert to authenticated with check(private.can_upload(bucket_id,name));
create policy ardna_media_delete on storage.objects for delete to authenticated using(private.can_upload(bucket_id,name));
