package com.ardna.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
