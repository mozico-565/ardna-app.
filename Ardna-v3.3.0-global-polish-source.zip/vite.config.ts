import {defineConfig} from 'vite';import react from '@vitejs/plugin-react';
// Relative assets make the app work on any GitHub Pages repository name.
export default defineConfig({plugins:[react()],base:'./',build:{rollupOptions:{output:{manualChunks:{map:['leaflet'],backend:['@supabase/supabase-js'],react:['react','react-dom']}}}}});
