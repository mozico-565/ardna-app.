import {defineConfig} from '@playwright/test';
export default defineConfig({testDir:'./scripts/ux-tests',testMatch:'**/*.spec.ts',use:{baseURL:'http://127.0.0.1:5190',screenshot:'only-on-failure'},webServer:{command:'npx vite --config scripts/ux-tests/vite.config.ts',url:'http://127.0.0.1:5190',reuseExistingServer:false},reporter:[['list'],['html',{open:'never'}]]});
