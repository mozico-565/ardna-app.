import {useEffect,useRef,useState} from 'react';
export function friendlyError(error:unknown){
 const message=typeof error==='string'?error:(error as Error)?.message||'';
 if(/invalid login credentials/i.test(message))return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
 if(/email not confirmed/i.test(message))return 'أكد بريدك الإلكتروني من رسالة التسجيل أولًا.';
 if(/already registered|already exists|duplicate key/i.test(message))return 'هذه البيانات مسجلة بالفعل. راجعها وحاول مجددًا.';
 if(/rate limit|too many/i.test(message))return 'طلبات كثيرة خلال وقت قصير. انتظر قليلًا ثم حاول مجددًا.';
 if(/fetch|network|timeout|connection/i.test(message))return 'تعذر الاتصال. تحقق من الإنترنت ثم أعد المحاولة.';
 if(/row.level|permission|not authorized|jwt|expired/i.test(message))return 'لا تتوفر صلاحية لهذه العملية. تحقق من تسجيل دخولك.';
 if(/constraint|null value|invalid input/i.test(message))return 'راجع الحقول المطلوبة والقيم المدخلة.';
 if(/storage|bucket|upload/i.test(message))return 'تعذر رفع أو فتح الملف. تحقق من الاتصال وأعد المحاولة.';
 return /[\u0600-\u06ff]/.test(message)?message:'تعذرت العملية. حاول مرة أخرى بعد قليل.';
}
const guards=new Map<symbol,()=>boolean>();
export function canLeave(){return ![...guards.values()].some(g=>g())||window.confirm('لديك تغييرات غير محفوظة. هل تريد مغادرة الصفحة؟');}
export function useUnsaved(dirty:boolean){
 const current=useRef(dirty);current.current=dirty;
 useEffect(()=>{const id=Symbol();guards.set(id,()=>current.current);const unload=(e:BeforeUnloadEvent)=>{if(current.current){e.preventDefault();e.returnValue=''}};window.addEventListener('beforeunload',unload);return()=>{guards.delete(id);window.removeEventListener('beforeunload',unload)}},[]);
 return ()=>{current.current=false};
}
const views=new Map<string,unknown>();
export function useViewState<T>(key:string,initial:T){
 const[state,setState]=useState<T>(()=>(views.get(key) as T)??initial);
 useEffect(()=>{views.set(key,state)},[key,state]);return [state,setState] as const;
}
export function clearViews(){views.clear()}
const positions=new Map<string,number>();
export function useNavigation(){
 const initial=()=>location.hash.replace(/^#\/?/,'')||'home';
 const[route,setRoute]=useState(initial),current=useRef(route),index=useRef(Number(history.state?.ardnaIndex)||0),restoring=useRef(false);
 useEffect(()=>{
 history.replaceState({...history.state,ardnaIndex:index.current},'');history.scrollRestoration='manual';
 const change=()=>{if(restoring.current){restoring.current=false;return}const next=initial();if(next===current.current)return;const target=Number(history.state?.ardnaIndex);
 if(!canLeave()){if(Number.isFinite(target)&&target!==index.current){restoring.current=true;history.go(index.current-target)}else history.replaceState({ardnaIndex:index.current},'','#/'+current.current);return}
 positions.set(current.current,window.scrollY);current.current=next;index.current=Number.isFinite(target)?target:index.current+1;history.replaceState({...history.state,ardnaIndex:index.current},'');setRoute(next);
 };
 window.addEventListener('hashchange',change);window.addEventListener('ardna:navigate',change);return()=>{window.removeEventListener('hashchange',change);window.removeEventListener('ardna:navigate',change)};
 },[]);
 useEffect(()=>{let pending=true;const restore=()=>{if(!pending)return;const y=positions.get(route)||0;window.scrollTo(0,y);if(Math.abs(window.scrollY-y)<3)pending=false};const cancel=()=>{pending=false};const id=requestAnimationFrame(restore);window.addEventListener('ardna:content-ready',restore);window.addEventListener('wheel',cancel,{passive:true});window.addEventListener('touchstart',cancel,{passive:true});return()=>{cancelAnimationFrame(id);window.removeEventListener('ardna:content-ready',restore);window.removeEventListener('wheel',cancel);window.removeEventListener('touchstart',cancel)}},[route]);
 const go=(path:string)=>{if(path===current.current||!canLeave())return;positions.set(current.current,window.scrollY);index.current++;history.pushState({ardnaIndex:index.current},'','#/'+path);current.current=path;setRoute(path)};
 const back=()=>{if(index.current>0)history.back();else go('home')};
 return {route,go,back};
}
export function useViewport(){
 useEffect(()=>{const viewport=window.visualViewport;const update=()=>{const height=viewport?.height||window.innerHeight;const typing=Boolean(document.activeElement?.matches('input,textarea,select'));document.documentElement.style.setProperty('--visible-height',height+'px');document.documentElement.classList.toggle('keyboard-open',typing&&window.innerHeight-height>120)};
 const focus=()=>{update();requestAnimationFrame(()=>{if(document.activeElement?.matches('input,textarea,select'))document.activeElement.scrollIntoView({block:'nearest',behavior:'auto'})})};
 viewport?.addEventListener('resize',update);window.addEventListener('focusin',focus);window.addEventListener('focusout',update);update();return()=>{viewport?.removeEventListener('resize',update);window.removeEventListener('focusin',focus);window.removeEventListener('focusout',update)};
 },[]);
}
export function toast(message:string,kind:'success'|'error'='success'){window.dispatchEvent(new CustomEvent('ardna:toast',{detail:{message,kind}}))}
