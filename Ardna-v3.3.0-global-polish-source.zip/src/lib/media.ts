import { db, check } from './backend';
import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';

export async function signed(bucket: string, path: string) {
 return check(await db().storage.from(bucket).createSignedUrl(path, 300)).signedUrl;
}
export async function openPrivateFile(bucket:string,path:string){
 const tab=Capacitor.isNativePlatform()?null:window.open('about:blank','_blank');
 if(tab)tab.opener=null;
 try{const url=await signed(bucket,path);if(Capacitor.isNativePlatform())await Browser.open({url});else if(tab)tab.location.href=url;else location.assign(url)}catch(e){tab?.close();throw e}
}
async function imageBlob(file: File, size: number, watermark?: string): Promise<Blob> {
 if (!['image/jpeg','image/png','image/webp'].includes(file.type) || file.size > 20*1024*1024) throw new Error('استخدم صورة JPG أو PNG أو WebP أصغر من 20 MB.');
 const bitmap = await createImageBitmap(file);
 const scale = Math.min(1, size/Math.max(bitmap.width, bitmap.height));
 const canvas = document.createElement('canvas'); canvas.width=Math.max(1,Math.round(bitmap.width*scale)); canvas.height=Math.max(1,Math.round(bitmap.height*scale));
 const ctx=canvas.getContext('2d')!; ctx.drawImage(bitmap,0,0,canvas.width,canvas.height); bitmap.close();
 if(watermark) { ctx.save(); ctx.fillStyle='rgba(0,40,30,.65)'; ctx.fillRect(0,canvas.height-64,canvas.width,64); ctx.fillStyle='#fff'; ctx.textAlign='center'; ctx.font=`${Math.max(12,Math.min(22,canvas.width/28))}px sans-serif`; ctx.fillText(watermark,canvas.width/2,canvas.height-25,canvas.width-16); ctx.restore(); }
 return new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('تعذرت معالجة الصورة')),'image/webp',.8));
}
export async function uploadImages(kind: 'property'|'design', id: string, uid: string, files: File[], engineerName='') {
 if(files.length>10) throw new Error('الحد الأقصى 10 صور.');
 const table=kind==='property'?'property_images':'design_images'; const bucket=kind==='property'?'property-images':'design-previews';
 const existing=check(await db().from(table).select('position').eq(kind+'_id',id));
 const positions=new Set(existing.map(r=>r.position));
 if(existing.length+files.length>10) throw new Error('الحد الأقصى 10 صور.');
 for(const file of files) {
  let position=0; while(positions.has(position)) position++; positions.add(position);
  const base=`${uid}/${id}/${crypto.randomUUID()}`; const path=base+'.webp', thumbnail_path=base+'-thumb.webp';
  const watermark=kind==='design'?`أرضنا • ${engineerName} • Preview • ${id.slice(0,8)}`:undefined;
  const image=await imageBlob(file,1400,watermark), thumb=await imageBlob(file,360,watermark);
  check(await db().storage.from(bucket).upload(path,image,{contentType:'image/webp'}));
  try { check(await db().storage.from(bucket).upload(thumbnail_path,thumb,{contentType:'image/webp'}));
   check(await db().from(table).insert({[kind+'_id']:id,path,thumbnail_path,position}));
  } catch(e) { await db().storage.from(bucket).remove([path,thumbnail_path]); throw e; }
 }
}
export async function uploadDocument(file: File,uid: string) {
 if(!['application/pdf','image/jpeg','image/png'].includes(file.type)||file.size>10485760||!file.size) throw new Error('استخدم PDF أو JPG أو PNG حتى 10 MB.');
 const path=`${uid}/${crypto.randomUUID()}`;
 check(await db().storage.from('documents').upload(path,file));
 try { check(await db().from('documents').insert({user_id:uid,name:file.name,path,mime_type:file.type,file_size:file.size})); }
 catch(e){await db().storage.from('documents').remove([path]);throw e;}
}
export async function uploadOriginal(file:File,uid:string,designId:string) {
 if(!/\.(pdf|zip|dwg|dxf)$/i.test(file.name)||!file.size||file.size>52428800) throw new Error('ملف PDF أو ZIP أو DWG أو DXF حتى 50 MB.');
 const hash=await crypto.subtle.digest('SHA-256',await file.arrayBuffer());
 const file_hash=Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('');
 const path=`${uid}/${designId}/${crypto.randomUUID()}`;
 check(await db().storage.from('design-originals').upload(path,file,{contentType:'application/octet-stream'}));
 try { check(await db().from('design_files').insert({engineer_id:uid,design_id:designId,path,original_filename:file.name,file_size:file.size,file_hash})); }
 catch(e){await db().storage.from('design-originals').remove([path]);throw e;}
}
