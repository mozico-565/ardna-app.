import {useEffect,useState} from 'react';
import {check,db,rpc,Row,share} from '../lib/backend';
import {openPrivateFile} from '../lib/media';
import {Action,DataForm,Empty,LoadState,Gallery,text,useLoad} from '../components/ui';
import {PropertyMap} from '../components/Map';
import {Kind,tableFor,imagesFor} from './Catalog';
export function Report({kind,id,uid}:{kind:'property'|'design'|'engineer',id:string,uid:string}){
 const[done,setDone]=useState(false);
 return <details><summary>الإبلاغ</summary>{done?<p>تم إرسال البلاغ للمراجعة.</p>:<DataForm label="إرسال البلاغ" fields={[{name:'reason',label:'السبب',options:['incorrect_information','possible_fraud','copyright','duplicate','inappropriate','other'],required:true},{name:'description',label:'التفاصيل',type:'textarea',required:true}]} submit={async v=>{check(await db().from('reports').insert({...v,user_id:uid,[kind+'_id']:id}));setDone(true)}}/>}</details>;
}
export function Details({kind,id,uid,go,match}:{kind:Kind,id:string,uid:string,go:(p:string)=>void,match:(v:Record<string,any>)=>void}){
 const[property]=useState(kind==='property'),[fav,setFav]=useState<Row|null>(null),[views,setViews]=useState<number|null>(null),[shared,setShared]=useState(false);
 const q=useLoad(async()=>{
  const r=check(await db().from(tableFor(kind)).select(`*,${imagesFor(kind)}(*)`).eq('id',id).single()) as Row;
  const f=uid?check(await db().from('favorites').select('*').eq('user_id',uid).eq(kind+'_id',id).maybeSingle()):null;setFav(f);
  return r;
 },[kind,id,uid]);
 useEffect(()=>{if(!uid)return;rpc('record_view',{kind,target:id}).then(setViews).catch(()=>{})},[kind,id]);
 const r=q.data,owner=r?.[property?'owner_id':'engineer_id'];
 return <LoadState query={q} variant="details">{r&&<><Gallery images={r[imagesFor(kind)]||[]} bucket={property?'property-images':'design-previews'} title={r.title}/><h1>{r.title}</h1><p className="detail-price">{Number(r.price).toLocaleString('ar')} {r.currency} • {text(r.status)}</p><p className="detail-location">{property?`${r.state} • ${r.city} • ${r.area} ${r.area_unit==='feddan'?'فدان':'م²'}`:`مساحة البناء ${r.building_area} م²`}</p><p className="preserve">{r.description}</p>
 <dl>{(property?[['الموقع',`${r.state} / ${r.city} / ${r.district||''}`],['المساحة',`${r.area} ${r.area_unit==='m2'?'م²':'فدان'}`],['العرض',text(r.listing_type)]]:[['الطوابق',r.floors],['غرف النوم',r.bedrooms],['الحمامات',r.bathrooms],['مساحة البناء',r.building_area+' م²'],['أقل أبعاد أرض',`${r.min_land_width} × ${r.min_land_length} م`],['مساحة الأرض المناسبة',r.recommended_land_area+' م²']]).map(([k,v])=><div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}<div><dt>تاريخ الإضافة</dt><dd>{new Date(r.created_at).toLocaleDateString('ar')}</dd></div>{views!==null&&<div><dt>مشاهدات الحسابات الفريدة</dt><dd>{views}</dd></div>}</dl>
 <div className="detail-actions"><div className="toolbar">{uid&&<Action run={async()=>{if(fav){check(await db().from('favorites').delete().eq('id',fav.id));setFav(null)}else{setFav(check(await db().from('favorites').insert({user_id:uid,[kind+'_id']:id}).select().single()))}}}>{fav?'إزالة من المفضلة':'حفظ في المفضلة'}</Action>}<Action run={async()=>{await share(kind+'/'+id,r.title);setShared(true)}}>مشاركة</Action></div>{shared&&<p role="status">تمت المشاركة أو نسخ الرابط.</p>}
 {uid&&owner!==uid&&<Action run={async()=>go('chat/'+await rpc('start_conversation',{recipient:owner}))}>مراسلة {property?'صاحب العقار':'المهندس'}</Action>}</div>
 {!property&&<><button className="outline" onClick={()=>go('engineer/'+owner)}>ملف المهندس</button><Licenses id={id} owner={owner===uid} uid={uid} go={go}/></>}
 {property&&r.latitude!=null&&r.longitude!=null&&<PropertyMap rows={[r]}/>}
 {property&&owner===uid&&<button className="outline" onClick={()=>match({land_width:r.width,land_length:r.length,land_area:r.area_unit==='feddan'?r.area*4200:r.area})}>ابحث عن تصميم لهذه الأرض</button>}
 {owner===uid&&<><div className="toolbar"><Action run={async()=>{await rpc('listing_action',{kind,target:id,action:'edit'});go('edit-'+kind+'/'+id)}}>تعديل (إعادة إلى مسودة)</Action><Action run={async()=>{await rpc('listing_action',{kind,target:id,action:'archive'});q.reload()}}>أرشفة</Action>{property&&r.status==='approved'&&['sold','rented'].map(s=><Action key={s} run={async()=>{await rpc('listing_action',{kind,target:id,action:s});q.reload()}}>{text(s)}</Action>)}</div>{['draft','rejected'].includes(r.status)&&<Action run={async()=>{if(!confirm('حذف المسودة؟'))return;check(await db().from(tableFor(kind)).delete().eq('id',id));go('mine-'+kind)}}>حذف المسودة</Action>}</>}
 {uid?<Report kind={kind} id={id} uid={uid}/>:<button className="primary" onClick={()=>go('login')}>سجّل الدخول للتواصل والحفظ</button>}</>}</LoadState>;
}
function Licenses({id,owner,uid,go}:{id:string,owner:boolean,uid:string,go:(p:string)=>void}){
 const q=useLoad(async()=>({licenses:check(await db().from('design_licenses').select('*').eq('design_id',id)),files:uid?check(await db().from('design_files').select('*').eq('design_id',id)):[]}),[id,uid]);
 return <LoadState query={q}><h2>التراخيص</h2>{!q.data?.licenses.length&&<Empty/>}{q.data?.licenses.map(l=><article className="card" key={l.id}><h3>{text(l.type)}</h3><p>{l.description}</p><p>الاستخدام: {l.allowed_usage}</p><p>السعر: {l.price}</p>{uid&&!owner&&l.type!=='preview'&&<Action run={async()=>{await rpc('order_design',{license:l.id});go('requests')}}>إرسال طلب شراء</Action>}</article>)}<p>طلب الشراء لا يعني إتمام الدفع. تُنسَّق الشروط مع المهندس عبر المحادثة.</p>
 {q.data?.files.map(f=><Action key={f.id} run={async()=>{await openPrivateFile('design-originals',f.path)}}>تنزيل {f.original_filename}</Action>)}
 {owner&&<details><summary>إضافة ترخيص (في وضع المسودة)</summary><DataForm fields={[{name:'type',label:'النوع',options:['preview','personal_use','purchase_with_modification','full_rights','commercial_use'],required:true},{name:'price',label:'السعر',type:'number',min:0,required:true},{name:'description',label:'الوصف',type:'textarea',required:true},{name:'allowed_usage',label:'الاستخدام المسموح',type:'textarea',required:true}]} submit={async v=>{check(await db().from('design_licenses').upsert({...v,design_id:id},{onConflict:'design_id,type'}));q.reload()}}/></details>}
 </LoadState>;
}
