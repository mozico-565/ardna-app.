import {friendlyError,useUnsaved,toast} from '../lib/ux';
import {useRef,useState} from 'react';
import {db,check,rpc,Row} from '../lib/backend';
import {uploadImages,uploadOriginal} from '../lib/media';
import {Action,Field,Fields,LoadState,Media,useLoad} from '../components/ui';
import {PropertyMap} from '../components/Map';
import {Kind,tableFor,imagesFor} from './Catalog';
const number=(name:string,label:string,min=0):Field=>({name,label,type:'number',min,required:true});
export function Editor({kind,id,uid,go}:{kind:Kind,id?:string,uid:string,go:(p:string)=>void}){
 const q=useLoad(async()=>id?check(await db().from(tableFor(kind)).select(`*,${imagesFor(kind)}(*)`).eq('id',id).single()) as Row:null,[kind,id]);
 return <LoadState query={q}><EditorForm kind={kind} existing={q.data} uid={uid} go={go}/></LoadState>;
}
function EditorForm({kind,existing,uid,go}:{kind:Kind,existing:Row|null,uid:string,go:(p:string)=>void}){
 const[id,setId]=useState(existing?.id),[step,setStep]=useState(0),[v,setV]=useState<Record<string,any>>(existing||{currency:'SDG',area_unit:'m2',category:'house',listing_type:'sale',floors:1,bedrooms:0,bathrooms:0}),[files,setFiles]=useState<File[]>([]),[original,setOriginal]=useState<File|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const[license,setLicense]=useState({type:'personal_use',price:0,description:'',allowed_usage:''}),[sentFiles,setSentFiles]=useState(false);
 const saved=useRef(JSON.stringify(v));const lock=useRef(false);const clear=useUnsaved(JSON.stringify(v)!==saved.current||files.length>0||Boolean(original)||Boolean(license.description));
 const property=kind==='property';
 const steps=property?['المعلومات الأساسية','نوع العقار','السعر والمساحة','الموقع','الصور','معلومات إضافية','المراجعة','الإرسال']:['المعلومات الأساسية','نوع المبنى','الأبعاد والمساحات','صور المعاينة','السعر','التراخيص والملفات','المراجعة','الإرسال'];
 const fields:Field[][]=property?[
 [{name:'title',label:'عنوان العقار',required:true},{name:'description',label:'الوصف',type:'textarea',required:true}],
 [{name:'category',label:'نوع العقار',options:['land','house','apartment','commercial','farm'],required:true},{name:'listing_type',label:'نوع العرض',options:['sale','rent','not_listed'],required:true}],
 [number('price','السعر'),{name:'currency',label:'العملة',options:['SDG','USD'],required:true},number('area','المساحة',1),{name:'area_unit',label:'وحدة المساحة',options:['m2','feddan'],required:true}],
 [{name:'state',label:'الولاية',required:true},{name:'city',label:'المدينة',required:true},{name:'district',label:'الحي'},{...number('latitude','خط العرض',-90),max:90},{...number('longitude','خط الطول',-180),max:180}],[],
 [{name:'registration_number',label:'رقم التسجيل (خاص بك)'},{name:'width',label:'العرض بالمتر',type:'number',min:1},{name:'length',label:'الطول بالمتر',type:'number',min:1}]
 ]:[
 [{name:'title',label:'عنوان التصميم',required:true},{name:'description',label:'الوصف',type:'textarea',required:true}],
 [{name:'category',label:'نوع المبنى',options:['house','apartment','commercial','farm'],required:true},{name:'architectural_style',label:'الطراز المعماري',required:true}],
 [number('floors','الطوابق',1),number('bedrooms','غرف النوم'),number('bathrooms','الحمامات'),number('building_area','مساحة البناء م²',1),number('min_land_width','أقل عرض للأرض م',1),number('min_land_length','أقل طول للأرض م',1),number('recommended_land_area','مساحة الأرض المناسبة م²',1)],[],
 [number('price','السعر الابتدائي'),{name:'currency',label:'العملة',options:['SDG','USD'],required:true}],[]
 ];
 async function save(submit:boolean){
  if(lock.current)return;lock.current=true;setBusy(true);
  try{
  const keys=fields.flat().map(f=>f.name).filter(k=>k!=='registration_number');
  const payload=Object.fromEntries(keys.filter(k=>v[k]!=null&&v[k]!=='').map(k=>[k,v[k]]));
  let current=id;
  if(!current){const r=check(await db().from(tableFor(kind)).insert({...payload,[property?'owner_id':'engineer_id']:uid}).select('id').single());current=r.id;setId(current)}
  else check(await db().from(tableFor(kind)).update(payload).eq('id',current));
  if(property&&v.registration_number)check(await db().from('property_records').upsert({property_id:current,registration_number:v.registration_number}));
  if(!sentFiles){if(files.length)await uploadImages(kind,current!,uid,files);setSentFiles(true);setFiles([])}
  if(!property){
   if(license.description&&license.allowed_usage)check(await db().from('design_licenses').upsert({design_id:current,...license},{onConflict:'design_id,type'}));
   if(original){await uploadOriginal(original,uid,current!);setOriginal(null)}
  }
  if(submit)await rpc('listing_action',{kind,target:current,action:'submit'});
  saved.current=JSON.stringify(v);clear();toast(submit?'تم إرسال الإعلان للمراجعة.':'تم حفظ المسودة.');go(kind+'/'+current);
  }finally{lock.current=false;setBusy(false)}
 }
 return <><h1>{property?'إضافة / تعديل عقار':'إضافة / تعديل تصميم'}</h1><p>الخطوة {step+1} من 8 — {steps[step]}</p><progress aria-label="تقدم إضافة الإعلان" value={step+1} max={8}/>
 <form className="card editor-form" onSubmit={async e=>{e.preventDefault();setError('');if(step<7){setStep(s=>s+1);return}setBusy(true);try{await save(true)}catch(e){setError(friendlyError(e))}finally{setBusy(false)}}}>
 {step<6&&<Fields fields={fields[step]||[]} values={v} set={setV}/>}
 {property&&step===3&&<PropertyMap onPoint={(latitude,longitude)=>setV(x=>({...x,latitude,longitude}))}/>}
 {step===(property?4:3)&&<><label>{property?'صور العقار':'صور معاينة التصميم'}<input type="file" multiple accept="image/jpeg,image/png,image/webp" onChange={e=>{setFiles(Array.from(e.target.files||[]));setSentFiles(false)}}/></label><p>{files.length} صور مختارة • حتى 10 صور. {property?'':'تضاف علامة مائية إلى نسخ المعاينة.'}</p>{existing?.[imagesFor(kind)]?.map((img:Row)=><div className="media-edit" key={img.id}><Media bucket={property?'property-images':'design-previews'} path={img.thumbnail_path} alt="صورة محفوظة"/><Action run={async()=>{check(await db().from(imagesFor(kind)).delete().eq('id',img.id));check(await db().storage.from(property?'property-images':'design-previews').remove([img.path,img.thumbnail_path]));go('edit-'+kind+'/'+id+'?updated='+Date.now())}}>حذف الصورة</Action></div>)}</>}
 {!property&&step===5&&<><Fields fields={[{name:'type',label:'الترخيص',options:['preview','personal_use','purchase_with_modification','full_rights','commercial_use'],required:true},number('price','سعر الترخيص'),{name:'description',label:'وصف الترخيص',type:'textarea',required:true},{name:'allowed_usage',label:'الاستخدام المسموح',type:'textarea',required:true}]} values={license} set={x=>setLicense(x as typeof license)}/><p>يمكن إضافة تراخيص أخرى بعد حفظ التصميم، من صفحة التفاصيل.</p><label>ملف التصميم الأصلي (خاص)<input type="file" accept=".pdf,.zip,.dwg,.dxf" onChange={e=>setOriginal(e.target.files?.[0]||null)}/></label></>}
 {step>=6&&<><h2>{v.title}</h2><p className="preserve">{v.description}</p><dl>{fields.flat().filter(f=>f.name!=='description'&&v[f.name]!=null).map(f=><div key={f.name}><dt>{f.label}</dt><dd>{String(v[f.name])}</dd></div>)}</dl><p>سيُرسل للمراجعة، ولن يظهر للعامة قبل الموافقة.</p></>}
 <div className="toolbar">{step>0&&<button type="button" disabled={busy} onClick={()=>setStep(s=>s-1)}>السابق</button>}<button className="primary" disabled={busy}>{busy?'جارٍ الحفظ والرفع…':step===7?'إرسال للمراجعة':'التالي'}</button></div>{error&&<p role="alert" className="error">{error} {id&&'حُفظت المسودة؛ يمكنك إعادة المحاولة.'}</p>}
 </form>{step===7&&<Action disabled={busy} run={()=>save(false)}>حفظ كمسودة</Action>}</>;
}
