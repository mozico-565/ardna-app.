import {friendlyError,useUnsaved} from '../lib/ux';
import {useEffect,useState} from 'react';
import {db,check,rpc,Row} from '../lib/backend';
import {Empty,LoadState,Skeleton,useLoad} from '../components/ui';
export function Chat({thread,uid,go}:{thread?:string,uid:string,go:(p:string)=>void}){
 const q=useLoad(async()=>check(await db().from('conversations').select('id,created_at').order('created_at',{ascending:false}).limit(100)) as Row[],[uid]);
 return <><h1>المحادثات</h1>{thread?<Thread key={thread} id={thread} uid={uid}/>:<LoadState query={q}>{!q.data?.length&&<Empty title="لا توجد محادثات" action={()=>go('engineers')} actionLabel="ابحث عن مهندس">ابدأ محادثة من صفحة عقار أو مهندس.</Empty>}{q.data?.map(r=><button className="service" key={r.id} onClick={()=>go('chat/'+r.id)}><span>✉</span><b>محادثة {r.id.slice(0,8)}</b><span>‹</span></button>)}</LoadState>}</>;
}
function Thread({id,uid}:{id:string,uid:string}){
 const[rows,setRows]=useState<Row[]>([]),[body,setBody]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[more,setMore]=useState(false),[loaded,setLoaded]=useState(false);
 useUnsaved(Boolean(body.trim()));
 useEffect(()=>{let active=true;const load=async()=>{try{const r=check(await db().from('messages').select('*').eq('conversation_id',id).order('created_at',{ascending:false}).limit(50));if(active){setRows(r.reverse());setLoaded(true);setMore(r.length===50);setError('')}await rpc('mark_messages_read',{thread:id})}catch(e){if(active)setError(friendlyError(e))}};void load();const timer=setInterval(()=>{if(document.visibilityState==='visible')void load()},10000);return()=>{active=false;clearInterval(timer)}},[id]);
 return <><p>رسائل نصية خاصة بأعضاء المحادثة. تتحدث تلقائيًا كل 10 ثوانٍ.</p>{more&&<p>تظهر أحدث 50 رسالة.</p>}{!loaded&&!error&&<Skeleton variant="messages"/>}<div className="messages" aria-live="polite">{loaded&&!rows.length&&<Empty>لا توجد رسائل بعد.</Empty>}{rows.map(r=><article className={'message '+(r.sender_id===uid?'mine':'')} key={r.id}><p>{r.body}</p><small>{new Date(r.created_at).toLocaleString('ar')} {r.sender_id===uid&&r.read_at?'• مقروءة':''}</small></article>)}</div><form className="chat-composer" onSubmit={async e=>{e.preventDefault();if(busy||!body.trim())return;setBusy(true);setError('');try{const r=check(await db().from('messages').insert({conversation_id:id,sender_id:uid,body:body.trim()}).select().single());setRows(x=>[...x,r]);setBody('')}catch(e){setError(friendlyError(e))}finally{setBusy(false)}}}><label>رسالة<textarea name="body" value={body} maxLength={4000} required onChange={e=>setBody(e.target.value)}/></label><button className="primary" disabled={busy}>{busy?'جارٍ الإرسال…':'إرسال'}</button></form>{error&&<p className="error" role="alert">{error}</p>}</>;
}
