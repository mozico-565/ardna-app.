import {useState} from 'react';
import {CheckCircle2,MailCheck} from 'lucide-react';
import {Capacitor} from '@capacitor/core';
import {Browser} from '@capacitor/browser';
import {db,check,authRedirect} from '../lib/backend';
import {Action,Brand,DataForm} from '../components/ui';
import {toast} from '../lib/ux';
export function Auth({recovery=false}:{recovery?:boolean}) {
 const[mode,setMode]=useState(recovery?'reset':'login'),[message,setMessage]=useState(''),[verified,setVerified]=useState(false);
 const titles:Record<string,string>={login:'تسجيل الدخول',signup:'إنشاء حساب',forgot:'استعادة كلمة المرور',reset:'كلمة مرور جديدة'};
 if(verified)return <section className="login auth-complete"><div className="success-orbit"><MailCheck/></div><h1>تم إنشاء حسابك</h1><p>أرسلنا رابط التأكيد إلى بريدك. افتحه ثم عد لتسجيل الدخول.</p><button className="primary" onClick={()=>{setVerified(false);setMode('login')}}>الانتقال لتسجيل الدخول</button></section>;
 return <section className="login"><Brand className="login-brand"/><h1>{titles[mode]}</h1><p className="auth-lead">{mode==='login'?'مرحبًا بعودتك إلى أرضنا':mode==='signup'?'خطوة واحدة وتبدأ رحلتك العقارية':''}</p>
 <DataForm key={mode} fields={[...(mode==='signup'?[{name:'full_name',label:'الاسم الكامل',required:true}]:[]),...(mode!=='reset'?[{name:'email',label:'البريد الإلكتروني',type:'email',required:true}]:[]),...(!['forgot'].includes(mode)?[{name:'password',label:'كلمة المرور (8 أحرف على الأقل)',type:'password',required:true}]:[])]} label={titles[mode]} submit={async v=>{
  setMessage(''); if(v.password&&v.password.length<8)throw new Error('استخدم كلمة مرور من 8 أحرف على الأقل.');
  if(mode==='login'){const result=check(await db().auth.signInWithPassword({email:v.email,password:v.password}));toast('تم تسجيل الدخول بنجاح.');location.hash='/home';return result;}
  if(mode==='signup'){const result=check(await db().auth.signUp({email:v.email,password:v.password,options:{data:{full_name:v.full_name},emailRedirectTo:authRedirect()}}));if(result.session){toast('تم إنشاء الحساب وتسجيل الدخول بنجاح.');location.hash='/home'}else setVerified(true);return result;}
  if(mode==='forgot'){check(await db().auth.resetPasswordForEmail(v.email,{redirectTo:authRedirect()}));setMessage('إذا كان البريد مسجّلًا، ستصلك رسالة الاستعادة.');}
  if(mode==='reset'){check(await db().auth.updateUser({password:v.password}));await db().auth.signOut();location.hash='/';location.reload();}
 }}/>{message&&<p role="status" className="auth-status"><CheckCircle2/>{message}</p>}
 {mode==='login'&&import.meta.env.VITE_GOOGLE_AUTH_ENABLED==='true'&&<Action run={async()=>{const result=check(await db().auth.signInWithOAuth({provider:'google',options:{redirectTo:authRedirect(),skipBrowserRedirect:Capacitor.isNativePlatform()}}));if(Capacitor.isNativePlatform()&&result.url)await Browser.open({url:result.url})}}>المتابعة باستخدام Google</Action>}
 {!recovery&&<div className="toolbar">{Object.entries(titles).filter(([k])=>k!==mode&&k!=='reset').map(([k,t])=><button key={k} onClick={()=>{setMode(k);setMessage('')}}>{t}</button>)}</div>}
 </section>;
}
