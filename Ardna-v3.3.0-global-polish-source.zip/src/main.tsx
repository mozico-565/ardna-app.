import React from 'react';
import {createRoot} from 'react-dom/client';
import {App} from './App';
createRoot(document.getElementById('root')!).render(<App/>);
// Retire legacy caches. Never cache authenticated data or signed URLs.
if('serviceWorker' in navigator)void navigator.serviceWorker.getRegistrations().then(rs=>Promise.all(rs.map(r=>r.unregister()))).catch(()=>{});
if('caches' in window)void caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('ardna-')).map(k=>caches.delete(k))));
