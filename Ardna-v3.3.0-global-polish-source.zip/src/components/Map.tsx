import {useEffect,useRef,useState} from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {Row} from '../lib/backend';
export function PropertyMap({rows=[],onSelect,onPoint}:{rows?:Row[],onSelect?:(id:string)=>void,onPoint?:(lat:number,lng:number)=>void}) {
 const ref=useRef<HTMLDivElement>(null),map=useRef<L.Map|null>(null),[message,setMessage]=useState(''),[locating,setLocating]=useState(false);
 const pointRef=useRef(onPoint),selectRef=useRef(onSelect);pointRef.current=onPoint;selectRef.current=onSelect;
 useEffect(()=>{const m=L.map(ref.current!).setView([15.5,32.5],6);map.current=m;
 L.tileLayer(import.meta.env.VITE_MAP_TILE_URL||'https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:import.meta.env.VITE_MAP_ATTRIBUTION||'© OpenStreetMap contributors'}).on('tileerror',()=>setMessage('تعذر تحميل بعض أجزاء الخريطة. تحقق من الاتصال.')).addTo(m);
 let marker:L.CircleMarker|undefined;
 m.on('click',(e:L.LeafletMouseEvent)=>{if(pointRef.current){marker?.remove();marker=L.circleMarker(e.latlng,{color:'#003f34',fillOpacity:.8}).addTo(m);pointRef.current(e.latlng.lat,e.latlng.lng)}});
 const ro=new ResizeObserver(()=>m.invalidateSize());ro.observe(ref.current!);
 return()=>{ro.disconnect();m.remove();map.current=null};
 },[]);
 useEffect(()=>{if(!map.current)return;const layer=L.layerGroup().addTo(map.current);const points:L.LatLngTuple[]=[];
 rows.forEach(r=>{if(r.latitude==null||r.longitude==null)return;const p:L.LatLngTuple=[r.latitude,r.longitude];points.push(p);const el=document.createElement('div');const title=document.createElement('strong');title.textContent=r.title;el.append(title);
 if(selectRef.current){const b=document.createElement('button');b.textContent='تفاصيل العقار';b.onclick=()=>selectRef.current?.(r.id);el.append(b)}
 L.circleMarker(p,{color:'#003f34',fillColor:'#d4b996',fillOpacity:.9,radius:9}).bindPopup(el).addTo(layer);});
 if(points.length)map.current.fitBounds(L.latLngBounds(points),{padding:[30,30],maxZoom:14});
 return()=>{layer.remove()};},[rows]);
 return <div><button className="outline" disabled={locating} onClick={()=>{if(!navigator.geolocation){setMessage('تحديد الموقع غير متاح في هذا الجهاز.');return}setLocating(true);setMessage('جارٍ تحديد موقعك…');navigator.geolocation.getCurrentPosition(p=>{setLocating(false);setMessage('تم تحديد الموقع.');map.current?.setView([p.coords.latitude,p.coords.longitude],14);pointRef.current?.(p.coords.latitude,p.coords.longitude)},e=>{setLocating(false);setMessage(e.code===1?'لم تسمح بالوصول إلى الموقع. يمكنك تحديده يدويًا.':e.code===3?'انتهت مهلة تحديد الموقع. حاول مجددًا.':'تعذر تحديد الموقع. يمكنك تحديده يدويًا.')},{timeout:12000,maximumAge:60000})}}>{locating?'جارٍ تحديد الموقع…':'استخدام موقعي'}</button>{message&&<p role="status">{message}</p>}<div ref={ref} className="real-map" aria-label="خريطة العقارات في السودان"/>{onPoint&&<small>اضغط على الخريطة لتحديد موقع العقار.</small>}</div>;
}
