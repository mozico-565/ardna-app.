// Runs before React mounts so the saved theme is applied without a white flash.
try {
  document.documentElement.dataset.theme = localStorage.getItem('ardna-theme') || 'light';
} catch {
  document.documentElement.dataset.theme = 'light';
}
