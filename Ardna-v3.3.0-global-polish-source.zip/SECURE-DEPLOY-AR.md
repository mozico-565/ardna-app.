# Ardna v3.1.0 Secure Release

## الهدف
احتفظ بمستودع GitHub خاصًا، وابنِ APK من السورس مباشرة، وانشر الويب من مزود استضافة يدعم مستودعات GitHub الخاصة.

## GitHub
1. ارفع محتويات هذا المجلد مباشرة إلى جذر المستودع. لا ترفع ملف ZIP داخل المستودع.
2. من Settings > Secrets and variables > Actions أضف Secrets:
   - VITE_SUPABASE_URL
   - VITE_SUPABASE_ANON_KEY
3. أضف Variable باسم VITE_PUBLIC_APP_URL بقيمة رابط الموقع النهائي.
4. VITE_GOOGLE_AUTH_ENABLED اختياري.
5. بعد التأكد من أن الاستضافة الخارجية تعمل، اجعل المستودع Private.

## بناء APK
Workflow: `.github/workflows/build-apk.yml`
يبني المشروع مباشرة من جذر المستودع ولا يحتاج unzip.

## نشر الويب على Cloudflare Pages
- اربط المستودع الخاص من لوحة Cloudflare Pages.
- Framework preset: Vite
- Build command: npm run build
- Build output directory: dist
- أضف متغيرات البيئة نفسها في إعدادات مشروع Pages.
- بعد أول نشر ناجح، انسخ رابط الموقع النهائي وضعه في VITE_PUBLIC_APP_URL في GitHub وفي إعدادات الاستضافة، ثم أعد النشر.

## قواعد أمنية
- لا تضع service_role أو sb_secret أو كلمة مرور قاعدة البيانات في الواجهة أو VITE_*.
- المفتاح المسموح للواجهة هو Supabase anon/publishable فقط، مع RLS صحيح.
- لا ترفع .env أو keystore أو source maps.
- لا تحفظ نسخ ZIP قديمة من السورس داخل مستودع عام.
