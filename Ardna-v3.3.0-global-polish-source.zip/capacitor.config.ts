import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ardna.app',
  appName: 'أرضنا',
  webDir: 'dist',
  backgroundColor: '#003f34',
  server: { androidScheme: 'https' }
};

export default config;
