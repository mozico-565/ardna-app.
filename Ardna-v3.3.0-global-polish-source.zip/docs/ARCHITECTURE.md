# Ardna implementation

The existing React/Vite/Capacitor application and brand assets are retained. The monolithic demo screen was replaced by feature modules in `src/features`. Styling keeps the original brand and responsive overrides. Native launch backgrounds remain small and unscaled.

- Supabase client uses PKCE, persistent sessions, optional Google OAuth, and Capacitor Preferences. No service-role key is shipped.
- `supabase/migrations`: schema, RLS/storage, server-controlled actions, media and identity hardening.
- `private` is a non-exposed schema. Security-definer functions use an empty search_path, explicit relation names, and authorization checks. RPCs expose an allowlist of transitions.
- `profiles` and engineer license data are private. `public_engineers` intentionally exposes a curated public projection, with computed ratings/project count.
- Catalog queries paginate. Map markers come from the same filtered page; tiles are configurable. Geolocation is opt-in.
- Draft edits return listings to moderation. Orders retain a license/price snapshot. Only explicit delivery unlocks originals. No payment receipt can be fabricated by a frontend update.
- Signed URLs expire after five minutes. Legacy service-worker caches are retired to prevent caching private responses. Storage may retain unreferenced objects after interrupted uploads/deleted drafts; add an owner-controlled cleanup job as storage usage grows.
- Polling chat uses Supabase every ten seconds while visible, with RLS membership checks. Text is rendered as React text, never injected HTML.
- Optional paid-provider boundaries: `paymentProvider` is disabled. SMS/biometrics are absent from production UI. FCM/Turnstile/Sentry require follow-up integration (see START-AR).

Primary references consulted:
- https://supabase.com/docs/guides/database/postgres/row-level-security
- https://supabase.com/docs/guides/auth/passwords
- https://leafletjs.com/reference.html

The SQL integration suite runs the real migrations in PGlite with minimal auth/storage scaffolding. Hosted Supabase, email delivery, native redirects, iOS signing, and actual-device tests remain separate acceptance gates.
