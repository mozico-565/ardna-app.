# توقيع نسخة أرضنا النهائية

يتم بناء التطبيق الآن كـ Release موقّع تلقائيًا عبر GitHub Actions. لا ترفع ملف المفتاح (`.keystore`) إلى GitHub ولا ترسله لأي شخص.

## أنشئ مفتاح التوقيع مرة واحدة على جهازك

```bash
keytool -genkeypair -v -keystore ardna-release.keystore -alias ardna -keyalg RSA -keysize 4096 -validity 10000
```

احتفظ بكلمة مرور الملف وكلمة مرور المفتاح في مكان آمن. فقدان المفتاح يمنعك من نشر تحديثات للتطبيق نفسه مستقبلاً.

## أضف Secrets في GitHub

من المستودع: **Settings → Secrets and variables → Actions → New repository secret**.

أضف هذه الأربعة:

| الاسم | القيمة |
|---|---|
| `ARDNA_KEYSTORE_BASE64` | ناتج الأمر `base64 -w 0 ardna-release.keystore` |
| `ARDNA_STORE_PASSWORD` | كلمة مرور ملف المفتاح |
| `ARDNA_KEY_ALIAS` | `ardna` أو الاسم الذي اخترته |
| `ARDNA_KEY_PASSWORD` | كلمة مرور المفتاح |

بعد إضافتها، شغّل Action باسم **Build Ardna APK**. ستجد في Artifacts ملفين موقّعين: APK للتثبيت المباشر، وAAB للرفع إلى Google Play.
