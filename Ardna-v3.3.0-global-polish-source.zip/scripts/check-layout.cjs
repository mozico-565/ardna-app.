const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
for(const [width,height] of [[320,568],[360,780],[412,915],[768,1024],[1024,600]]){
 const page=await browser.newPage({viewport:{width,height}});await page.goto('http://127.0.0.1:5173/');
 await page.getByText('تخطي',{exact:true}).click();await page.getByText('حسابي',{exact:true}).click();await page.getByText('الإعدادات',{exact:true}).click();await page.getByRole('switch').check();
 if(!await page.locator('.app').evaluate(e=>e.classList.contains('dark')))throw Error('dark failed');
 const fits=await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth);if(!fits)throw Error('overflow '+width);
 await page.locator('header button').first().click();
 const colors=await page.locator('.service>svg').first().evaluate(e=>({fg:getComputedStyle(e).color,bg:getComputedStyle(e).backgroundColor}));
 await page.screenshot({path:'/tmp/ardna-'+width+'.png',fullPage:true});console.log({width,height,fits,colors});await page.close();}
await browser.close();})();
