// Isolated test fixture. This file is only loaded by test-ux.mjs's esbuild alias.
export type Row={id:string,[key:string]:any};
export const state={roles:[] as string[],tables:{} as Record<string,any[]>,calls:[] as string[],session:null as any,listener:null as ((event:string,s:any)=>void)|null,fail:false};
state.tables.properties=[{id:'property-test',owner_id:'owner-test',title:'عقار اختبار معزول',city:'الخرطوم',state:'الخرطوم',area:300,area_unit:'m2',price:100,currency:'SDG',status:'approved',category:'land',listing_type:'sale',description:'بيانات اختبار غير منشورة',created_at:'2026-09-13',property_images:[]}];
export function reset(){state.roles=[];state.session=null;state.calls=[];state.tables.favorites=[];state.tables.profiles=[{id:'user-test',full_name:'مستخدم الاختبار'}];state.tables.user_roles=[];state.fail=false}
reset();
class Query{
 filters:((r:any)=>boolean)[]=[];op='select';payload:any;one=false;head=false;
 constructor(public table:string){}
 select(_='*',opts:any={}){this.head=opts.head;return this}eq(k:string,v:any){this.filters.push(r=>r[k]===v);return this}in(k:string,v:any[]){this.filters.push(r=>v.includes(r[k]));return this}ilike(){return this}or(){return this}gte(){return this}lte(){return this}order(){return this}range(){return this}limit(){return this}single(){this.one=true;return this}maybeSingle(){this.one=true;return this}insert(v:any){this.op='insert';this.payload=v;return this}update(v:any){this.op='update';this.payload=v;return this}upsert(v:any){this.op='insert';this.payload=v;return this}delete(){this.op='delete';return this}
 then(resolve:any,reject:any){return Promise.resolve().then(()=>{state.calls.push(this.table+':'+this.op);if(state.fail)return {data:null,error:{message:'Failed to fetch'}};const table=state.tables[this.table]??(state.tables[this.table]=[]);let rows=table.filter(r=>this.filters.every(f=>f(r)));
 if(this.op==='insert'){const r={id:this.table+'-new',created_at:new Date().toISOString(),status:'draft',...this.payload};if(this.table==='engineering_designs')r.design_images=[];table.push(r);rows=[r]}
 if(this.op==='update')rows.forEach(r=>Object.assign(r,this.payload));if(this.op==='delete')state.tables[this.table]=table.filter(r=>!rows.includes(r));
 return {data:this.head?null:this.one?rows[0]||null:rows,error:null,count:rows.length};}).then(resolve,reject)}
}
function emit(){state.listener?.('SIGNED_IN',state.session)}
export const supabase={auth:{getSession:async()=>({data:{session:state.session},error:null}),onAuthStateChange:(fn:any)=>{state.listener=fn;return {data:{subscription:{unsubscribe(){state.listener=null}}}}},signUp:async()=>{state.calls.push('auth:signup');state.session={user:{id:'user-test'}};emit();return {data:{session:state.session},error:null}},signInWithPassword:async()=>{state.session={user:{id:'user-test'}};emit();return {data:{session:state.session},error:null}},signOut:async()=>{state.session=null;state.listener?.('SIGNED_OUT',null);return {error:null}},startAutoRefresh(){},stopAutoRefresh(){},exchangeCodeForSession:async()=>({error:null}),resetPasswordForEmail:async()=>({error:null}),updateUser:async()=>({error:null})},from:(table:string)=>new Query(table),storage:{from:()=>({remove:async()=>({error:null})})}};
export const configured=true;
export function db(){return supabase}
export function check(r:any){if(r.error)throw Error(r.error.message);return r.data}
export async function rpc(name:string,args:any){state.calls.push('rpc:'+name);if(name==='choose_role'){state.roles.push(args.chosen);state.tables.user_roles.push({user_id:'user-test',role:args.chosen});if(args.chosen==='engineer')state.tables.engineer_profiles=[{user_id:'user-test',verification_status:'pending',...args.details}];return null}if(name==='start_conversation'){state.tables.conversations=[{id:'thread-test',created_at:'2026-09-13'}];return 'thread-test'}if(name==='listing_action'){const row=state.tables.engineering_designs.find(r=>r.id===args.target);if(row)row.status='pending'}return 1}
export const authRedirect=()=>'';
export const share=async()=>{state.calls.push('share')};
export const publicBase='https://example.invalid/';
export const paymentProvider={enabled:false};
