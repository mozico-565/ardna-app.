import {test,expect} from '@playwright/test';
for(const width of [320,360,390,430,768])for(const theme of ['light','dark'])for(const role of ['customer','engineer']){
 test(`${role} ${width}px ${theme}`,async({page})=>{
  await page.setViewportSize({width,height:844});
  await page.addInitScript(t=>localStorage.setItem('ardna-theme',t),theme);
  await page.goto('/?role='+role+'#/home');
  await expect(page.getByRole('heading',{level:1})).toBeVisible();
  await expect(page.getByLabel('التنقل الرئيسي')).toBeVisible();
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);
  expect(overflow).toBe(false);
  await page.getByRole('button',{name:'حسابي',exact:true}).click();
  await page.getByRole('button',{name:'الإعدادات',exact:true}).click();
  await expect(page.getByRole('switch')).toBeVisible();
  expect(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1)).toBe(false);
 });
}
test('reduced motion',async({page})=>{await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/?role=customer#/home');await expect(page.getByRole('heading',{level:1})).toBeVisible();expect(await page.locator('.page-transition').evaluate(el=>getComputedStyle(el).animationName)).toBe('none')});
