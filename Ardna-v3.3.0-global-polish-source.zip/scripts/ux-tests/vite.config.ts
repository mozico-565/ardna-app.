import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {resolve} from 'node:path';
export default defineConfig({root:resolve('scripts/ux-tests'),plugins:[react()],resolve:{alias:[{find:/^.*lib\/backend$/,replacement:resolve('scripts/ux-tests/backend.ts')}]},server:{host:'127.0.0.1',port:5190,fs:{allow:[resolve('.')]}}});
