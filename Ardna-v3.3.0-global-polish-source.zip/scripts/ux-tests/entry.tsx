// Test-only entry: never imported by the production app.
import React from 'react';
import {createRoot} from 'react-dom/client';
import {App} from '../../src/App';
import {state} from './backend';
const role=new URLSearchParams(location.search).get('role');
if(role==='customer'||role==='engineer'){
 state.session={user:{id:'user-test'}};
 state.tables.user_roles=[{user_id:'user-test',role}];
 state.tables.engineer_profiles=[{user_id:'user-test',verification_status:'pending'}];
}
createRoot(document.getElementById('root')!).render(<App/>);
