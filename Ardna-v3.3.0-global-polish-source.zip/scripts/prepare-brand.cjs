const sharp=require('sharp');
const fs=require('fs/promises');
const path=require('path');
const root=path.resolve(__dirname,'..');
const source=path.join(root,'public/brand-transparent.svg');
async function canvas(size,ratio=.82){const icon=await sharp(source).resize(Math.round(size*ratio),Math.round(size*ratio),{fit:'contain'}).png().toBuffer();return sharp({create:{width:size,height:size,channels:4,background:'#003f34'}}).composite([{input:icon,gravity:'centre'}]).png().toBuffer()}
(async()=>{
 for(const[density,size]of Object.entries({ldpi:36,mdpi:48,hdpi:72,xhdpi:96,xxhdpi:144,xxxhdpi:192})){
  const dir=path.join(root,`android/app/src/main/res/mipmap-${density}`);await fs.mkdir(dir,{recursive:true});const bytes=await canvas(size);for(const n of ['ic_launcher','ic_launcher_round'])await fs.writeFile(path.join(dir,n+'.png'),bytes);
 }
 for(const[name,size]of [['icon-192',192],['icon-512',512],['apple-touch-icon',180]])await fs.writeFile(path.join(root,'public',name+'.png'),await canvas(size));
 await fs.writeFile(path.join(root,'assets/icon-only.png'),await canvas(1024));
 await fs.writeFile(path.join(root,'ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png'),await canvas(1024));
 const dir=path.join(root,'android/app/src/main/res/drawable-mdpi');await fs.mkdir(dir,{recursive:true});
 const mark=await sharp(source).resize(160,160).png().toBuffer();await sharp({create:{width:288,height:288,channels:4,background:'#00000000'}}).composite([{input:mark,gravity:'centre'}]).png().toFile(path.join(dir,'launch_logo.png'));
 await sharp(source).resize(112,112).png().toFile(path.join(dir,'launch_logo_small.png'));
 const foreground=await sharp(source).resize(176,176).png().toBuffer();await sharp({create:{width:288,height:288,channels:4,background:'#00000000'}}).composite([{input:foreground,gravity:'centre'}]).png().toFile(path.join(dir,'launcher_foreground.png'));
 for(const [scale,size] of [['1x',112],['2x',224],['3x',336]])await sharp(source).resize(size,size).png().toFile(path.join(root,`ios/App/App/Assets.xcassets/Splash.imageset/logo-${scale}.png`));
 console.log('Brand assets generated with consistent contain sizing and safe margins.');
})();
