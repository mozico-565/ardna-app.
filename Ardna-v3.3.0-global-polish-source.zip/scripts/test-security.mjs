import {PGlite} from '@electric-sql/pglite';
import {readFile,readdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
const db=new PGlite();let tests=0;
await db.exec(`create role anon;create role authenticated;create schema auth;create schema storage;
 create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb default '{}');
 create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
 grant usage on schema auth,storage,public to anon,authenticated;grant execute on function auth.uid() to anon,authenticated;
 create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
 create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text);
 alter table storage.objects enable row level security;
 grant select,insert,update,delete on storage.objects to authenticated;grant select on storage.objects to anon;
 create function storage.foldername(text) returns text[] language sql immutable as $$select string_to_array($1,'/')$$;`);
for(const f of (await readdir('supabase/migrations')).filter(f=>f.endsWith('.sql')).sort()){
 try{await db.exec(await readFile('supabase/migrations/'+f,'utf8'));console.log('Migration OK:',f)}catch(e){console.error('MIGRATION FAILED',f,e.message);process.exit(1)}
}
const ids={customer:'00000000-0000-0000-0000-000000000001',engineer:'00000000-0000-0000-0000-000000000002',stranger:'00000000-0000-0000-0000-000000000003',admin:'00000000-0000-0000-0000-000000000004'};
for(const [name,id] of Object.entries(ids))await db.query('insert into auth.users(id,email) values($1,$2)',[id,name+'@example.test']);
await db.query("insert into public.user_roles(user_id,role) values($1,'admin')",[ids.admin]);
async function as(who,fn){await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[ids[who]||'']);await db.exec('set role '+(who==='anon'?'anon':'authenticated'));try{return await fn()}finally{await db.exec('reset role')}}
async function ok(label,fn){try{await fn();console.log('PASS',label);tests++}catch(e){console.error('FAIL',label,e.message);throw e}}
async function denied(sql,args=[]){let threw=false;try{await db.query(sql,args)}catch{threw=true}assert.equal(threw,true,'write should be denied')}
const scalar=async(sql,args=[])=>(await db.query(sql,args)).rows[0];
await ok('customer role persists and admin cannot be self-assigned',()=>as('customer',async()=>{
 await db.query("select public.choose_role('customer')");await denied("select public.choose_role('admin')");await denied("insert into user_roles(user_id,role) values($1,'admin')",[ids.customer]);
 assert.equal((await db.query('select * from user_roles')).rows.length,1);
}));
await ok('engineer starts pending; private license hidden',async()=>{
 await as('engineer',()=>db.query("select public.choose_role('engineer',$1)",[JSON.stringify({professional_name:'مهندس الاختبار',specialization:'معماري',professional_license:'PRIVATE-123'})]));
 await as('stranger',async()=>{assert.equal((await db.query('select * from engineer_profiles')).rows.length,0);const p=await scalar('select * from public_engineers');assert.equal(p.verification_status,'pending');assert.equal('professional_license' in p,false)});
 await as('engineer',()=>denied("update engineer_profiles set verification_status='verified'"));
});
let property,design,license,order,thread;
await ok('property draft private, moderation cannot be bypassed',async()=>{
 await as('customer',async()=>{property=(await scalar("insert into properties(owner_id,title,category,listing_type,state,city,area) values($1,'أرض اختبار','land','sale','الجزيرة','ود مدني',300) returning id",[ids.customer])).id;await denied("update properties set status='approved' where id=$1",[property]);});
 await as('stranger',async()=>{assert.equal((await db.query('select * from properties')).rows.length,0);assert.equal((await db.query('update properties set title=\'غير مسموح\' where id=$1 returning id',[property])).rows.length,0)});
 await as('anon',async()=>assert.equal((await db.query('select * from properties')).rows.length,0));
 await as('admin',()=>db.query("select admin_action('property',$1,'approved')",[property]));
 await as('anon',async()=>assert.equal((await db.query('select * from properties')).rows.length,1));
});
await ok('favorites and private documents isolated across users',async()=>{
 await as('customer',async()=>{await db.query('insert into favorites(user_id,property_id) values($1,$2)',[ids.customer,property]);await db.query("insert into documents(user_id,name,path,mime_type,file_size) values($1,'وثيقة',$2,'application/pdf',100)",[ids.customer,ids.customer+'/document']);await db.query("insert into storage.objects(bucket_id,name) values('documents',$1)",[ids.customer+'/document']);});
 await as('stranger',async()=>{assert.equal((await db.query('select * from favorites')).rows.length,0);assert.equal((await db.query('select * from documents')).rows.length,0);assert.equal((await db.query('select * from storage.objects')).rows.length,0);await denied("insert into storage.objects(bucket_id,name) values('documents',$1)",[ids.customer+'/forged'])});
});
await ok('private member chat; outsiders cannot read, send or join',async()=>{
 await as('customer',async()=>{thread=(await scalar('select start_conversation($1) as id',[ids.engineer])).id;await db.query('insert into messages(conversation_id,sender_id,body) values($1,$2,$3)',[thread,ids.customer,'رسالة الاختبار']);});
 await as('engineer',async()=>{assert.equal((await db.query('select * from messages')).rows.length,1);await db.query('select mark_messages_read($1)',[thread]);});
 await as('stranger',async()=>{assert.equal((await db.query('select * from conversations')).rows.length,0);assert.equal((await db.query('select * from messages')).rows.length,0);await denied('insert into messages(conversation_id,sender_id,body) values($1,$2,$3)',[thread,ids.stranger,'غير مسموح']);await denied('insert into conversation_members(conversation_id,user_id) values($1,$2)',[thread,ids.stranger]);});
});
await ok('design files remain private until explicit delivery',async()=>{
 await as('engineer',async()=>{
 design=(await scalar("insert into engineering_designs(engineer_id,title,category,building_area,min_land_width,min_land_length,recommended_land_area,price) values($1,'تصميم اختبار','house',100,10,20,200,500) returning id",[ids.engineer])).id;
 license=(await scalar("insert into design_licenses(design_id,type,price,description,allowed_usage) values($1,'personal_use',500,'شخصي','بناء واحد') returning id",[design])).id;
 const path=ids.engineer+'/'+design+'/original';await db.query("insert into storage.objects(bucket_id,name) values('design-originals',$1)",[path]);await db.query("insert into design_files(design_id,engineer_id,path,original_filename,file_size,file_hash) values($1,$2,$3,'plan.pdf',100,$4)",[design,ids.engineer,path,'a'.repeat(64)]);
 });
 await as('admin',()=>db.query("select admin_action('design',$1,'approved')",[design]));
 await as('customer',async()=>{order=(await scalar('select order_design($1) as id',[license])).id;assert.equal((await db.query('select * from design_files')).rows.length,0);await denied("select request_action('order',$1,'paid')",[order]);await denied("select request_action('order',$1,'completed')",[order]);});
 await as('engineer',async()=>{await db.query("select request_action('order',$1,'accepted')",[order]);await db.query("select request_action('order',$1,'in_progress')",[order]);await db.query("select request_action('order',$1,'delivered')",[order]);});
 await as('customer',async()=>{assert.equal((await db.query('select * from design_files')).rows.length,1);assert.equal((await db.query("select * from storage.objects where bucket_id='design-originals'")).rows.length,1);await db.query("select request_action('order',$1,'completed')",[order]);});
 await as('stranger',async()=>assert.equal((await db.query('select * from design_files')).rows.length,0));
});
await ok('reviews require completed own order and cannot be duplicated',async()=>{
 await as('stranger',()=>denied("insert into reviews(reviewer_id,engineer_id,order_id,rating,comment) values($1,$2,$3,5,'تقييم')",[ids.stranger,ids.engineer,order]));
 await as('customer',async()=>{await db.query("insert into reviews(reviewer_id,engineer_id,order_id,rating,comment) values($1,$2,$3,5,'تقييم')",[ids.customer,ids.engineer,order]);await denied("insert into reviews(reviewer_id,engineer_id,order_id,rating,comment) values($1,$2,$3,5,'مكرر')",[ids.customer,ids.engineer,order]);});
});
await ok('notifications are real and cannot be forged',()=>as('customer',async()=>{assert.ok((await db.query('select * from notifications')).rows.length>0);await denied("insert into notifications(user_id,title,body,type) values($1,'fake','fake','fake')",[ids.customer]);}));
await ok('suspended accounts lose access and cannot unsuspend themselves',async()=>{
 await as('admin',()=>db.query("select admin_action('user',$1,'suspend')",[ids.customer]));
 await as('customer',async()=>{assert.equal((await db.query('select * from documents')).rows.length,0);await denied('update profiles set suspended=false');await denied("select choose_role('engineer')");});
 await as('admin',()=>db.query("select admin_action('user',$1,'unsuspend')",[ids.customer]));
});
await ok('RLS enabled on every app table and all storage buckets private',async()=>{
 const rows=(await db.query("select relname,relrowsecurity from pg_class join pg_namespace n on n.oid=relnamespace where n.nspname='public' and relkind='r'")).rows;
 assert.ok(rows.length>=25);assert.ok(rows.every(r=>r.relrowsecurity));assert.equal((await db.query('select * from storage.buckets where public')).rows.length,0);
});
console.log(`Security integration: ${tests} groups passed.`);await db.close();
