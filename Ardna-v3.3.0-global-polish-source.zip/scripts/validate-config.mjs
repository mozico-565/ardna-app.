const required=['VITE_SUPABASE_URL','VITE_SUPABASE_ANON_KEY','VITE_PUBLIC_APP_URL'];
const missing=required.filter(k=>!process.env[k]);
if(missing.length){console.error('Configure repository Actions secrets/variables before publishing: '+missing.join(', '));process.exit(1)}
for(const key of ['VITE_SUPABASE_URL','VITE_PUBLIC_APP_URL']){if(new URL(process.env[key]).protocol!=='https:')throw new Error(key+' must be HTTPS')}
const key=process.env.VITE_SUPABASE_ANON_KEY;
if(key.startsWith('sb_secret_'))throw new Error('A secret key must never be bundled into the app.');
if(key.split('.').length===3){const payload=JSON.parse(Buffer.from(key.split('.')[1],'base64url').toString());if(payload.role!=='anon')throw new Error('Only the anon key is allowed in the frontend.')}
console.log('Public application configuration present; secret values were not printed.');
