const sharp = require('sharp');
const path = require('path');
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'public/brand-v22.png');
(async () => {
  for (const [density,size] of Object.entries({ldpi:36,mdpi:48,hdpi:72,xhdpi:96,xxhdpi:144,xxxhdpi:192})) {
    for (const name of ['ic_launcher','ic_launcher_round']) {
      await sharp(source).resize(size,size).png().toFile(path.join(root,`android/app/src/main/res/mipmap-${density}/${name}.png`));
    }
  }
  await sharp(source).resize(1024,1024).png().toFile(path.join(root,'ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png'));
  await sharp(source).resize(192,192).png().toFile(path.join(root,'public/icon-192.png'));
  await sharp(source).resize(512,512).png().toFile(path.join(root,'public/icon-512.png'));
  await sharp(source).resize(180,180).png().toFile(path.join(root,'public/apple-touch-icon.png'));
})();
