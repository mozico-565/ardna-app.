import React,{useEffect,useState} from 'react';
import {Session} from '@supabase/supabase-js';
import {App as NativeApp} from '@capacitor/app';
import {Browser} from '@capacitor/browser';
import {Home,Search,Building2,UserRound,Bell,ChevronRight,MessageCircle} from 'lucide-react';
import {check,configured,db,rpc,Row,supabase} from './lib/backend';
import {Action,Brand,DataForm,Empty,LoadState,Skeleton,ToastHost,useLoad} from './components/ui';
import {Auth} from './features/Auth';
import {Catalog} from './features/Catalog';
import {Editor} from './features/Editor';
import {Details} from './features/Details';
import {Engineers,EngineerProfile,EngineerSetup,Onboarding} from './features/Engineers';
import {Requests,CustomRequest} from './features/Requests';
import {Chat} from './features/Chat';
import {Admin,Dashboard,Documents,Notifications,Services} from './features/Workspace';
import './app.css';
import {useNavigation,useViewport,clearViews,friendlyError} from './lib/ux';

export function App(){
 const[session,setSession]=useState<Session|null>(null),[loading,setLoading]=useState(true),[error,setError]=useState(''),[recovery,setRecovery]=useState(false);
 const {route,go,back}=useNavigation();useViewport();
 const[dark,setDark]=useState(()=>localStorage.getItem('ardna-theme')==='dark');
 useEffect(()=>{localStorage.setItem('ardna-theme',dark?'dark':'light');document.documentElement.style.colorScheme=dark?'dark':'light';document.documentElement.dataset.theme=dark?'dark':'light';document.querySelector('meta[name="theme-color"]')?.setAttribute('content',dark?'#10231d':'#f6f4ed')},[dark]);

 useEffect(()=>{
  if(!supabase){setLoading(false);return}
  let live=true;supabase.auth.getSession().then(r=>{if(live){if(r.error)setError(r.error.message);setSession(r.data.session);setLoading(false)}}).catch(e=>{if(live){setError(e.message);setLoading(false)}});
  const sub=supabase.auth.onAuthStateChange((event,s)=>{setSession(s);if(event==='SIGNED_OUT')clearViews();if(event==='PASSWORD_RECOVERY')setRecovery(true)}).data.subscription;
  const listener=NativeApp.addListener('appUrlOpen',async({url})=>{try{const u=new URL(url);if(u.protocol!=='com.ardna.app:'||u.host!=='auth'||u.pathname!=='/callback')return;const code=u.searchParams.get('code');if(code){check(await db().auth.exchangeCodeForSession(code));await Browser.close().catch(()=>{})}}catch(e){setError((e as Error).message)}});
  const state=NativeApp.addListener('appStateChange',({isActive})=>{if(isActive)db().auth.startAutoRefresh();else db().auth.stopAutoRefresh()});
  const back=NativeApp.addListener('backButton',()=>{if(Number(history.state?.ardnaIndex)>0)history.back();else void NativeApp.minimizeApp()});
  return()=>{live=false;sub.unsubscribe();void listener.then(h=>h.remove());void state.then(h=>h.remove());void back.then(h=>h.remove())};
 },[]);

 return <main className={'app '+(dark?'dark':'')} dir="rtl"><section className="page shell"><div className="content">
 <ToastHost/><header><button className="icon-btn" aria-label="رجوع" onClick={back}><ChevronRight/></button><button className="header-home" aria-label="أرضنا — الرئيسية" onClick={()=>go('home')}><Brand className="header-brand"/><b>أرضنا</b></button>{session&&<button className="icon-btn" aria-label="الإشعارات" onClick={()=>go('notifications')}><Bell/></button>}</header>
 {error&&<p role="alert" className="error">{friendlyError(error)}</p>}
 {!configured?<section className="unavailable"><Brand/><h1>أرضنا</h1><p>الخدمة غير متاحة مؤقتًا. يرجى المحاولة لاحقًا.</p><small>الإصدار 3.0.1 • UX</small></section>:loading?<Skeleton variant="form"/>:recovery?<Auth recovery/>:!session?<Guest route={route} go={go}/>:<Workspace key={session.user.id} uid={session.user.id} route={route} go={go} dark={dark} setDark={setDark}/>}
 </div></section></main>;
}
function Guest({route,go}:{route:string,go:(p:string)=>void}){
 const[page,id]=route.split('/');let content:React.ReactNode;
 if(page==='properties'||page==='designs')content=<Catalog key={page} kind={page==='properties'?'property':'design'} uid="" go={go}/>;
 else if((page==='property'||page==='design')&&id)content=<Details key={route} kind={page} id={id} uid="" go={go} match={()=>go('designs')}/>;
 else if(page==='engineers')content=<Engineers go={go}/>;
 else if(page==='engineer'&&id)content=<EngineerProfile id={id} uid="" go={go}/>;
 else content=<Auth/>;
 return <><div className="toolbar">{[['properties','العقارات'],['designs','التصاميم'],['engineers','المهندسون'],['login','تسجيل الدخول']].map(([p,l])=><button key={p} onClick={()=>go(p)}>{l}</button>)}</div>{content}</>;
}
function Workspace({uid,route,go,dark,setDark}:{uid:string,route:string,go:(p:string)=>void,dark:boolean,setDark:(b:boolean)=>void}){
 const q=useLoad(async()=>({profile:check(await db().from('profiles').select('*').eq('id',uid).single()) as Row,roles:check(await db().from('user_roles').select('role').eq('user_id',uid)).map(r=>r.role as string)}),[uid]);
 const[mode,setMode]=useState(localStorage.getItem('ardna-mode')||'customer'),[matching,setMatching]=useState<Record<string,any>>({});
 const roles=q.data?.roles||[],engineer=roles.includes('engineer')&&(mode==='engineer'||!roles.includes('customer'));
 const path=route.split('?')[0],parts=path.split('/'),page=parts[0],id=parts[1];
 function switchMode(next:string){setMode(next);localStorage.setItem('ardna-mode',next);go('home')}
 const engineerQ=useLoad(async()=>page==='engineer-settings'?check(await db().from('engineer_profiles').select('*').eq('user_id',uid).maybeSingle()) as Row|null:null,[page,uid]);
 let content:React.ReactNode=null;
 if(page==='home')content=<Dashboard uid={uid} engineer={engineer} name={q.data?.profile.full_name||''} go={go}/>;
 else if(['properties','map','mine-property'].includes(page))content=<Catalog key={page+'-property'} kind="property" uid={uid} go={go} map={page==='map'} mine={page==='mine-property'}/>;
 else if(['designs','mine-design','matching'].includes(page))content=<Catalog key={page} kind="design" uid={uid} go={go} mine={page==='mine-design'} initial={page==='matching'?matching:{}}/>;
 else if(page==='favorites')content=<><Catalog key={page+'-property'} kind="property" uid={uid} go={go} favorites/><Catalog kind="design" uid={uid} go={go} favorites/></>;
 else if(['property','design'].includes(page)&&id)content=<Details key={route} kind={page as 'property'|'design'} id={id} uid={uid} go={go} match={v=>{setMatching(v);go('matching')}}/>;
 else if(page==='edit-property'||page==='edit-design')content=page==='edit-design'&&!roles.includes('engineer')?<Empty>أضف ملفًا مهنيًا أولًا من حسابك.</Empty>:<Editor key={route} kind={page==='edit-property'?'property':'design'} id={id} uid={uid} go={go}/>;
 else if(page==='engineers')content=<Engineers go={go}/>;
 else if(page==='engineer'&&id)content=<EngineerProfile id={id} uid={uid} go={go}/>;
 else if(page==='custom'&&id)content=<CustomRequest engineer={id} uid={uid} go={go}/>;
 else if(page==='requests')content=<Requests uid={uid} go={go}/>;
 else if(page==='chat')content=<Chat thread={id} uid={uid} go={go}/>;
 else if(page==='documents')content=<Documents uid={uid}/>;
 else if(page==='notifications')content=<Notifications uid={uid} go={go}/>;
 else if(page==='services')content=<Services uid={uid}/>;
 else if(page==='admin')content=roles.includes('admin')?<Admin go={go}/>:<Empty>هذه الصفحة للإدارة فقط.</Empty>;
 else if(page==='engineer-settings')content=<LoadState query={engineerQ}><EngineerSetup initial={engineerQ.data||undefined} done={()=>{q.reload();go('account')}}/></LoadState>;
 else if(page==='settings')content=<><h1>الإعدادات</h1><section className="settings-row"><label htmlFor="night-mode">الوضع الليلي</label><input id="night-mode" type="checkbox" role="switch" checked={dark} onChange={e=>setDark(e.target.checked)}/></section><p>الإصدار 3.0.1 • UX</p></>;
 else if(page==='account')content=<><h1>حسابي</h1><DataForm key={q.data?.profile.updated_at} initial={q.data?.profile} fields={[{name:'full_name',label:'الاسم الكامل',required:true},{name:'phone',label:'رقم الهاتف',type:'tel'},{name:'city',label:'المدينة'},{name:'country',label:'الدولة'}]} submit={async v=>{check(await db().from('profiles').update({full_name:v.full_name,phone:v.phone,city:v.city,country:v.country}).eq('id',uid));q.reload()}}/><div className="service-list">{roles.includes('engineer')?<><button className="outline" onClick={()=>switchMode('engineer')}>وضع المهندس</button>{roles.includes('customer')?<button className="outline" onClick={()=>switchMode('customer')}>وضع العميل</button>:<Action run={async()=>{await rpc('choose_role',{chosen:'customer'});q.reload();switchMode('customer')}}>إضافة وضع العميل</Action>}</>:<button className="outline" onClick={()=>go('engineer-settings')}>إضافة حساب مهندس</button>}{[['settings','الإعدادات'],['documents','وثائقي'],['services','الدعم والخدمات'],['mine-property','عقاراتي'],['favorites','المفضلة'],['requests','طلباتي']].map(([p,l])=><button className="outline" key={p} onClick={()=>go(p)}>{l}</button>)}{roles.includes('admin')&&<button className="outline" onClick={()=>go('admin')}>لوحة الإدارة</button>}<Action run={async()=>{check(await db().auth.signOut());go('home')}}>تسجيل الخروج</Action></div></>;
 else content=<Empty>الصفحة غير موجودة. استخدم زر الرئيسية.</Empty>;
 return <LoadState query={q}>{!roles.length?<Onboarding done={q.reload}/>:<><div key={route} className="page-transition">{content}</div>{!['edit-property','edit-design','engineer-settings','custom'].includes(page)&&<nav aria-label="التنقل الرئيسي">{[[Home,'home','الرئيسية'],[Search,'properties','العقارات'],[Building2,'designs','التصاميم'],[MessageCircle,'chat','الرسائل'],[UserRound,'account','حسابي']].map(([Icon,p,l])=>{const I=Icon as typeof Home;return <button key={String(p)} aria-current={(page===p||(p==='properties'&&['property','map','mine-property'].includes(page))||(p==='designs'&&['design','matching','mine-design'].includes(page))||(p==='account'&&['settings','documents','services','engineer-settings'].includes(page)))?'page':undefined} className={(page===p||(p==='properties'&&['property','map','mine-property'].includes(page))||(p==='designs'&&['design','matching','mine-design'].includes(page))||(p==='account'&&['settings','documents','services','engineer-settings'].includes(page)))?'active':''} onClick={()=>go(String(p))}><I/><span>{String(l)}</span></button>})}</nav>}</>}</LoadState>;
}
