import {useEffect,useState} from 'react';
import {useViewState} from '../lib/ux';
import {Heart,Share2} from 'lucide-react';
import {db,check,Row,share} from '../lib/backend';
import {Action,Empty,Fields,LoadState,Media,text,useLoad} from '../components/ui';
import {PropertyMap} from '../components/Map';
export type Kind='property'|'design';
export const tableFor=(kind:Kind)=>kind==='property'?'properties':'engineering_designs';
export const imagesFor=(kind:Kind)=>kind==='property'?'property_images':'design_images';
export function Cards({rows,kind,go,uid=''}:{rows:Row[],kind:Kind,go:(p:string)=>void,uid?:string}) {
 const[favorites,setFavorites]=useState<string[]>([]);const ids=rows.map(r=>r.id).join(',');
 useEffect(()=>{let active=true;if(!uid||!ids){setFavorites([]);return}db().from('favorites').select(kind+'_id').eq('user_id',uid).in(kind+'_id',ids.split(',')).then(r=>{if(active&&!r.error)setFavorites((r.data||[]).map((v:any)=>v[kind+'_id']))});return()=>{active=false}},[uid,kind,ids]);
 return rows.length?<div className="property-list">{rows.map(r=><article className="listing-card" key={r.id}><button className="property-row" onClick={()=>go(`${kind}/${r.id}`)}><Media bucket={kind==='property'?'property-images':'design-previews'} path={r[imagesFor(kind)]?.[0]?.thumbnail_path} alt={r.title}/><div><b>{r.title}</b><strong className="card-price">{Number(r.price).toLocaleString('ar')} {r.currency}</strong><span>{r.city||text(r.category)} {r.state||''}</span><small>{r.area||r.building_area||'—'} {r.area_unit==='feddan'?'فدان':'م²'} • {text(r.status)}</small></div><span aria-hidden>‹</span></button><div className="card-tools">{uid&&<Action run={async()=>{const exists=favorites.includes(r.id);if(exists)check(await db().from('favorites').delete().eq('user_id',uid).eq(kind+'_id',r.id));else check(await db().from('favorites').insert({user_id:uid,[kind+'_id']:r.id}));setFavorites(v=>exists?v.filter(id=>id!==r.id):[...v,r.id])}}><Heart size={17} fill={favorites.includes(r.id)?'currentColor':'none'}/>{favorites.includes(r.id)?'محفوظ':'حفظ'}</Action>}<Action run={()=>share(kind+'/'+r.id,r.title)} success="تمت المشاركة أو نسخ الرابط."><Share2 size={17}/>مشاركة</Action></div></article>)}</div>:<Empty action={()=>go(kind==='property'?'properties':'designs')} actionLabel="استكشاف الإعلانات">لا توجد إعلانات هنا بعد. يمكنك تصفح بقية الأقسام.</Empty>;
}
export function Catalog({kind,go,uid,mine=false,favorites=false,map=false,initial={}}:{kind:Kind,go:(p:string)=>void,uid:string,mine?:boolean,favorites?:boolean,map?:boolean,initial?:Record<string,any>}){
 const cacheKey=[uid,kind,mine,favorites,map,JSON.stringify(initial)].join(':');
 const[f,setF]=useViewState<Record<string,any>>(cacheKey+':fields',initial),[applied,setApplied]=useViewState(cacheKey+':applied',initial),[page,setPage]=useViewState(cacheKey+':page',0);
 const q=useLoad(async()=>{
  let query=db().from(tableFor(kind)).select(`*,${imagesFor(kind)}(thumbnail_path)`,{count:'exact'});
  if(mine)query=query.eq(kind==='property'?'owner_id':'engineer_id',uid);else query=query.eq('status','approved');
  if(favorites){const fav=check(await db().from('favorites').select(kind+'_id').eq('user_id',uid));query=query.in('id',fav.map((r:any)=>r[kind+'_id']).filter(Boolean));}
  const term=String(applied.search||'').replace(/[^\p{L}\p{N}\s]/gu,' ').trim();
  if(term)query=kind==='property'?query.or(`title.ilike.%${term}%,state.ilike.%${term}%,city.ilike.%${term}%,district.ilike.%${term}%`):query.ilike('title',`%${term}%`);
  for(const k of ['category','listing_type','state','city','architectural_style'])if(applied[k])query=query.eq(k,applied[k]);
  for(const [key,col,op] of [['min_price','price','gte'],['max_price','price','lte'],['min_area',kind==='property'?'area':'building_area','gte'],['max_area',kind==='property'?'area':'building_area','lte'],['land_width','min_land_width','lte'],['land_length','min_land_length','lte'],['land_area','recommended_land_area','lte']] as const){if(applied[key]!=null&&applied[key]!=='')query=query[op](col,applied[key]);}
  if(applied.floors)query=query.eq('floors',applied.floors);
  query=applied.sort==='price_low'?query.order('price'):applied.sort==='price_high'?query.order('price',{ascending:false}):applied.land_area?query.order('recommended_land_area',{ascending:false}):query.order('created_at',{ascending:applied.sort==='oldest'});
  const r=await query.range(page*12,page*12+11);check(r);return {rows:r.data as Row[],count:r.count||0};
 },[kind,mine,favorites,uid,applied,page]);
 return <><h1>{mine?(kind==='property'?'عقاراتي':'تصاميمي'):favorites?'المفضلة':kind==='property'?'استكشف العقارات':'سوق التصاميم'}</h1>
 <form className="card filters-form" onSubmit={e=>{e.preventDefault();setApplied({...f});setPage(0)}}><Fields values={f} set={setF} fields={[{name:'search',label:'البحث'},{name:'category',label:'النوع',options:kind==='property'?['land','house','apartment','commercial','farm']:['house','apartment','commercial','farm']},...(kind==='property'?[{name:'listing_type',label:'العرض',options:['sale','rent','not_listed']},{name:'state',label:'الولاية'},{name:'city',label:'المدينة'}]:[{name:'architectural_style',label:'الطراز المعماري'}]),{name:'min_price',label:'أقل سعر',type:'number',min:0},{name:'max_price',label:'أعلى سعر',type:'number',min:0},{name:'min_area',label:'أقل مساحة',type:'number',min:0},{name:'max_area',label:'أعلى مساحة',type:'number',min:0}]}/>
 {kind==='design'&&<details open={Boolean(initial.land_area)}><summary>تصاميم تناسب أرضك</summary><Fields values={f} set={setF} fields={[{name:'land_width',label:'عرض الأرض بالمتر',type:'number',min:1},{name:'land_length',label:'طول الأرض بالمتر',type:'number',min:1},{name:'land_area',label:'مساحة الأرض بالمتر المربع',type:'number',min:1},{name:'floors',label:'الطوابق',type:'number',min:1}]}/></details>}
 <label>الترتيب<select value={f.sort||'newest'} onChange={e=>setF({...f,sort:e.target.value})}><option value="newest">الأحدث</option><option value="oldest">الأقدم</option><option value="price_low">الأقل سعرًا</option><option value="price_high">الأعلى سعرًا</option></select></label><button className="primary">بحث</button></form>
 <LoadState query={q}>{map&&<><PropertyMap rows={q.data?.rows} onSelect={id=>go('property/'+id)}/><small>الخريطة تعرض نتائج الصفحة الحالية. غيّر البحث أو الصفحة لاستكشاف بقية العقارات.</small></>}{q.data?.rows.length?<Cards rows={q.data.rows} kind={kind} go={go} uid={uid}/>:<Empty title={favorites?'المفضلة فارغة':mine?(kind==='property'?'لم تضف عقارات بعد':'لم تضف تصاميم بعد'):'لا توجد نتائج مطابقة'} action={()=>{if(favorites)go(kind==='property'?'properties':'designs');else if(mine)go('edit-'+kind);else{setF({});setApplied({});setPage(0)}}} actionLabel={favorites?'استكشاف الإعلانات':mine?'إضافة إعلان':'مسح الفلاتر'}>{favorites?'احفظ ما يعجبك لتجده هنا بسهولة.':'يمكنك إضافة إعلان أو تغيير البحث للعثور على نتائج أخرى.'}</Empty>}<div className="toolbar"><button disabled={page===0} onClick={()=>setPage(p=>p-1)}>السابق</button><span>{page+1} • {q.data?.count||0} نتيجة</span><button disabled={(page+1)*12>=(q.data?.count||0)} onClick={()=>setPage(p=>p+1)}>التالي</button></div></LoadState>
 </>;
}
