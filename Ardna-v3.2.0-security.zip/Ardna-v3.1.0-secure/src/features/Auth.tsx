import {useState} from 'react';
import {Capacitor} from '@capacitor/core';
import {Browser} from '@capacitor/browser';
import {db,check,authRedirect} from '../lib/backend';
import {Action,Brand,DataForm} from '../components/ui';
export function Auth({recovery=false}:{recovery?:boolean}) {
 const[mode,setMode]=useState(recovery?'reset':'login'),[message,setMessage]=useState('');
 const titles:Record<string,string>={login:'تسجيل الدخول',signup:'إنشاء حساب',forgot:'استعادة كلمة المرور',reset:'كلمة مرور جديدة'};
 return <section className="login"><Brand className="login-brand"/><h1>{titles[mode]}</h1>
 <DataForm key={mode} fields={[...(mode==='signup'?[{name:'full_name',label:'الاسم الكامل',required:true}]:[]),...(mode!=='reset'?[{name:'email',label:'البريد الإلكتروني',type:'email',required:true}]:[]),...(!['forgot'].includes(mode)?[{name:'password',label:'كلمة المرور (8 أحرف على الأقل)',type:'password',required:true}]:[])]} label={titles[mode]} submit={async v=>{
  setMessage(''); if(v.password&&v.password.length<8)throw new Error('استخدم كلمة مرور من 8 أحرف على الأقل.');
  if(mode==='login')check(await db().auth.signInWithPassword({email:v.email,password:v.password}));
  if(mode==='signup'){check(await db().auth.signUp({email:v.email,password:v.password,options:{data:{full_name:v.full_name},emailRedirectTo:authRedirect()}}));setMessage('راجع بريدك لتأكيد الحساب قبل تسجيل الدخول.');}
  if(mode==='forgot'){check(await db().auth.resetPasswordForEmail(v.email,{redirectTo:authRedirect()}));setMessage('إذا كان البريد مسجّلًا، ستصلك رسالة الاستعادة.');}
  if(mode==='reset'){check(await db().auth.updateUser({password:v.password}));await db().auth.signOut();location.hash='/';location.reload();}
 }}/>{message&&<p role="status">{message}</p>}
 {mode==='login'&&import.meta.env.VITE_GOOGLE_AUTH_ENABLED==='true'&&<Action run={async()=>{const result=check(await db().auth.signInWithOAuth({provider:'google',options:{redirectTo:authRedirect(),skipBrowserRedirect:Capacitor.isNativePlatform()}}));if(Capacitor.isNativePlatform()&&result.url)await Browser.open({url:result.url})}}>المتابعة باستخدام Google</Action>}
 {!recovery&&<div className="toolbar">{Object.entries(titles).filter(([k])=>k!==mode&&k!=='reset').map(([k,t])=><button key={k} onClick={()=>{setMode(k);setMessage('')}}>{t}</button>)}</div>}
 </section>;
}
