// src/App.tsx
import { useEffect as useEffect7, useState as useState12 } from "react";

// fixture:@capacitor/app
var App = { addListener: async () => ({ remove() {
} }), minimizeApp() {
} };

// fixture:@capacitor/browser
var Browser = { close: async () => {
}, open: async () => {
} };

// src/App.tsx
import { Home, Search, Building2 as Building22, UserRound, Bell, ChevronRight as ChevronRight2, MessageCircle } from "lucide-react";

// scripts/ux-tests/backend.ts
var state = { roles: [], tables: {}, calls: [], session: null, listener: null, fail: false };
state.tables.properties = [{ id: "property-test", owner_id: "owner-test", title: "\u0639\u0642\u0627\u0631 \u0627\u062E\u062A\u0628\u0627\u0631 \u0645\u0639\u0632\u0648\u0644", city: "\u0627\u0644\u062E\u0631\u0637\u0648\u0645", state: "\u0627\u0644\u062E\u0631\u0637\u0648\u0645", area: 300, area_unit: "m2", price: 100, currency: "SDG", status: "approved", category: "land", listing_type: "sale", description: "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u062E\u062A\u0628\u0627\u0631 \u063A\u064A\u0631 \u0645\u0646\u0634\u0648\u0631\u0629", created_at: "2026-09-13", property_images: [] }];
function reset() {
  state.roles = [];
  state.session = null;
  state.calls = [];
  state.tables.favorites = [];
  state.tables.profiles = [{ id: "user-test", full_name: "\u0645\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0627\u062E\u062A\u0628\u0627\u0631" }];
  state.tables.user_roles = [];
  state.fail = false;
}
reset();
var Query = class {
  constructor(table) {
    this.table = table;
  }
  filters = [];
  op = "select";
  payload;
  one = false;
  head = false;
  select(_ = "*", opts = {}) {
    this.head = opts.head;
    return this;
  }
  eq(k, v) {
    this.filters.push((r) => r[k] === v);
    return this;
  }
  in(k, v) {
    this.filters.push((r) => v.includes(r[k]));
    return this;
  }
  ilike() {
    return this;
  }
  or() {
    return this;
  }
  gte() {
    return this;
  }
  lte() {
    return this;
  }
  order() {
    return this;
  }
  range() {
    return this;
  }
  limit() {
    return this;
  }
  single() {
    this.one = true;
    return this;
  }
  maybeSingle() {
    this.one = true;
    return this;
  }
  insert(v) {
    this.op = "insert";
    this.payload = v;
    return this;
  }
  update(v) {
    this.op = "update";
    this.payload = v;
    return this;
  }
  upsert(v) {
    this.op = "insert";
    this.payload = v;
    return this;
  }
  delete() {
    this.op = "delete";
    return this;
  }
  then(resolve, reject) {
    return Promise.resolve().then(() => {
      state.calls.push(this.table + ":" + this.op);
      if (state.fail) return { data: null, error: { message: "Failed to fetch" } };
      const table = state.tables[this.table] ?? (state.tables[this.table] = []);
      let rows = table.filter((r) => this.filters.every((f) => f(r)));
      if (this.op === "insert") {
        const r = { id: this.table + "-new", created_at: (/* @__PURE__ */ new Date()).toISOString(), status: "draft", ...this.payload };
        if (this.table === "engineering_designs") r.design_images = [];
        table.push(r);
        rows = [r];
      }
      if (this.op === "update") rows.forEach((r) => Object.assign(r, this.payload));
      if (this.op === "delete") state.tables[this.table] = table.filter((r) => !rows.includes(r));
      return { data: this.head ? null : this.one ? rows[0] || null : rows, error: null, count: rows.length };
    }).then(resolve, reject);
  }
};
function emit() {
  state.listener?.("SIGNED_IN", state.session);
}
var supabase = { auth: { getSession: async () => ({ data: { session: state.session }, error: null }), onAuthStateChange: (fn) => {
  state.listener = fn;
  return { data: { subscription: { unsubscribe() {
    state.listener = null;
  } } } };
}, signUp: async () => {
  state.calls.push("auth:signup");
  state.session = { user: { id: "user-test" } };
  emit();
  return { data: { session: state.session }, error: null };
}, signInWithPassword: async () => {
  state.session = { user: { id: "user-test" } };
  emit();
  return { data: { session: state.session }, error: null };
}, signOut: async () => {
  state.session = null;
  state.listener?.("SIGNED_OUT", null);
  return { error: null };
}, startAutoRefresh() {
}, stopAutoRefresh() {
}, exchangeCodeForSession: async () => ({ error: null }), resetPasswordForEmail: async () => ({ error: null }), updateUser: async () => ({ error: null }) }, from: (table) => new Query(table), storage: { from: () => ({ remove: async () => ({ error: null }) }) } };
var configured = true;
function db() {
  return supabase;
}
function check(r) {
  if (r.error) throw Error(r.error.message);
  return r.data;
}
async function rpc(name, args) {
  state.calls.push("rpc:" + name);
  if (name === "choose_role") {
    state.roles.push(args.chosen);
    state.tables.user_roles.push({ user_id: "user-test", role: args.chosen });
    if (args.chosen === "engineer") state.tables.engineer_profiles = [{ user_id: "user-test", verification_status: "pending", ...args.details }];
    return null;
  }
  if (name === "start_conversation") {
    state.tables.conversations = [{ id: "thread-test", created_at: "2026-09-13" }];
    return "thread-test";
  }
  if (name === "listing_action") {
    const row = state.tables.engineering_designs.find((r) => r.id === args.target);
    if (row) row.status = "pending";
  }
  return 1;
}
var authRedirect = () => "";
var share = async () => {
  state.calls.push("share");
};

// src/components/ui.tsx
import { useEffect as useEffect2, useState as useState2, useRef as useRef2, useId } from "react";
import { Building2, Eye, EyeOff, X, ChevronLeft, ChevronRight } from "lucide-react";

// src/lib/ux.ts
import { useEffect, useRef, useState } from "react";
function friendlyError(error) {
  const message = typeof error === "string" ? error : error?.message || "";
  if (/invalid login credentials/i.test(message)) return "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629.";
  if (/email not confirmed/i.test(message)) return "\u0623\u0643\u062F \u0628\u0631\u064A\u062F\u0643 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0645\u0646 \u0631\u0633\u0627\u0644\u0629 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0623\u0648\u0644\u064B\u0627.";
  if (/already registered|already exists|duplicate key/i.test(message)) return "\u0647\u0630\u0647 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0645\u0633\u062C\u0644\u0629 \u0628\u0627\u0644\u0641\u0639\u0644. \u0631\u0627\u062C\u0639\u0647\u0627 \u0648\u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627.";
  if (/rate limit|too many/i.test(message)) return "\u0637\u0644\u0628\u0627\u062A \u0643\u062B\u064A\u0631\u0629 \u062E\u0644\u0627\u0644 \u0648\u0642\u062A \u0642\u0635\u064A\u0631. \u0627\u0646\u062A\u0638\u0631 \u0642\u0644\u064A\u0644\u064B\u0627 \u062B\u0645 \u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627.";
  if (/fetch|network|timeout|connection/i.test(message)) return "\u062A\u0639\u0630\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644. \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A \u062B\u0645 \u0623\u0639\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629.";
  if (/row.level|permission|not authorized|jwt|expired/i.test(message)) return "\u0644\u0627 \u062A\u062A\u0648\u0641\u0631 \u0635\u0644\u0627\u062D\u064A\u0629 \u0644\u0647\u0630\u0647 \u0627\u0644\u0639\u0645\u0644\u064A\u0629. \u062A\u062D\u0642\u0642 \u0645\u0646 \u062A\u0633\u062C\u064A\u0644 \u062F\u062E\u0648\u0644\u0643.";
  if (/constraint|null value|invalid input/i.test(message)) return "\u0631\u0627\u062C\u0639 \u0627\u0644\u062D\u0642\u0648\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629 \u0648\u0627\u0644\u0642\u064A\u0645 \u0627\u0644\u0645\u062F\u062E\u0644\u0629.";
  if (/storage|bucket|upload/i.test(message)) return "\u062A\u0639\u0630\u0631 \u0631\u0641\u0639 \u0623\u0648 \u0641\u062A\u062D \u0627\u0644\u0645\u0644\u0641. \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0648\u0623\u0639\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629.";
  return /[\u0600-\u06ff]/.test(message) ? message : "\u062A\u0639\u0630\u0631\u062A \u0627\u0644\u0639\u0645\u0644\u064A\u0629. \u062D\u0627\u0648\u0644 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649 \u0628\u0639\u062F \u0642\u0644\u064A\u0644.";
}
var guards = /* @__PURE__ */ new Map();
function canLeave() {
  return ![...guards.values()].some((g) => g()) || window.confirm("\u0644\u062F\u064A\u0643 \u062A\u063A\u064A\u064A\u0631\u0627\u062A \u063A\u064A\u0631 \u0645\u062D\u0641\u0648\u0638\u0629. \u0647\u0644 \u062A\u0631\u064A\u062F \u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0635\u0641\u062D\u0629\u061F");
}
function useUnsaved(dirty) {
  const current = useRef(dirty);
  current.current = dirty;
  useEffect(() => {
    const id = Symbol();
    guards.set(id, () => current.current);
    const unload = (e) => {
      if (current.current) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", unload);
    return () => {
      guards.delete(id);
      window.removeEventListener("beforeunload", unload);
    };
  }, []);
  return () => {
    current.current = false;
  };
}
var views = /* @__PURE__ */ new Map();
function useViewState(key, initial) {
  const [state2, setState] = useState(() => views.get(key) ?? initial);
  useEffect(() => {
    views.set(key, state2);
  }, [key, state2]);
  return [state2, setState];
}
function clearViews() {
  views.clear();
}
var positions = /* @__PURE__ */ new Map();
function useNavigation() {
  const initial = () => location.hash.replace(/^#\/?/, "") || "home";
  const [route, setRoute] = useState(initial), current = useRef(route), index = useRef(Number(history.state?.ardnaIndex) || 0), restoring = useRef(false);
  useEffect(() => {
    history.replaceState({ ...history.state, ardnaIndex: index.current }, "");
    history.scrollRestoration = "manual";
    const change = () => {
      if (restoring.current) {
        restoring.current = false;
        return;
      }
      const next = initial();
      if (next === current.current) return;
      const target = Number(history.state?.ardnaIndex);
      if (!canLeave()) {
        if (Number.isFinite(target) && target !== index.current) {
          restoring.current = true;
          history.go(index.current - target);
        } else history.replaceState({ ardnaIndex: index.current }, "", "#/" + current.current);
        return;
      }
      positions.set(current.current, window.scrollY);
      current.current = next;
      index.current = Number.isFinite(target) ? target : index.current + 1;
      history.replaceState({ ...history.state, ardnaIndex: index.current }, "");
      setRoute(next);
    };
    window.addEventListener("hashchange", change);
    window.addEventListener("ardna:navigate", change);
    return () => {
      window.removeEventListener("hashchange", change);
      window.removeEventListener("ardna:navigate", change);
    };
  }, []);
  useEffect(() => {
    let pending = true;
    const restore = () => {
      if (!pending) return;
      const y = positions.get(route) || 0;
      window.scrollTo(0, y);
      if (Math.abs(window.scrollY - y) < 3) pending = false;
    };
    const cancel = () => {
      pending = false;
    };
    const id = requestAnimationFrame(restore);
    window.addEventListener("ardna:content-ready", restore);
    window.addEventListener("wheel", cancel, { passive: true });
    window.addEventListener("touchstart", cancel, { passive: true });
    return () => {
      cancelAnimationFrame(id);
      window.removeEventListener("ardna:content-ready", restore);
      window.removeEventListener("wheel", cancel);
      window.removeEventListener("touchstart", cancel);
    };
  }, [route]);
  const go = (path) => {
    if (path === current.current || !canLeave()) return;
    positions.set(current.current, window.scrollY);
    index.current++;
    history.pushState({ ardnaIndex: index.current }, "", "#/" + path);
    current.current = path;
    setRoute(path);
  };
  const back = () => {
    if (index.current > 0) history.back();
    else go("home");
  };
  return { route, go, back };
}
function useViewport() {
  useEffect(() => {
    const viewport = window.visualViewport;
    const update = () => {
      const height = viewport?.height || window.innerHeight;
      const typing = Boolean(document.activeElement?.matches("input,textarea,select"));
      document.documentElement.style.setProperty("--visible-height", height + "px");
      document.documentElement.classList.toggle("keyboard-open", typing && window.innerHeight - height > 120);
    };
    const focus = () => {
      update();
      requestAnimationFrame(() => {
        if (document.activeElement?.matches("input,textarea,select")) document.activeElement.scrollIntoView({ block: "nearest", behavior: "auto" });
      });
    };
    viewport?.addEventListener("resize", update);
    window.addEventListener("focusin", focus);
    window.addEventListener("focusout", update);
    update();
    return () => {
      viewport?.removeEventListener("resize", update);
      window.removeEventListener("focusin", focus);
      window.removeEventListener("focusout", update);
    };
  }, []);
}
function toast(message, kind = "success") {
  window.dispatchEvent(new CustomEvent("ardna:toast", { detail: { message, kind } }));
}

// fixture:media
var signed = async () => "";
var uploadImages = async () => {
};
var uploadOriginal = async () => {
};
var uploadDocument = async () => {
};
var openPrivateFile = async () => {
};

// src/components/ui.tsx
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var labels = { draft: "\u0645\u0633\u0648\u062F\u0629", pending: "\u0642\u064A\u062F \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629", approved: "\u0645\u0646\u0634\u0648\u0631", rejected: "\u0645\u0631\u0641\u0648\u0636", archived: "\u0645\u0624\u0631\u0634\u0641", sold: "\u062A\u0645 \u0627\u0644\u0628\u064A\u0639", rented: "\u062A\u0645 \u0627\u0644\u062A\u0623\u062C\u064A\u0631", requested: "\u0637\u0644\u0628 \u062C\u062F\u064A\u062F", submitted: "\u0645\u064F\u0631\u0633\u0644", accepted: "\u0645\u0642\u0628\u0648\u0644", awaiting_payment: "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062F\u0641\u0639", paid: "\u0645\u062F\u0641\u0648\u0639", in_discussion: "\u0642\u064A\u062F \u0627\u0644\u0646\u0642\u0627\u0634", in_progress: "\u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630", delivered: "\u062A\u0645 \u0627\u0644\u062A\u0633\u0644\u064A\u0645", completed: "\u0645\u0643\u062A\u0645\u0644", cancelled: "\u0645\u0644\u063A\u064A", disputed: "\u0645\u062A\u0646\u0627\u0632\u0639 \u0639\u0644\u064A\u0647", verified: "\u0645\u0648\u062B\u0651\u0642", unverified: "\u063A\u064A\u0631 \u0645\u0648\u062B\u0651\u0642", land: "\u0623\u0631\u0636", house: "\u0645\u0646\u0632\u0644", apartment: "\u0634\u0642\u0629", commercial: "\u062A\u062C\u0627\u0631\u064A", farm: "\u0632\u0631\u0627\u0639\u064A", sale: "\u0644\u0644\u0628\u064A\u0639", rent: "\u0644\u0644\u0625\u064A\u062C\u0627\u0631", not_listed: "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0636", preview: "\u0645\u0639\u0627\u064A\u0646\u0629", personal_use: "\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0634\u062E\u0635\u064A", purchase_with_modification: "\u0634\u0631\u0627\u0621 \u0645\u0639 \u062A\u0639\u062F\u064A\u0644", full_rights: "\u0643\u0627\u0645\u0644 \u0627\u0644\u062D\u0642\u0648\u0642", commercial_use: "\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u062A\u062C\u0627\u0631\u064A", open: "\u062C\u062F\u064A\u062F", reviewed: "\u062A\u0645\u062A \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629", resolved: "\u062A\u0645\u062A \u0627\u0644\u0645\u0639\u0627\u0644\u062C\u0629" };
var text = (v) => labels[String(v)] || String(v ?? "\u2014");
function Empty({ children, title = "\u0644\u0627 \u062A\u0648\u062C\u062F \u0646\u062A\u0627\u0626\u062C \u062D\u062A\u0649 \u0627\u0644\u0622\u0646", action, actionLabel = "\u0627\u0633\u062A\u0643\u0634\u0641 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A" }) {
  return /* @__PURE__ */ jsxs("section", { className: "empty", children: [
    /* @__PURE__ */ jsx(Building2, { "aria-hidden": "true" }),
    /* @__PURE__ */ jsx("h2", { children: title }),
    /* @__PURE__ */ jsx("p", { children: children || "\u062C\u0631\u0651\u0628 \u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0628\u062D\u062B \u0623\u0648 \u0639\u062F \u0644\u0627\u062D\u0642\u064B\u0627 \u0644\u0644\u0627\u0637\u0644\u0627\u0639 \u0639\u0644\u0649 \u0627\u0644\u062C\u062F\u064A\u062F." }),
    action && /* @__PURE__ */ jsx("button", { className: "outline", onClick: action, children: actionLabel })
  ] });
}
function Skeleton({ variant = "cards" }) {
  return /* @__PURE__ */ jsxs("div", { role: "status", "aria-label": "\u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0645\u062D\u062A\u0648\u0649", className: "skeletons skeleton-" + variant, children: [
    /* @__PURE__ */ jsx("span", { className: "sr-only", children: "\u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0645\u062D\u062A\u0648\u0649" }),
    [0, 1, 2].map((n) => /* @__PURE__ */ jsxs("div", { className: "skeleton-card", children: [
      /* @__PURE__ */ jsx("i", {}),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("i", {}),
        /* @__PURE__ */ jsx("i", {}),
        /* @__PURE__ */ jsx("i", {})
      ] })
    ] }, n))
  ] });
}
function ToastHost() {
  const [item, setItem] = useState2(null);
  useEffect2(() => {
    let timer;
    const show = (e) => {
      setItem(e.detail);
      clearTimeout(timer);
      timer = setTimeout(() => setItem(null), 5e3);
    };
    window.addEventListener("ardna:toast", show);
    return () => {
      window.removeEventListener("ardna:toast", show);
      clearTimeout(timer);
    };
  }, []);
  return /* @__PURE__ */ jsx("div", { className: "toast-region", "aria-live": "polite", "aria-atomic": "true", children: item && /* @__PURE__ */ jsxs("div", { className: "ux-toast " + item.kind, children: [
    /* @__PURE__ */ jsx("span", { children: item.message }),
    /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u062A\u0646\u0628\u064A\u0647", onClick: () => setItem(null), children: /* @__PURE__ */ jsx(X, {}) })
  ] }) });
}
function useLoad(loader, deps = []) {
  const [data, setData] = useState2(null), [error, setError] = useState2(""), [loading, setLoading] = useState2(true), [resolved, setResolved] = useState2(false), [revision, setRevision] = useState2(0);
  const previous = useRef2("");
  const depKey = JSON.stringify(deps);
  useEffect2(() => {
    let active = true;
    setLoading(true);
    setError("");
    if (previous.current !== depKey) {
      setData(null);
      setResolved(false);
    }
    previous.current = depKey;
    loader().then((v) => {
      if (active) {
        setData(v);
        setResolved(true);
      }
    }).catch((e) => {
      if (active) setError(friendlyError(e));
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [depKey, revision]);
  useEffect2(() => {
    if (!loading && resolved) {
      const id = requestAnimationFrame(() => window.dispatchEvent(new Event("ardna:content-ready")));
      return () => cancelAnimationFrame(id);
    }
  }, [loading, resolved]);
  return { data, error, loading, resolved, reload: () => setRevision((n) => n + 1) };
}
function LoadState({ query, children, variant = "cards" }) {
  if (query.loading && !query.resolved) return /* @__PURE__ */ jsx(Skeleton, { variant });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    query.error && /* @__PURE__ */ jsxs("div", { role: "alert", className: "notice error", children: [
      /* @__PURE__ */ jsx("p", { children: friendlyError(query.error) }),
      /* @__PURE__ */ jsx("button", { className: "outline", onClick: query.reload, children: "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629" })
    ] }),
    query.loading && /* @__PURE__ */ jsx("div", { className: "refresh-progress", role: "status", "aria-label": "\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u062D\u062A\u0648\u0649" }),
    (!query.error || query.resolved) && children
  ] });
}
function Action({ run, children, className = "outline", disabled = false, success }) {
  const [busy, setBusy] = useState2(false), [error, setError] = useState2("");
  const lock = useRef2(false);
  return /* @__PURE__ */ jsxs("div", { className: "action", children: [
    /* @__PURE__ */ jsx("button", { className, disabled: disabled || busy, "aria-busy": busy, onClick: async () => {
      if (lock.current) return;
      lock.current = true;
      setBusy(true);
      setError("");
      try {
        await run();
        if (success) toast(success);
      } catch (e) {
        if (e.name !== "AbortError") {
          const msg = friendlyError(e);
          setError(msg);
          toast(msg, "error");
        }
      } finally {
        lock.current = false;
        setBusy(false);
      }
    }, children: busy ? "\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u0646\u0641\u064A\u0630\u2026" : children }),
    error && /* @__PURE__ */ jsx("small", { role: "alert", className: "error", children: error })
  ] });
}
function FieldControl({ field: f, values, set }) {
  const id = useId(), [visible, setVisible] = useState2(false), [error, setError] = useState2("");
  const validate = (el) => {
    const v = el.validity;
    setError(v.valid ? "" : v.valueMissing ? "\u0647\u0630\u0627 \u0627\u0644\u062D\u0642\u0644 \u0645\u0637\u0644\u0648\u0628." : v.typeMismatch ? "\u0623\u062F\u062E\u0644 \u0642\u064A\u0645\u0629 \u0635\u062D\u064A\u062D\u0629." : v.rangeUnderflow ? `\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 ${f.min}.` : v.rangeOverflow ? `\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0639\u0644\u0649 ${f.max}.` : v.tooShort ? "\u0627\u0633\u062A\u062E\u062F\u0645 8 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644." : "\u0631\u0627\u062C\u0639 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u062F\u062E\u0644\u0629.");
  };
  const shared = { id, name: f.name, required: f.required, value: values[f.name] ?? "", onBlur: (e) => validate(e.currentTarget), onInvalid: (e) => validate(e.currentTarget), "aria-invalid": Boolean(error), "aria-describedby": error ? id + "-error" : void 0 };
  return /* @__PURE__ */ jsxs("div", { className: "field", children: [
    /* @__PURE__ */ jsxs("label", { htmlFor: id, children: [
      f.label,
      f.required && /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: " *" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: f.type === "password" ? "password-wrap" : "", children: [
      f.options ? /* @__PURE__ */ jsxs("select", { ...shared, onChange: (e) => {
        set({ ...values, [f.name]: e.target.value });
        setError("");
      }, children: [
        /* @__PURE__ */ jsx("option", { value: "", children: "\u0627\u062E\u062A\u0631" }),
        f.options.map((v) => /* @__PURE__ */ jsx("option", { value: v, children: text(v) }, v))
      ] }) : f.type === "textarea" ? /* @__PURE__ */ jsx("textarea", { ...shared, maxLength: 8e3, onChange: (e) => {
        set({ ...values, [f.name]: e.target.value });
        setError("");
      } }) : /* @__PURE__ */ jsx("input", { ...shared, type: f.type === "password" ? visible ? "text" : "password" : f.type || "text", inputMode: f.type === "number" ? "decimal" : f.type === "email" ? "email" : f.type === "tel" || f.name === "phone" ? "tel" : void 0, dir: ["email", "password", "tel", "number"].includes(f.type || "") ? "ltr" : void 0, autoComplete: f.type === "password" ? "current-password" : f.type === "email" ? "email" : f.name === "phone" ? "tel" : void 0, minLength: f.type === "password" ? 8 : void 0, min: f.min, max: f.max, step: f.step || "any", maxLength: f.type === "password" ? 128 : 200, onChange: (e) => {
        set({ ...values, [f.name]: f.type === "number" ? e.target.value === "" ? null : Number(e.target.value) : e.target.value });
        setError("");
      } }),
      f.type === "password" && /* @__PURE__ */ jsx("button", { className: "password-toggle", type: "button", "aria-label": visible ? "\u0625\u062E\u0641\u0627\u0621 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" : "\u0625\u0638\u0647\u0627\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631", "aria-pressed": visible, onClick: () => setVisible(!visible), children: visible ? /* @__PURE__ */ jsx(EyeOff, {}) : /* @__PURE__ */ jsx(Eye, {}) })
    ] }),
    error && /* @__PURE__ */ jsx("small", { id: id + "-error", className: "field-error", role: "alert", children: error })
  ] });
}
function Fields({ fields, values, set }) {
  return /* @__PURE__ */ jsx("div", { className: "fields", children: fields.map((f) => /* @__PURE__ */ jsx(FieldControl, { field: f, values, set }, f.name)) });
}
function DataForm({ fields, initial = {}, submit, label = "\u062D\u0641\u0638" }) {
  const [v, set] = useState2(initial), [busy, setBusy] = useState2(false), [error, setError] = useState2(""), [dirty, setDirty] = useState2(false), [step, setStep] = useState2(0);
  const lock = useRef2(false);
  const clear = useUnsaved(dirty);
  const count = fields.length > 6 ? Math.ceil(fields.length / 4) : 1;
  const shown = count > 1 ? fields.slice(step * 4, step * 4 + 4) : fields;
  return /* @__PURE__ */ jsxs("form", { className: "card data-form", onSubmit: async (e) => {
    e.preventDefault();
    if (lock.current) return;
    if (step < count - 1) {
      setStep((s) => s + 1);
      return;
    }
    lock.current = true;
    setBusy(true);
    setError("");
    clear();
    setDirty(false);
    try {
      await submit(v);
      toast("\u062A\u0645\u062A \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0628\u0646\u062C\u0627\u062D.");
    } catch (e2) {
      setDirty(true);
      const msg = friendlyError(e2);
      setError(msg);
      toast(msg, "error");
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }, children: [
    count > 1 && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "\u0627\u0644\u062E\u0637\u0648\u0629 ",
        step + 1,
        " \u0645\u0646 ",
        count
      ] }),
      /* @__PURE__ */ jsx("progress", { "aria-label": "\u062A\u0642\u062F\u0645 \u0627\u0644\u0646\u0645\u0648\u0630\u062C", value: step + 1, max: count })
    ] }),
    /* @__PURE__ */ jsxs("fieldset", { disabled: busy, children: [
      /* @__PURE__ */ jsx(Fields, { fields: shown, values: v, set: (x) => {
        set(x);
        setDirty(true);
      } }),
      /* @__PURE__ */ jsxs("div", { className: "form-actions", children: [
        step > 0 && /* @__PURE__ */ jsx("button", { type: "button", className: "outline", onClick: () => setStep((s) => s - 1), children: "\u0627\u0644\u0633\u0627\u0628\u0642" }),
        /* @__PURE__ */ jsx("button", { className: "primary", disabled: busy, "aria-busy": busy, children: busy ? "\u062C\u0627\u0631\u064D \u0627\u0644\u062D\u0641\u0638\u2026" : step < count - 1 ? "\u0627\u0644\u062A\u0627\u0644\u064A" : label })
      ] })
    ] }),
    error && /* @__PURE__ */ jsxs("p", { role: "alert", className: "error", children: [
      error,
      " \u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0645\u062C\u062F\u062F\u064B\u0627\u061B \u0628\u064A\u0627\u0646\u0627\u062A\u0643 \u0645\u0627 \u0632\u0627\u0644\u062A \u0647\u0646\u0627."
    ] })
  ] });
}
function Brand({ className = "" }) {
  return /* @__PURE__ */ jsx("span", { className: "brand-frame " + className, children: /* @__PURE__ */ jsx("img", { src: "./brand-transparent.svg", alt: "\u0623\u0631\u0636\u0646\u0627", width: "144", height: "144" }) });
}
function Media({ bucket, path, alt }) {
  const [url, setUrl] = useState2(""), [loaded, setLoaded] = useState2(false);
  useEffect2(() => {
    let live = true;
    setUrl("");
    setLoaded(false);
    if (path) signed(bucket, path).then((u) => {
      if (live) setUrl(u);
    }).catch(() => {
    });
    return () => {
      live = false;
    };
  }, [bucket, path]);
  return /* @__PURE__ */ jsxs("div", { className: "media-frame " + (loaded ? "is-loaded" : ""), children: [
    /* @__PURE__ */ jsxs("div", { className: "image-placeholder", children: [
      /* @__PURE__ */ jsx(Brand, {}),
      /* @__PURE__ */ jsx("span", { className: "sr-only", children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0635\u0648\u0631\u0629 \u0645\u062A\u0627\u062D\u0629" })
    ] }),
    url && /* @__PURE__ */ jsx("img", { className: "listing-image", src: url, alt, loading: "lazy", decoding: "async", onLoad: () => setLoaded(true), onError: () => setUrl("") })
  ] });
}
function Gallery({ images, bucket, title }) {
  const [index, setIndex] = useState2(0);
  const ref = useRef2(null);
  const list = [...images].sort((a, b) => (a.position || 0) - (b.position || 0));
  return /* @__PURE__ */ jsxs("section", { className: "gallery-section", "aria-label": "\u0635\u0648\u0631 \u0627\u0644\u0625\u0639\u0644\u0627\u0646", children: [
    /* @__PURE__ */ jsx("div", { ref, className: "gallery", onScroll: () => {
      const el = ref.current;
      if (el) setIndex(Math.round(Math.abs(el.scrollLeft) / el.clientWidth));
    }, children: list.length ? list.map((i, n) => /* @__PURE__ */ jsx("div", { className: "gallery-slide", children: /* @__PURE__ */ jsx(Media, { bucket, path: i.path, alt: `${title} \u2014 \u0635\u0648\u0631\u0629 ${n + 1}` }) }, i.id)) : /* @__PURE__ */ jsx("div", { className: "gallery-slide", children: /* @__PURE__ */ jsx(Media, { bucket, alt: title }) }) }),
    list.length > 1 && /* @__PURE__ */ jsxs("div", { className: "gallery-controls", children: [
      /* @__PURE__ */ jsx("button", { className: "icon-btn", "aria-label": "\u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629", disabled: index === 0, onClick: () => ref.current?.children[index - 1]?.scrollIntoView({ block: "nearest", inline: "start" }), children: /* @__PURE__ */ jsx(ChevronRight, {}) }),
      /* @__PURE__ */ jsxs("span", { "aria-live": "polite", children: [
        index + 1,
        " / ",
        list.length
      ] }),
      /* @__PURE__ */ jsx("button", { className: "icon-btn", "aria-label": "\u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629", disabled: index >= list.length - 1, onClick: () => ref.current?.children[index + 1]?.scrollIntoView({ block: "nearest", inline: "start" }), children: /* @__PURE__ */ jsx(ChevronLeft, {}) })
    ] })
  ] });
}

// src/features/Auth.tsx
import { useState as useState3 } from "react";
import "@capacitor/core";
import { jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
function Auth({ recovery = false }) {
  const [mode, setMode] = useState3(recovery ? "reset" : "login"), [message, setMessage] = useState3("");
  const titles = { login: "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644", signup: "\u0625\u0646\u0634\u0627\u0621 \u062D\u0633\u0627\u0628", forgot: "\u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631", reset: "\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062C\u062F\u064A\u062F\u0629" };
  return /* @__PURE__ */ jsxs2("section", { className: "login", children: [
    /* @__PURE__ */ jsx2(Brand, { className: "login-brand" }),
    /* @__PURE__ */ jsx2("h1", { children: titles[mode] }),
    /* @__PURE__ */ jsx2(DataForm, { fields: [...mode === "signup" ? [{ name: "full_name", label: "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644", required: true }] : [], ...mode !== "reset" ? [{ name: "email", label: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A", type: "email", required: true }] : [], ...!["forgot"].includes(mode) ? [{ name: "password", label: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 (8 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644)", type: "password", required: true }] : []], label: titles[mode], submit: async (v) => {
      setMessage("");
      if (v.password && v.password.length < 8) throw new Error("\u0627\u0633\u062A\u062E\u062F\u0645 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0645\u0646 8 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.");
      if (mode === "login") check(await db().auth.signInWithPassword({ email: v.email, password: v.password }));
      if (mode === "signup") {
        check(await db().auth.signUp({ email: v.email, password: v.password, options: { data: { full_name: v.full_name }, emailRedirectTo: authRedirect() } }));
        setMessage("\u0631\u0627\u062C\u0639 \u0628\u0631\u064A\u062F\u0643 \u0644\u062A\u0623\u0643\u064A\u062F \u0627\u0644\u062D\u0633\u0627\u0628 \u0642\u0628\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644.");
      }
      if (mode === "forgot") {
        check(await db().auth.resetPasswordForEmail(v.email, { redirectTo: authRedirect() }));
        setMessage("\u0625\u0630\u0627 \u0643\u0627\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0645\u0633\u062C\u0651\u0644\u064B\u0627\u060C \u0633\u062A\u0635\u0644\u0643 \u0631\u0633\u0627\u0644\u0629 \u0627\u0644\u0627\u0633\u062A\u0639\u0627\u062F\u0629.");
      }
      if (mode === "reset") {
        check(await db().auth.updateUser({ password: v.password }));
        await db().auth.signOut();
        location.hash = "/";
        location.reload();
      }
    } }, mode),
    message && /* @__PURE__ */ jsx2("p", { role: "status", children: message }),
    mode === "login" && false,
    !recovery && /* @__PURE__ */ jsx2("div", { className: "toolbar", children: Object.entries(titles).filter(([k]) => k !== mode && k !== "reset").map(([k, t]) => /* @__PURE__ */ jsx2("button", { onClick: () => {
      setMode(k);
      setMessage("");
    }, children: t }, k)) })
  ] });
}

// src/features/Catalog.tsx
import { useEffect as useEffect4, useState as useState5 } from "react";
import { Heart, Share2 } from "lucide-react";

// src/components/Map.tsx
import { useEffect as useEffect3, useRef as useRef3, useState as useState4 } from "react";
import L from "leaflet";
import { jsx as jsx3, jsxs as jsxs3 } from "react/jsx-runtime";
function PropertyMap({ rows = [], onSelect, onPoint }) {
  const ref = useRef3(null), map = useRef3(null), [message, setMessage] = useState4(""), [locating, setLocating] = useState4(false);
  const pointRef = useRef3(onPoint), selectRef = useRef3(onSelect);
  pointRef.current = onPoint;
  selectRef.current = onSelect;
  useEffect3(() => {
    const m = L.map(ref.current).setView([15.5, 32.5], 6);
    map.current = m;
    L.tileLayer(import.meta.env.VITE_MAP_TILE_URL || "https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: import.meta.env.VITE_MAP_ATTRIBUTION || "\xA9 OpenStreetMap contributors" }).on("tileerror", () => setMessage("\u062A\u0639\u0630\u0631 \u062A\u062D\u0645\u064A\u0644 \u0628\u0639\u0636 \u0623\u062C\u0632\u0627\u0621 \u0627\u0644\u062E\u0631\u064A\u0637\u0629. \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u062A\u0635\u0627\u0644.")).addTo(m);
    let marker;
    m.on("click", (e) => {
      if (pointRef.current) {
        marker?.remove();
        marker = L.circleMarker(e.latlng, { color: "#003f34", fillOpacity: 0.8 }).addTo(m);
        pointRef.current(e.latlng.lat, e.latlng.lng);
      }
    });
    const ro = new ResizeObserver(() => m.invalidateSize());
    ro.observe(ref.current);
    return () => {
      ro.disconnect();
      m.remove();
      map.current = null;
    };
  }, []);
  useEffect3(() => {
    if (!map.current) return;
    const layer = L.layerGroup().addTo(map.current);
    const points = [];
    rows.forEach((r) => {
      if (r.latitude == null || r.longitude == null) return;
      const p = [r.latitude, r.longitude];
      points.push(p);
      const el = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = r.title;
      el.append(title);
      if (selectRef.current) {
        const b = document.createElement("button");
        b.textContent = "\u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u0639\u0642\u0627\u0631";
        b.onclick = () => selectRef.current?.(r.id);
        el.append(b);
      }
      L.circleMarker(p, { color: "#003f34", fillColor: "#d4b996", fillOpacity: 0.9, radius: 9 }).bindPopup(el).addTo(layer);
    });
    if (points.length) map.current.fitBounds(L.latLngBounds(points), { padding: [30, 30], maxZoom: 14 });
    return () => {
      layer.remove();
    };
  }, [rows]);
  return /* @__PURE__ */ jsxs3("div", { children: [
    /* @__PURE__ */ jsx3("button", { className: "outline", disabled: locating, onClick: () => {
      if (!navigator.geolocation) {
        setMessage("\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0648\u0642\u0639 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.");
        return;
      }
      setLocating(true);
      setMessage("\u062C\u0627\u0631\u064D \u062A\u062D\u062F\u064A\u062F \u0645\u0648\u0642\u0639\u0643\u2026");
      navigator.geolocation.getCurrentPosition((p) => {
        setLocating(false);
        setMessage("\u062A\u0645 \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0648\u0642\u0639.");
        map.current?.setView([p.coords.latitude, p.coords.longitude], 14);
        pointRef.current?.(p.coords.latitude, p.coords.longitude);
      }, (e) => {
        setLocating(false);
        setMessage(e.code === 1 ? "\u0644\u0645 \u062A\u0633\u0645\u062D \u0628\u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639. \u064A\u0645\u0643\u0646\u0643 \u062A\u062D\u062F\u064A\u062F\u0647 \u064A\u062F\u0648\u064A\u064B\u0627." : e.code === 3 ? "\u0627\u0646\u062A\u0647\u062A \u0645\u0647\u0644\u0629 \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0648\u0642\u0639. \u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627." : "\u062A\u0639\u0630\u0631 \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0648\u0642\u0639. \u064A\u0645\u0643\u0646\u0643 \u062A\u062D\u062F\u064A\u062F\u0647 \u064A\u062F\u0648\u064A\u064B\u0627.");
      }, { timeout: 12e3, maximumAge: 6e4 });
    }, children: locating ? "\u062C\u0627\u0631\u064D \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0648\u0642\u0639\u2026" : "\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u0648\u0642\u0639\u064A" }),
    message && /* @__PURE__ */ jsx3("p", { role: "status", children: message }),
    /* @__PURE__ */ jsx3("div", { ref, className: "real-map", "aria-label": "\u062E\u0631\u064A\u0637\u0629 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A \u0641\u064A \u0627\u0644\u0633\u0648\u062F\u0627\u0646" }),
    onPoint && /* @__PURE__ */ jsx3("small", { children: "\u0627\u0636\u063A\u0637 \u0639\u0644\u0649 \u0627\u0644\u062E\u0631\u064A\u0637\u0629 \u0644\u062A\u062D\u062F\u064A\u062F \u0645\u0648\u0642\u0639 \u0627\u0644\u0639\u0642\u0627\u0631." })
  ] });
}

// src/features/Catalog.tsx
import { Fragment as Fragment2, jsx as jsx4, jsxs as jsxs4 } from "react/jsx-runtime";
var tableFor = (kind) => kind === "property" ? "properties" : "engineering_designs";
var imagesFor = (kind) => kind === "property" ? "property_images" : "design_images";
function Cards({ rows, kind, go, uid = "" }) {
  const [favorites, setFavorites] = useState5([]);
  const ids = rows.map((r) => r.id).join(",");
  useEffect4(() => {
    let active = true;
    if (!uid || !ids) {
      setFavorites([]);
      return;
    }
    db().from("favorites").select(kind + "_id").eq("user_id", uid).in(kind + "_id", ids.split(",")).then((r) => {
      if (active && !r.error) setFavorites((r.data || []).map((v) => v[kind + "_id"]));
    });
    return () => {
      active = false;
    };
  }, [uid, kind, ids]);
  return rows.length ? /* @__PURE__ */ jsx4("div", { className: "property-list", children: rows.map((r) => /* @__PURE__ */ jsxs4("article", { className: "listing-card", children: [
    /* @__PURE__ */ jsxs4("button", { className: "property-row", onClick: () => go(`${kind}/${r.id}`), children: [
      /* @__PURE__ */ jsx4(Media, { bucket: kind === "property" ? "property-images" : "design-previews", path: r[imagesFor(kind)]?.[0]?.thumbnail_path, alt: r.title }),
      /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx4("b", { children: r.title }),
        /* @__PURE__ */ jsxs4("strong", { className: "card-price", children: [
          Number(r.price).toLocaleString("ar"),
          " ",
          r.currency
        ] }),
        /* @__PURE__ */ jsxs4("span", { children: [
          r.city || text(r.category),
          " ",
          r.state || ""
        ] }),
        /* @__PURE__ */ jsxs4("small", { children: [
          r.area || r.building_area || "\u2014",
          " ",
          r.area_unit === "feddan" ? "\u0641\u062F\u0627\u0646" : "\u0645\xB2",
          " \u2022 ",
          text(r.status)
        ] })
      ] }),
      /* @__PURE__ */ jsx4("span", { "aria-hidden": true, children: "\u2039" })
    ] }),
    /* @__PURE__ */ jsxs4("div", { className: "card-tools", children: [
      uid && /* @__PURE__ */ jsxs4(Action, { run: async () => {
        const exists = favorites.includes(r.id);
        if (exists) check(await db().from("favorites").delete().eq("user_id", uid).eq(kind + "_id", r.id));
        else check(await db().from("favorites").insert({ user_id: uid, [kind + "_id"]: r.id }));
        setFavorites((v) => exists ? v.filter((id) => id !== r.id) : [...v, r.id]);
      }, children: [
        /* @__PURE__ */ jsx4(Heart, { size: 17, fill: favorites.includes(r.id) ? "currentColor" : "none" }),
        favorites.includes(r.id) ? "\u0645\u062D\u0641\u0648\u0638" : "\u062D\u0641\u0638"
      ] }),
      /* @__PURE__ */ jsxs4(Action, { run: () => share(kind + "/" + r.id, r.title), success: "\u062A\u0645\u062A \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0623\u0648 \u0646\u0633\u062E \u0627\u0644\u0631\u0627\u0628\u0637.", children: [
        /* @__PURE__ */ jsx4(Share2, { size: 17 }),
        "\u0645\u0634\u0627\u0631\u0643\u0629"
      ] })
    ] })
  ] }, r.id)) }) : /* @__PURE__ */ jsx4(Empty, { action: () => go(kind === "property" ? "properties" : "designs"), actionLabel: "\u0627\u0633\u062A\u0643\u0634\u0627\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A", children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0647\u0646\u0627 \u0628\u0639\u062F. \u064A\u0645\u0643\u0646\u0643 \u062A\u0635\u0641\u062D \u0628\u0642\u064A\u0629 \u0627\u0644\u0623\u0642\u0633\u0627\u0645." });
}
function Catalog({ kind, go, uid, mine = false, favorites = false, map = false, initial = {} }) {
  const cacheKey = [uid, kind, mine, favorites, map, JSON.stringify(initial)].join(":");
  const [f, setF] = useViewState(cacheKey + ":fields", initial), [applied, setApplied] = useViewState(cacheKey + ":applied", initial), [page, setPage] = useViewState(cacheKey + ":page", 0);
  const q = useLoad(async () => {
    let query = db().from(tableFor(kind)).select(`*,${imagesFor(kind)}(thumbnail_path)`, { count: "exact" });
    if (mine) query = query.eq(kind === "property" ? "owner_id" : "engineer_id", uid);
    else query = query.eq("status", "approved");
    if (favorites) {
      const fav = check(await db().from("favorites").select(kind + "_id").eq("user_id", uid));
      query = query.in("id", fav.map((r2) => r2[kind + "_id"]).filter(Boolean));
    }
    const term = String(applied.search || "").replace(/[^\p{L}\p{N}\s]/gu, " ").trim();
    if (term) query = kind === "property" ? query.or(`title.ilike.%${term}%,state.ilike.%${term}%,city.ilike.%${term}%,district.ilike.%${term}%`) : query.ilike("title", `%${term}%`);
    for (const k of ["category", "listing_type", "state", "city", "architectural_style"]) if (applied[k]) query = query.eq(k, applied[k]);
    for (const [key, col, op] of [["min_price", "price", "gte"], ["max_price", "price", "lte"], ["min_area", kind === "property" ? "area" : "building_area", "gte"], ["max_area", kind === "property" ? "area" : "building_area", "lte"], ["land_width", "min_land_width", "lte"], ["land_length", "min_land_length", "lte"], ["land_area", "recommended_land_area", "lte"]]) {
      if (applied[key] != null && applied[key] !== "") query = query[op](col, applied[key]);
    }
    if (applied.floors) query = query.eq("floors", applied.floors);
    query = applied.sort === "price_low" ? query.order("price") : applied.sort === "price_high" ? query.order("price", { ascending: false }) : applied.land_area ? query.order("recommended_land_area", { ascending: false }) : query.order("created_at", { ascending: applied.sort === "oldest" });
    const r = await query.range(page * 12, page * 12 + 11);
    check(r);
    return { rows: r.data, count: r.count || 0 };
  }, [kind, mine, favorites, uid, applied, page]);
  return /* @__PURE__ */ jsxs4(Fragment2, { children: [
    /* @__PURE__ */ jsx4("h1", { children: mine ? kind === "property" ? "\u0639\u0642\u0627\u0631\u0627\u062A\u064A" : "\u062A\u0635\u0627\u0645\u064A\u0645\u064A" : favorites ? "\u0627\u0644\u0645\u0641\u0636\u0644\u0629" : kind === "property" ? "\u0627\u0633\u062A\u0643\u0634\u0641 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A" : "\u0633\u0648\u0642 \u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645" }),
    /* @__PURE__ */ jsxs4("form", { className: "card filters-form", onSubmit: (e) => {
      e.preventDefault();
      setApplied({ ...f });
      setPage(0);
    }, children: [
      /* @__PURE__ */ jsx4(Fields, { values: f, set: setF, fields: [{ name: "search", label: "\u0627\u0644\u0628\u062D\u062B" }, { name: "category", label: "\u0627\u0644\u0646\u0648\u0639", options: kind === "property" ? ["land", "house", "apartment", "commercial", "farm"] : ["house", "apartment", "commercial", "farm"] }, ...kind === "property" ? [{ name: "listing_type", label: "\u0627\u0644\u0639\u0631\u0636", options: ["sale", "rent", "not_listed"] }, { name: "state", label: "\u0627\u0644\u0648\u0644\u0627\u064A\u0629" }, { name: "city", label: "\u0627\u0644\u0645\u062F\u064A\u0646\u0629" }] : [{ name: "architectural_style", label: "\u0627\u0644\u0637\u0631\u0627\u0632 \u0627\u0644\u0645\u0639\u0645\u0627\u0631\u064A" }], { name: "min_price", label: "\u0623\u0642\u0644 \u0633\u0639\u0631", type: "number", min: 0 }, { name: "max_price", label: "\u0623\u0639\u0644\u0649 \u0633\u0639\u0631", type: "number", min: 0 }, { name: "min_area", label: "\u0623\u0642\u0644 \u0645\u0633\u0627\u062D\u0629", type: "number", min: 0 }, { name: "max_area", label: "\u0623\u0639\u0644\u0649 \u0645\u0633\u0627\u062D\u0629", type: "number", min: 0 }] }),
      kind === "design" && /* @__PURE__ */ jsxs4("details", { open: Boolean(initial.land_area), children: [
        /* @__PURE__ */ jsx4("summary", { children: "\u062A\u0635\u0627\u0645\u064A\u0645 \u062A\u0646\u0627\u0633\u0628 \u0623\u0631\u0636\u0643" }),
        /* @__PURE__ */ jsx4(Fields, { values: f, set: setF, fields: [{ name: "land_width", label: "\u0639\u0631\u0636 \u0627\u0644\u0623\u0631\u0636 \u0628\u0627\u0644\u0645\u062A\u0631", type: "number", min: 1 }, { name: "land_length", label: "\u0637\u0648\u0644 \u0627\u0644\u0623\u0631\u0636 \u0628\u0627\u0644\u0645\u062A\u0631", type: "number", min: 1 }, { name: "land_area", label: "\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0623\u0631\u0636 \u0628\u0627\u0644\u0645\u062A\u0631 \u0627\u0644\u0645\u0631\u0628\u0639", type: "number", min: 1 }, { name: "floors", label: "\u0627\u0644\u0637\u0648\u0627\u0628\u0642", type: "number", min: 1 }] })
      ] }),
      /* @__PURE__ */ jsxs4("label", { children: [
        "\u0627\u0644\u062A\u0631\u062A\u064A\u0628",
        /* @__PURE__ */ jsxs4("select", { value: f.sort || "newest", onChange: (e) => setF({ ...f, sort: e.target.value }), children: [
          /* @__PURE__ */ jsx4("option", { value: "newest", children: "\u0627\u0644\u0623\u062D\u062F\u062B" }),
          /* @__PURE__ */ jsx4("option", { value: "oldest", children: "\u0627\u0644\u0623\u0642\u062F\u0645" }),
          /* @__PURE__ */ jsx4("option", { value: "price_low", children: "\u0627\u0644\u0623\u0642\u0644 \u0633\u0639\u0631\u064B\u0627" }),
          /* @__PURE__ */ jsx4("option", { value: "price_high", children: "\u0627\u0644\u0623\u0639\u0644\u0649 \u0633\u0639\u0631\u064B\u0627" })
        ] })
      ] }),
      /* @__PURE__ */ jsx4("button", { className: "primary", children: "\u0628\u062D\u062B" })
    ] }),
    /* @__PURE__ */ jsxs4(LoadState, { query: q, children: [
      map && /* @__PURE__ */ jsxs4(Fragment2, { children: [
        /* @__PURE__ */ jsx4(PropertyMap, { rows: q.data?.rows, onSelect: (id) => go("property/" + id) }),
        /* @__PURE__ */ jsx4("small", { children: "\u0627\u0644\u062E\u0631\u064A\u0637\u0629 \u062A\u0639\u0631\u0636 \u0646\u062A\u0627\u0626\u062C \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629. \u063A\u064A\u0651\u0631 \u0627\u0644\u0628\u062D\u062B \u0623\u0648 \u0627\u0644\u0635\u0641\u062D\u0629 \u0644\u0627\u0633\u062A\u0643\u0634\u0627\u0641 \u0628\u0642\u064A\u0629 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A." })
      ] }),
      q.data?.rows.length ? /* @__PURE__ */ jsx4(Cards, { rows: q.data.rows, kind, go, uid }) : /* @__PURE__ */ jsx4(Empty, { title: favorites ? "\u0627\u0644\u0645\u0641\u0636\u0644\u0629 \u0641\u0627\u0631\u063A\u0629" : mine ? kind === "property" ? "\u0644\u0645 \u062A\u0636\u0641 \u0639\u0642\u0627\u0631\u0627\u062A \u0628\u0639\u062F" : "\u0644\u0645 \u062A\u0636\u0641 \u062A\u0635\u0627\u0645\u064A\u0645 \u0628\u0639\u062F" : "\u0644\u0627 \u062A\u0648\u062C\u062F \u0646\u062A\u0627\u0626\u062C \u0645\u0637\u0627\u0628\u0642\u0629", action: () => {
        if (favorites) go(kind === "property" ? "properties" : "designs");
        else if (mine) go("edit-" + kind);
        else {
          setF({});
          setApplied({});
          setPage(0);
        }
      }, actionLabel: favorites ? "\u0627\u0633\u062A\u0643\u0634\u0627\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A" : mine ? "\u0625\u0636\u0627\u0641\u0629 \u0625\u0639\u0644\u0627\u0646" : "\u0645\u0633\u062D \u0627\u0644\u0641\u0644\u0627\u062A\u0631", children: favorites ? "\u0627\u062D\u0641\u0638 \u0645\u0627 \u064A\u0639\u062C\u0628\u0643 \u0644\u062A\u062C\u062F\u0647 \u0647\u0646\u0627 \u0628\u0633\u0647\u0648\u0644\u0629." : "\u064A\u0645\u0643\u0646\u0643 \u0625\u0636\u0627\u0641\u0629 \u0625\u0639\u0644\u0627\u0646 \u0623\u0648 \u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0628\u062D\u062B \u0644\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0646\u062A\u0627\u0626\u062C \u0623\u062E\u0631\u0649." }),
      /* @__PURE__ */ jsxs4("div", { className: "toolbar", children: [
        /* @__PURE__ */ jsx4("button", { disabled: page === 0, onClick: () => setPage((p) => p - 1), children: "\u0627\u0644\u0633\u0627\u0628\u0642" }),
        /* @__PURE__ */ jsxs4("span", { children: [
          page + 1,
          " \u2022 ",
          q.data?.count || 0,
          " \u0646\u062A\u064A\u062C\u0629"
        ] }),
        /* @__PURE__ */ jsx4("button", { disabled: (page + 1) * 12 >= (q.data?.count || 0), onClick: () => setPage((p) => p + 1), children: "\u0627\u0644\u062A\u0627\u0644\u064A" })
      ] })
    ] })
  ] });
}

// src/features/Editor.tsx
import { useRef as useRef4, useState as useState6 } from "react";
import { Fragment as Fragment3, jsx as jsx5, jsxs as jsxs5 } from "react/jsx-runtime";
var number = (name, label, min = 0) => ({ name, label, type: "number", min, required: true });
function Editor({ kind, id, uid, go }) {
  const q = useLoad(async () => id ? check(await db().from(tableFor(kind)).select(`*,${imagesFor(kind)}(*)`).eq("id", id).single()) : null, [kind, id]);
  return /* @__PURE__ */ jsx5(LoadState, { query: q, children: /* @__PURE__ */ jsx5(EditorForm, { kind, existing: q.data, uid, go }) });
}
function EditorForm({ kind, existing, uid, go }) {
  const [id, setId] = useState6(existing?.id), [step, setStep] = useState6(0), [v, setV] = useState6(existing || { currency: "SDG", area_unit: "m2", category: "house", listing_type: "sale", floors: 1, bedrooms: 0, bathrooms: 0 }), [files, setFiles] = useState6([]), [original, setOriginal] = useState6(null), [busy, setBusy] = useState6(false), [error, setError] = useState6("");
  const [license, setLicense] = useState6({ type: "personal_use", price: 0, description: "", allowed_usage: "" }), [sentFiles, setSentFiles] = useState6(false);
  const saved = useRef4(JSON.stringify(v));
  const lock = useRef4(false);
  const clear = useUnsaved(JSON.stringify(v) !== saved.current || files.length > 0 || Boolean(original) || Boolean(license.description));
  const property = kind === "property";
  const steps = property ? ["\u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629", "\u0646\u0648\u0639 \u0627\u0644\u0639\u0642\u0627\u0631", "\u0627\u0644\u0633\u0639\u0631 \u0648\u0627\u0644\u0645\u0633\u0627\u062D\u0629", "\u0627\u0644\u0645\u0648\u0642\u0639", "\u0627\u0644\u0635\u0648\u0631", "\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0625\u0636\u0627\u0641\u064A\u0629", "\u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629", "\u0627\u0644\u0625\u0631\u0633\u0627\u0644"] : ["\u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629", "\u0646\u0648\u0639 \u0627\u0644\u0645\u0628\u0646\u0649", "\u0627\u0644\u0623\u0628\u0639\u0627\u062F \u0648\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A", "\u0635\u0648\u0631 \u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629", "\u0627\u0644\u0633\u0639\u0631", "\u0627\u0644\u062A\u0631\u0627\u062E\u064A\u0635 \u0648\u0627\u0644\u0645\u0644\u0641\u0627\u062A", "\u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629", "\u0627\u0644\u0625\u0631\u0633\u0627\u0644"];
  const fields = property ? [
    [{ name: "title", label: "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0639\u0642\u0627\u0631", required: true }, { name: "description", label: "\u0627\u0644\u0648\u0635\u0641", type: "textarea", required: true }],
    [{ name: "category", label: "\u0646\u0648\u0639 \u0627\u0644\u0639\u0642\u0627\u0631", options: ["land", "house", "apartment", "commercial", "farm"], required: true }, { name: "listing_type", label: "\u0646\u0648\u0639 \u0627\u0644\u0639\u0631\u0636", options: ["sale", "rent", "not_listed"], required: true }],
    [number("price", "\u0627\u0644\u0633\u0639\u0631"), { name: "currency", label: "\u0627\u0644\u0639\u0645\u0644\u0629", options: ["SDG", "USD"], required: true }, number("area", "\u0627\u0644\u0645\u0633\u0627\u062D\u0629", 1), { name: "area_unit", label: "\u0648\u062D\u062F\u0629 \u0627\u0644\u0645\u0633\u0627\u062D\u0629", options: ["m2", "feddan"], required: true }],
    [{ name: "state", label: "\u0627\u0644\u0648\u0644\u0627\u064A\u0629", required: true }, { name: "city", label: "\u0627\u0644\u0645\u062F\u064A\u0646\u0629", required: true }, { name: "district", label: "\u0627\u0644\u062D\u064A" }, { ...number("latitude", "\u062E\u0637 \u0627\u0644\u0639\u0631\u0636", -90), max: 90 }, { ...number("longitude", "\u062E\u0637 \u0627\u0644\u0637\u0648\u0644", -180), max: 180 }],
    [],
    [{ name: "registration_number", label: "\u0631\u0642\u0645 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 (\u062E\u0627\u0635 \u0628\u0643)" }, { name: "width", label: "\u0627\u0644\u0639\u0631\u0636 \u0628\u0627\u0644\u0645\u062A\u0631", type: "number", min: 1 }, { name: "length", label: "\u0627\u0644\u0637\u0648\u0644 \u0628\u0627\u0644\u0645\u062A\u0631", type: "number", min: 1 }]
  ] : [
    [{ name: "title", label: "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062A\u0635\u0645\u064A\u0645", required: true }, { name: "description", label: "\u0627\u0644\u0648\u0635\u0641", type: "textarea", required: true }],
    [{ name: "category", label: "\u0646\u0648\u0639 \u0627\u0644\u0645\u0628\u0646\u0649", options: ["house", "apartment", "commercial", "farm"], required: true }, { name: "architectural_style", label: "\u0627\u0644\u0637\u0631\u0627\u0632 \u0627\u0644\u0645\u0639\u0645\u0627\u0631\u064A", required: true }],
    [number("floors", "\u0627\u0644\u0637\u0648\u0627\u0628\u0642", 1), number("bedrooms", "\u063A\u0631\u0641 \u0627\u0644\u0646\u0648\u0645"), number("bathrooms", "\u0627\u0644\u062D\u0645\u0627\u0645\u0627\u062A"), number("building_area", "\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0628\u0646\u0627\u0621 \u0645\xB2", 1), number("min_land_width", "\u0623\u0642\u0644 \u0639\u0631\u0636 \u0644\u0644\u0623\u0631\u0636 \u0645", 1), number("min_land_length", "\u0623\u0642\u0644 \u0637\u0648\u0644 \u0644\u0644\u0623\u0631\u0636 \u0645", 1), number("recommended_land_area", "\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0623\u0631\u0636 \u0627\u0644\u0645\u0646\u0627\u0633\u0628\u0629 \u0645\xB2", 1)],
    [],
    [number("price", "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0628\u062A\u062F\u0627\u0626\u064A"), { name: "currency", label: "\u0627\u0644\u0639\u0645\u0644\u0629", options: ["SDG", "USD"], required: true }],
    []
  ];
  async function save(submit) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    try {
      const keys = fields.flat().map((f) => f.name).filter((k) => k !== "registration_number");
      const payload = Object.fromEntries(keys.filter((k) => v[k] != null && v[k] !== "").map((k) => [k, v[k]]));
      let current = id;
      if (!current) {
        const r = check(await db().from(tableFor(kind)).insert({ ...payload, [property ? "owner_id" : "engineer_id"]: uid }).select("id").single());
        current = r.id;
        setId(current);
      } else check(await db().from(tableFor(kind)).update(payload).eq("id", current));
      if (property && v.registration_number) check(await db().from("property_records").upsert({ property_id: current, registration_number: v.registration_number }));
      if (!sentFiles) {
        if (files.length) await uploadImages(kind, current, uid, files);
        setSentFiles(true);
        setFiles([]);
      }
      if (!property) {
        if (license.description && license.allowed_usage) check(await db().from("design_licenses").upsert({ design_id: current, ...license }, { onConflict: "design_id,type" }));
        if (original) {
          await uploadOriginal(original, uid, current);
          setOriginal(null);
        }
      }
      if (submit) await rpc("listing_action", { kind, target: current, action: "submit" });
      saved.current = JSON.stringify(v);
      clear();
      toast(submit ? "\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629." : "\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0645\u0633\u0648\u062F\u0629.");
      go(kind + "/" + current);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxs5(Fragment3, { children: [
    /* @__PURE__ */ jsx5("h1", { children: property ? "\u0625\u0636\u0627\u0641\u0629 / \u062A\u0639\u062F\u064A\u0644 \u0639\u0642\u0627\u0631" : "\u0625\u0636\u0627\u0641\u0629 / \u062A\u0639\u062F\u064A\u0644 \u062A\u0635\u0645\u064A\u0645" }),
    /* @__PURE__ */ jsxs5("p", { children: [
      "\u0627\u0644\u062E\u0637\u0648\u0629 ",
      step + 1,
      " \u0645\u0646 8 \u2014 ",
      steps[step]
    ] }),
    /* @__PURE__ */ jsx5("progress", { "aria-label": "\u062A\u0642\u062F\u0645 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646", value: step + 1, max: 8 }),
    /* @__PURE__ */ jsxs5("form", { className: "card editor-form", onSubmit: async (e) => {
      e.preventDefault();
      setError("");
      if (step < 7) {
        setStep((s) => s + 1);
        return;
      }
      setBusy(true);
      try {
        await save(true);
      } catch (e2) {
        setError(friendlyError(e2));
      } finally {
        setBusy(false);
      }
    }, children: [
      step < 6 && /* @__PURE__ */ jsx5(Fields, { fields: fields[step] || [], values: v, set: setV }),
      property && step === 3 && /* @__PURE__ */ jsx5(PropertyMap, { onPoint: (latitude, longitude) => setV((x) => ({ ...x, latitude, longitude })) }),
      step === (property ? 4 : 3) && /* @__PURE__ */ jsxs5(Fragment3, { children: [
        /* @__PURE__ */ jsxs5("label", { children: [
          property ? "\u0635\u0648\u0631 \u0627\u0644\u0639\u0642\u0627\u0631" : "\u0635\u0648\u0631 \u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u062A\u0635\u0645\u064A\u0645",
          /* @__PURE__ */ jsx5("input", { type: "file", multiple: true, accept: "image/jpeg,image/png,image/webp", onChange: (e) => {
            setFiles(Array.from(e.target.files || []));
            setSentFiles(false);
          } })
        ] }),
        /* @__PURE__ */ jsxs5("p", { children: [
          files.length,
          " \u0635\u0648\u0631 \u0645\u062E\u062A\u0627\u0631\u0629 \u2022 \u062D\u062A\u0649 10 \u0635\u0648\u0631. ",
          property ? "" : "\u062A\u0636\u0627\u0641 \u0639\u0644\u0627\u0645\u0629 \u0645\u0627\u0626\u064A\u0629 \u0625\u0644\u0649 \u0646\u0633\u062E \u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629."
        ] }),
        existing?.[imagesFor(kind)]?.map((img) => /* @__PURE__ */ jsxs5("div", { className: "media-edit", children: [
          /* @__PURE__ */ jsx5(Media, { bucket: property ? "property-images" : "design-previews", path: img.thumbnail_path, alt: "\u0635\u0648\u0631\u0629 \u0645\u062D\u0641\u0648\u0638\u0629" }),
          /* @__PURE__ */ jsx5(Action, { run: async () => {
            check(await db().from(imagesFor(kind)).delete().eq("id", img.id));
            check(await db().storage.from(property ? "property-images" : "design-previews").remove([img.path, img.thumbnail_path]));
            go("edit-" + kind + "/" + id + "?updated=" + Date.now());
          }, children: "\u062D\u0630\u0641 \u0627\u0644\u0635\u0648\u0631\u0629" })
        ] }, img.id))
      ] }),
      !property && step === 5 && /* @__PURE__ */ jsxs5(Fragment3, { children: [
        /* @__PURE__ */ jsx5(Fields, { fields: [{ name: "type", label: "\u0627\u0644\u062A\u0631\u062E\u064A\u0635", options: ["preview", "personal_use", "purchase_with_modification", "full_rights", "commercial_use"], required: true }, number("price", "\u0633\u0639\u0631 \u0627\u0644\u062A\u0631\u062E\u064A\u0635"), { name: "description", label: "\u0648\u0635\u0641 \u0627\u0644\u062A\u0631\u062E\u064A\u0635", type: "textarea", required: true }, { name: "allowed_usage", label: "\u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0645\u0633\u0645\u0648\u062D", type: "textarea", required: true }], values: license, set: (x) => setLicense(x) }),
        /* @__PURE__ */ jsx5("p", { children: "\u064A\u0645\u0643\u0646 \u0625\u0636\u0627\u0641\u0629 \u062A\u0631\u0627\u062E\u064A\u0635 \u0623\u062E\u0631\u0649 \u0628\u0639\u062F \u062D\u0641\u0638 \u0627\u0644\u062A\u0635\u0645\u064A\u0645\u060C \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644." }),
        /* @__PURE__ */ jsxs5("label", { children: [
          "\u0645\u0644\u0641 \u0627\u0644\u062A\u0635\u0645\u064A\u0645 \u0627\u0644\u0623\u0635\u0644\u064A (\u062E\u0627\u0635)",
          /* @__PURE__ */ jsx5("input", { type: "file", accept: ".pdf,.zip,.dwg,.dxf", onChange: (e) => setOriginal(e.target.files?.[0] || null) })
        ] })
      ] }),
      step >= 6 && /* @__PURE__ */ jsxs5(Fragment3, { children: [
        /* @__PURE__ */ jsx5("h2", { children: v.title }),
        /* @__PURE__ */ jsx5("p", { className: "preserve", children: v.description }),
        /* @__PURE__ */ jsx5("dl", { children: fields.flat().filter((f) => f.name !== "description" && v[f.name] != null).map((f) => /* @__PURE__ */ jsxs5("div", { children: [
          /* @__PURE__ */ jsx5("dt", { children: f.label }),
          /* @__PURE__ */ jsx5("dd", { children: String(v[f.name]) })
        ] }, f.name)) }),
        /* @__PURE__ */ jsx5("p", { children: "\u0633\u064A\u064F\u0631\u0633\u0644 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629\u060C \u0648\u0644\u0646 \u064A\u0638\u0647\u0631 \u0644\u0644\u0639\u0627\u0645\u0629 \u0642\u0628\u0644 \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629." })
      ] }),
      /* @__PURE__ */ jsxs5("div", { className: "toolbar", children: [
        step > 0 && /* @__PURE__ */ jsx5("button", { type: "button", disabled: busy, onClick: () => setStep((s) => s - 1), children: "\u0627\u0644\u0633\u0627\u0628\u0642" }),
        /* @__PURE__ */ jsx5("button", { className: "primary", disabled: busy, children: busy ? "\u062C\u0627\u0631\u064D \u0627\u0644\u062D\u0641\u0638 \u0648\u0627\u0644\u0631\u0641\u0639\u2026" : step === 7 ? "\u0625\u0631\u0633\u0627\u0644 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629" : "\u0627\u0644\u062A\u0627\u0644\u064A" })
      ] }),
      error && /* @__PURE__ */ jsxs5("p", { role: "alert", className: "error", children: [
        error,
        " ",
        id && "\u062D\u064F\u0641\u0638\u062A \u0627\u0644\u0645\u0633\u0648\u062F\u0629\u061B \u064A\u0645\u0643\u0646\u0643 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629."
      ] })
    ] }),
    step === 7 && /* @__PURE__ */ jsx5(Action, { disabled: busy, run: () => save(false), children: "\u062D\u0641\u0638 \u0643\u0645\u0633\u0648\u062F\u0629" })
  ] });
}

// src/features/Details.tsx
import { useEffect as useEffect5, useState as useState7 } from "react";
import { Fragment as Fragment4, jsx as jsx6, jsxs as jsxs6 } from "react/jsx-runtime";
function Report({ kind, id, uid }) {
  const [done, setDone] = useState7(false);
  return /* @__PURE__ */ jsxs6("details", { children: [
    /* @__PURE__ */ jsx6("summary", { children: "\u0627\u0644\u0625\u0628\u0644\u0627\u063A" }),
    done ? /* @__PURE__ */ jsx6("p", { children: "\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0628\u0644\u0627\u063A \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629." }) : /* @__PURE__ */ jsx6(DataForm, { label: "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0628\u0644\u0627\u063A", fields: [{ name: "reason", label: "\u0627\u0644\u0633\u0628\u0628", options: ["incorrect_information", "possible_fraud", "copyright", "duplicate", "inappropriate", "other"], required: true }, { name: "description", label: "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644", type: "textarea", required: true }], submit: async (v) => {
      check(await db().from("reports").insert({ ...v, user_id: uid, [kind + "_id"]: id }));
      setDone(true);
    } })
  ] });
}
function Details({ kind, id, uid, go, match }) {
  const [property] = useState7(kind === "property"), [fav, setFav] = useState7(null), [views2, setViews] = useState7(null), [shared, setShared] = useState7(false);
  const q = useLoad(async () => {
    const r2 = check(await db().from(tableFor(kind)).select(`*,${imagesFor(kind)}(*)`).eq("id", id).single());
    const f = uid ? check(await db().from("favorites").select("*").eq("user_id", uid).eq(kind + "_id", id).maybeSingle()) : null;
    setFav(f);
    return r2;
  }, [kind, id, uid]);
  useEffect5(() => {
    if (!uid) return;
    rpc("record_view", { kind, target: id }).then(setViews).catch(() => {
    });
  }, [kind, id]);
  const r = q.data, owner = r?.[property ? "owner_id" : "engineer_id"];
  return /* @__PURE__ */ jsx6(LoadState, { query: q, variant: "details", children: r && /* @__PURE__ */ jsxs6(Fragment4, { children: [
    /* @__PURE__ */ jsx6(Gallery, { images: r[imagesFor(kind)] || [], bucket: property ? "property-images" : "design-previews", title: r.title }),
    /* @__PURE__ */ jsx6("h1", { children: r.title }),
    /* @__PURE__ */ jsxs6("p", { className: "detail-price", children: [
      Number(r.price).toLocaleString("ar"),
      " ",
      r.currency,
      " \u2022 ",
      text(r.status)
    ] }),
    /* @__PURE__ */ jsx6("p", { className: "detail-location", children: property ? `${r.state} \u2022 ${r.city} \u2022 ${r.area} ${r.area_unit === "feddan" ? "\u0641\u062F\u0627\u0646" : "\u0645\xB2"}` : `\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0628\u0646\u0627\u0621 ${r.building_area} \u0645\xB2` }),
    /* @__PURE__ */ jsx6("p", { className: "preserve", children: r.description }),
    /* @__PURE__ */ jsxs6("dl", { children: [
      (property ? [["\u0627\u0644\u0645\u0648\u0642\u0639", `${r.state} / ${r.city} / ${r.district || ""}`], ["\u0627\u0644\u0645\u0633\u0627\u062D\u0629", `${r.area} ${r.area_unit === "m2" ? "\u0645\xB2" : "\u0641\u062F\u0627\u0646"}`], ["\u0627\u0644\u0639\u0631\u0636", text(r.listing_type)]] : [["\u0627\u0644\u0637\u0648\u0627\u0628\u0642", r.floors], ["\u063A\u0631\u0641 \u0627\u0644\u0646\u0648\u0645", r.bedrooms], ["\u0627\u0644\u062D\u0645\u0627\u0645\u0627\u062A", r.bathrooms], ["\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0628\u0646\u0627\u0621", r.building_area + " \u0645\xB2"], ["\u0623\u0642\u0644 \u0623\u0628\u0639\u0627\u062F \u0623\u0631\u0636", `${r.min_land_width} \xD7 ${r.min_land_length} \u0645`], ["\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0623\u0631\u0636 \u0627\u0644\u0645\u0646\u0627\u0633\u0628\u0629", r.recommended_land_area + " \u0645\xB2"]]).map(([k, v]) => /* @__PURE__ */ jsxs6("div", { children: [
        /* @__PURE__ */ jsx6("dt", { children: k }),
        /* @__PURE__ */ jsx6("dd", { children: v })
      ] }, k)),
      /* @__PURE__ */ jsxs6("div", { children: [
        /* @__PURE__ */ jsx6("dt", { children: "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0625\u0636\u0627\u0641\u0629" }),
        /* @__PURE__ */ jsx6("dd", { children: new Date(r.created_at).toLocaleDateString("ar") })
      ] }),
      views2 !== null && /* @__PURE__ */ jsxs6("div", { children: [
        /* @__PURE__ */ jsx6("dt", { children: "\u0645\u0634\u0627\u0647\u062F\u0627\u062A \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u0627\u0644\u0641\u0631\u064A\u062F\u0629" }),
        /* @__PURE__ */ jsx6("dd", { children: views2 })
      ] })
    ] }),
    /* @__PURE__ */ jsxs6("div", { className: "detail-actions", children: [
      /* @__PURE__ */ jsxs6("div", { className: "toolbar", children: [
        uid && /* @__PURE__ */ jsx6(Action, { run: async () => {
          if (fav) {
            check(await db().from("favorites").delete().eq("id", fav.id));
            setFav(null);
          } else {
            setFav(check(await db().from("favorites").insert({ user_id: uid, [kind + "_id"]: id }).select().single()));
          }
        }, children: fav ? "\u0625\u0632\u0627\u0644\u0629 \u0645\u0646 \u0627\u0644\u0645\u0641\u0636\u0644\u0629" : "\u062D\u0641\u0638 \u0641\u064A \u0627\u0644\u0645\u0641\u0636\u0644\u0629" }),
        /* @__PURE__ */ jsx6(Action, { run: async () => {
          await share(kind + "/" + id, r.title);
          setShared(true);
        }, children: "\u0645\u0634\u0627\u0631\u0643\u0629" })
      ] }),
      shared && /* @__PURE__ */ jsx6("p", { role: "status", children: "\u062A\u0645\u062A \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0623\u0648 \u0646\u0633\u062E \u0627\u0644\u0631\u0627\u0628\u0637." }),
      uid && owner !== uid && /* @__PURE__ */ jsxs6(Action, { run: async () => go("chat/" + await rpc("start_conversation", { recipient: owner })), children: [
        "\u0645\u0631\u0627\u0633\u0644\u0629 ",
        property ? "\u0635\u0627\u062D\u0628 \u0627\u0644\u0639\u0642\u0627\u0631" : "\u0627\u0644\u0645\u0647\u0646\u062F\u0633"
      ] })
    ] }),
    !property && /* @__PURE__ */ jsxs6(Fragment4, { children: [
      /* @__PURE__ */ jsx6("button", { className: "outline", onClick: () => go("engineer/" + owner), children: "\u0645\u0644\u0641 \u0627\u0644\u0645\u0647\u0646\u062F\u0633" }),
      /* @__PURE__ */ jsx6(Licenses, { id, owner: owner === uid, uid, go })
    ] }),
    property && r.latitude != null && r.longitude != null && /* @__PURE__ */ jsx6(PropertyMap, { rows: [r] }),
    property && owner === uid && /* @__PURE__ */ jsx6("button", { className: "outline", onClick: () => match({ land_width: r.width, land_length: r.length, land_area: r.area_unit === "feddan" ? r.area * 4200 : r.area }), children: "\u0627\u0628\u062D\u062B \u0639\u0646 \u062A\u0635\u0645\u064A\u0645 \u0644\u0647\u0630\u0647 \u0627\u0644\u0623\u0631\u0636" }),
    owner === uid && /* @__PURE__ */ jsxs6(Fragment4, { children: [
      /* @__PURE__ */ jsxs6("div", { className: "toolbar", children: [
        /* @__PURE__ */ jsx6(Action, { run: async () => {
          await rpc("listing_action", { kind, target: id, action: "edit" });
          go("edit-" + kind + "/" + id);
        }, children: "\u062A\u0639\u062F\u064A\u0644 (\u0625\u0639\u0627\u062F\u0629 \u0625\u0644\u0649 \u0645\u0633\u0648\u062F\u0629)" }),
        /* @__PURE__ */ jsx6(Action, { run: async () => {
          await rpc("listing_action", { kind, target: id, action: "archive" });
          q.reload();
        }, children: "\u0623\u0631\u0634\u0641\u0629" }),
        property && r.status === "approved" && ["sold", "rented"].map((s) => /* @__PURE__ */ jsx6(Action, { run: async () => {
          await rpc("listing_action", { kind, target: id, action: s });
          q.reload();
        }, children: text(s) }, s))
      ] }),
      ["draft", "rejected"].includes(r.status) && /* @__PURE__ */ jsx6(Action, { run: async () => {
        if (!confirm("\u062D\u0630\u0641 \u0627\u0644\u0645\u0633\u0648\u062F\u0629\u061F")) return;
        check(await db().from(tableFor(kind)).delete().eq("id", id));
        go("mine-" + kind);
      }, children: "\u062D\u0630\u0641 \u0627\u0644\u0645\u0633\u0648\u062F\u0629" })
    ] }),
    uid ? /* @__PURE__ */ jsx6(Report, { kind, id, uid }) : /* @__PURE__ */ jsx6("button", { className: "primary", onClick: () => go("login"), children: "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u0644\u062A\u0648\u0627\u0635\u0644 \u0648\u0627\u0644\u062D\u0641\u0638" })
  ] }) });
}
function Licenses({ id, owner, uid, go }) {
  const q = useLoad(async () => ({ licenses: check(await db().from("design_licenses").select("*").eq("design_id", id)), files: uid ? check(await db().from("design_files").select("*").eq("design_id", id)) : [] }), [id, uid]);
  return /* @__PURE__ */ jsxs6(LoadState, { query: q, children: [
    /* @__PURE__ */ jsx6("h2", { children: "\u0627\u0644\u062A\u0631\u0627\u062E\u064A\u0635" }),
    !q.data?.licenses.length && /* @__PURE__ */ jsx6(Empty, {}),
    q.data?.licenses.map((l) => /* @__PURE__ */ jsxs6("article", { className: "card", children: [
      /* @__PURE__ */ jsx6("h3", { children: text(l.type) }),
      /* @__PURE__ */ jsx6("p", { children: l.description }),
      /* @__PURE__ */ jsxs6("p", { children: [
        "\u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645: ",
        l.allowed_usage
      ] }),
      /* @__PURE__ */ jsxs6("p", { children: [
        "\u0627\u0644\u0633\u0639\u0631: ",
        l.price
      ] }),
      uid && !owner && l.type !== "preview" && /* @__PURE__ */ jsx6(Action, { run: async () => {
        await rpc("order_design", { license: l.id });
        go("requests");
      }, children: "\u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628 \u0634\u0631\u0627\u0621" })
    ] }, l.id)),
    /* @__PURE__ */ jsx6("p", { children: "\u0637\u0644\u0628 \u0627\u0644\u0634\u0631\u0627\u0621 \u0644\u0627 \u064A\u0639\u0646\u064A \u0625\u062A\u0645\u0627\u0645 \u0627\u0644\u062F\u0641\u0639. \u062A\u064F\u0646\u0633\u0651\u064E\u0642 \u0627\u0644\u0634\u0631\u0648\u0637 \u0645\u0639 \u0627\u0644\u0645\u0647\u0646\u062F\u0633 \u0639\u0628\u0631 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629." }),
    q.data?.files.map((f) => /* @__PURE__ */ jsxs6(Action, { run: async () => {
      await openPrivateFile("design-originals", f.path);
    }, children: [
      "\u062A\u0646\u0632\u064A\u0644 ",
      f.original_filename
    ] }, f.id)),
    owner && /* @__PURE__ */ jsxs6("details", { children: [
      /* @__PURE__ */ jsx6("summary", { children: "\u0625\u0636\u0627\u0641\u0629 \u062A\u0631\u062E\u064A\u0635 (\u0641\u064A \u0648\u0636\u0639 \u0627\u0644\u0645\u0633\u0648\u062F\u0629)" }),
      /* @__PURE__ */ jsx6(DataForm, { fields: [{ name: "type", label: "\u0627\u0644\u0646\u0648\u0639", options: ["preview", "personal_use", "purchase_with_modification", "full_rights", "commercial_use"], required: true }, { name: "price", label: "\u0627\u0644\u0633\u0639\u0631", type: "number", min: 0, required: true }, { name: "description", label: "\u0627\u0644\u0648\u0635\u0641", type: "textarea", required: true }, { name: "allowed_usage", label: "\u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0645\u0633\u0645\u0648\u062D", type: "textarea", required: true }], submit: async (v) => {
        check(await db().from("design_licenses").upsert({ ...v, design_id: id }, { onConflict: "design_id,type" }));
        q.reload();
      } })
    ] })
  ] });
}

// src/features/Engineers.tsx
import { House, LandPlot } from "lucide-react";
import { useState as useState8 } from "react";
import { Fragment as Fragment5, jsx as jsx7, jsxs as jsxs7 } from "react/jsx-runtime";
var engineerFields = [{ name: "professional_name", label: "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0645\u0647\u0646\u064A", required: true }, { name: "specialization", label: "\u0627\u0644\u062A\u062E\u0635\u0635", required: true }, { name: "city", label: "\u0627\u0644\u0645\u062F\u064A\u0646\u0629", required: true }, { name: "country", label: "\u0627\u0644\u062F\u0648\u0644\u0629", required: true }, { name: "years_experience", label: "\u0633\u0646\u0648\u0627\u062A \u0627\u0644\u062E\u0628\u0631\u0629", type: "number", min: 0, max: 80, required: true }, { name: "bio", label: "\u0646\u0628\u0630\u0629", type: "textarea", required: true }, { name: "professional_license", label: "\u0631\u0642\u0645 \u0627\u0644\u062A\u0631\u062E\u064A\u0635 (\u062E\u0627\u0635 \u0628\u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629)" }, { name: "starting_price", label: "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0628\u062A\u062F\u0627\u0626\u064A", type: "number", min: 0 }];
function Onboarding({ done }) {
  const [engineer, setEngineer] = useState8(false);
  return /* @__PURE__ */ jsxs7(Fragment5, { children: [
    /* @__PURE__ */ jsx7("h1", { children: "\u0643\u064A\u0641 \u0633\u062A\u0633\u062A\u062E\u062F\u0645 \u0623\u0631\u0636\u0646\u0627\u061F" }),
    /* @__PURE__ */ jsxs7("div", { className: "role-cards", children: [
      /* @__PURE__ */ jsxs7("article", { className: "card role-card", children: [
        /* @__PURE__ */ jsx7(House, { "aria-hidden": "true" }),
        /* @__PURE__ */ jsx7("h2", { children: "\u0623\u0628\u062D\u062B \u0639\u0646 \u0639\u0642\u0627\u0631 \u0623\u0648 \u062E\u062F\u0645\u0627\u062A" }),
        /* @__PURE__ */ jsx7("p", { children: "\u062A\u0635\u0641\u062D \u0627\u0644\u0623\u0631\u0627\u0636\u064A \u0648\u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A\u060C \u0627\u0628\u062D\u062B \u0639\u0646 \u062A\u0635\u0645\u064A\u0645 \u0645\u0646\u0627\u0633\u0628\u060C \u0648\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0645\u0647\u0646\u062F\u0633\u064A\u0646." }),
        /* @__PURE__ */ jsx7(Action, { run: async () => {
          await rpc("choose_role", { chosen: "customer" });
          done();
        }, children: "\u0645\u062A\u0627\u0628\u0639\u0629 \u0643\u0641\u0631\u062F / \u0639\u0645\u064A\u0644" })
      ] }),
      /* @__PURE__ */ jsxs7("article", { className: "card role-card", children: [
        /* @__PURE__ */ jsx7(LandPlot, { "aria-hidden": "true" }),
        /* @__PURE__ */ jsx7("h2", { children: "\u0623\u0646\u0627 \u0645\u0647\u0646\u062F\u0633" }),
        /* @__PURE__ */ jsx7("p", { children: "\u0627\u0639\u0631\u0636 \u062A\u0635\u0627\u0645\u064A\u0645\u0643 \u0648\u062E\u062F\u0645\u0627\u062A\u0643 \u0648\u0627\u0633\u062A\u0642\u0628\u0644 \u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0639\u0645\u0644\u0627\u0621." }),
        /* @__PURE__ */ jsx7("button", { className: "outline", onClick: () => setEngineer(true), children: "\u0625\u0643\u0645\u0627\u0644 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0645\u0647\u0646\u064A" })
      ] })
    ] }),
    engineer && /* @__PURE__ */ jsx7(EngineerSetup, { done })
  ] });
}
function EngineerSetup({ done, initial }) {
  return /* @__PURE__ */ jsxs7(Fragment5, { children: [
    /* @__PURE__ */ jsx7("h2", { children: "\u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0645\u0647\u0646\u064A" }),
    /* @__PURE__ */ jsx7("p", { children: "\u062A\u064F\u0631\u0627\u062C\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0648\u062B\u064A\u0642 \u0645\u0646 \u0627\u0644\u0625\u062F\u0627\u0631\u0629. \u0644\u0627 \u064A\u0638\u0647\u0631 \u0634\u0627\u0631\u0629 \u0627\u0644\u062A\u0648\u062B\u064A\u0642 \u0642\u0628\u0644 \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629." }),
    /* @__PURE__ */ jsx7(DataForm, { fields: engineerFields, initial: initial || { country: "\u0627\u0644\u0633\u0648\u062F\u0627\u0646", years_experience: 0, starting_price: 0 }, submit: async (v) => {
      if (initial) {
        const payload = Object.fromEntries(engineerFields.map((f) => [f.name, v[f.name] ?? null]));
        check(await db().from("engineer_profiles").update(payload).eq("user_id", initial.user_id));
      } else await rpc("choose_role", { chosen: "engineer", details: v });
      done();
    }, label: "\u062D\u0641\u0638 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0645\u0647\u0646\u064A" })
  ] });
}
function Engineers({ go }) {
  const [f, setF] = useViewState("engineers:fields", {}), [applied, setApplied] = useViewState("engineers:applied", {}), [page, setPage] = useViewState("engineers:page", 0);
  const q = useLoad(async () => {
    let b = db().from("public_engineers").select("*", { count: "exact" });
    for (const k of ["specialization", "city"]) if (applied[k]) b = b.ilike(k, `%${String(applied[k]).replace(/[%_]/g, "")}%`);
    for (const [a, k] of [["rating", "average_rating"], ["experience", "years_experience"]]) if (applied[a] != null) b = b.gte(k, applied[a]);
    if (applied.price != null) b = b.lte("starting_price", applied.price);
    if (applied.verified) b = b.eq("verification_status", "verified");
    const r = await b.order(applied.sort || "average_rating", { ascending: applied.sort === "starting_price" }).range(page * 12, page * 12 + 11);
    check(r);
    return { rows: r.data, count: r.count || 0 };
  }, [applied, page]);
  return /* @__PURE__ */ jsxs7(Fragment5, { children: [
    /* @__PURE__ */ jsx7("h1", { children: "\u0627\u0628\u062D\u062B \u0639\u0646 \u0645\u0647\u0646\u062F\u0633" }),
    /* @__PURE__ */ jsxs7("form", { className: "card", onSubmit: (e) => {
      e.preventDefault();
      setApplied({ ...f });
      setPage(0);
    }, children: [
      /* @__PURE__ */ jsx7(Fields, { values: f, set: setF, fields: [{ name: "specialization", label: "\u0627\u0644\u062A\u062E\u0635\u0635" }, { name: "city", label: "\u0627\u0644\u0645\u062F\u064A\u0646\u0629" }, { name: "rating", label: "\u0623\u0642\u0644 \u062A\u0642\u064A\u064A\u0645", type: "number", min: 0, max: 5 }, { name: "experience", label: "\u0623\u0642\u0644 \u062E\u0628\u0631\u0629 \u0628\u0627\u0644\u0633\u0646\u0648\u0627\u062A", type: "number", min: 0 }, { name: "price", label: "\u0623\u0639\u0644\u0649 \u0633\u0639\u0631 \u0627\u0628\u062A\u062F\u0627\u0626\u064A", type: "number", min: 0 }] }),
      /* @__PURE__ */ jsxs7("label", { className: "check", children: [
        /* @__PURE__ */ jsx7("input", { type: "checkbox", checked: f.verified || false, onChange: (e) => setF({ ...f, verified: e.target.checked }) }),
        "\u0627\u0644\u0645\u0648\u062B\u0651\u0642\u0648\u0646 \u0641\u0642\u0637"
      ] }),
      /* @__PURE__ */ jsxs7("label", { children: [
        "\u0627\u0644\u062A\u0631\u062A\u064A\u0628",
        /* @__PURE__ */ jsxs7("select", { value: f.sort || "average_rating", onChange: (e) => setF({ ...f, sort: e.target.value }), children: [
          /* @__PURE__ */ jsx7("option", { value: "average_rating", children: "\u0627\u0644\u0623\u0639\u0644\u0649 \u062A\u0642\u064A\u064A\u0645\u064B\u0627" }),
          /* @__PURE__ */ jsx7("option", { value: "years_experience", children: "\u0627\u0644\u0623\u0643\u062B\u0631 \u062E\u0628\u0631\u0629" }),
          /* @__PURE__ */ jsx7("option", { value: "starting_price", children: "\u0627\u0644\u0623\u0642\u0644 \u0633\u0639\u0631\u064B\u0627" }),
          /* @__PURE__ */ jsx7("option", { value: "created_at", children: "\u0627\u0644\u0623\u062D\u062F\u062B" })
        ] })
      ] }),
      /* @__PURE__ */ jsx7("button", { className: "primary", children: "\u0628\u062D\u062B" })
    ] }),
    /* @__PURE__ */ jsxs7(LoadState, { query: q, children: [
      !q.data?.rows.length && /* @__PURE__ */ jsx7(Empty, {}),
      q.data?.rows.map((r) => /* @__PURE__ */ jsxs7("button", { className: "service", onClick: () => go("engineer/" + r.user_id), children: [
        /* @__PURE__ */ jsx7("span", { children: "\u{1F4D0}" }),
        /* @__PURE__ */ jsxs7("span", { children: [
          /* @__PURE__ */ jsx7("b", { children: r.professional_name }),
          /* @__PURE__ */ jsxs7("small", { children: [
            r.specialization,
            " \u2022 ",
            r.city,
            " \u2022 ",
            text(r.verification_status),
            " \u2022 ",
            r.average_rating,
            "/5"
          ] })
        ] }),
        /* @__PURE__ */ jsx7("span", { children: "\u2039" })
      ] }, r.user_id)),
      /* @__PURE__ */ jsxs7("div", { className: "toolbar", children: [
        /* @__PURE__ */ jsx7("button", { disabled: !page, onClick: () => setPage((p) => p - 1), children: "\u0627\u0644\u0633\u0627\u0628\u0642" }),
        /* @__PURE__ */ jsx7("button", { disabled: (page + 1) * 12 >= (q.data?.count || 0), onClick: () => setPage((p) => p + 1), children: "\u0627\u0644\u062A\u0627\u0644\u064A" })
      ] })
    ] })
  ] });
}
function EngineerProfile({ id, uid, go }) {
  const q = useLoad(async () => ({ person: check(await db().from("public_engineers").select("*").eq("user_id", id).single()), designs: check(await db().from("engineering_designs").select("*,design_images(thumbnail_path)").eq("engineer_id", id).eq("status", "approved").limit(12)), reviews: check(await db().from("reviews").select("id,rating,comment,created_at").eq("engineer_id", id).order("created_at", { ascending: false }).limit(20)) }), [id]);
  const p = q.data?.person;
  return /* @__PURE__ */ jsx7(LoadState, { query: q, children: p && /* @__PURE__ */ jsxs7(Fragment5, { children: [
    /* @__PURE__ */ jsxs7("div", { className: "profile-head", children: [
      /* @__PURE__ */ jsx7("span", { className: "avatar", children: "\u{1F4D0}" }),
      /* @__PURE__ */ jsx7("h1", { children: p.professional_name }),
      /* @__PURE__ */ jsxs7("p", { children: [
        p.specialization,
        " \u2022 ",
        p.city,
        " \u2022 ",
        p.country
      ] }),
      /* @__PURE__ */ jsx7("span", { className: "status-badge " + p.verification_status, children: text(p.verification_status) })
    ] }),
    /* @__PURE__ */ jsx7("p", { className: "preserve", children: p.bio }),
    /* @__PURE__ */ jsxs7("dl", { children: [
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { children: "\u0633\u0646\u0648\u0627\u062A \u0627\u0644\u062E\u0628\u0631\u0629" }),
        /* @__PURE__ */ jsx7("dd", { children: p.years_experience })
      ] }),
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { children: "\u0627\u0644\u062A\u0642\u064A\u064A\u0645" }),
        /* @__PURE__ */ jsxs7("dd", { children: [
          p.average_rating,
          "/5"
        ] })
      ] }),
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { children: "\u0627\u0644\u0645\u0634\u0627\u0631\u064A\u0639 \u0627\u0644\u0645\u0643\u062A\u0645\u0644\u0629" }),
        /* @__PURE__ */ jsx7("dd", { children: p.completed_projects })
      ] }),
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { children: "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0628\u062A\u062F\u0627\u0626\u064A" }),
        /* @__PURE__ */ jsx7("dd", { children: p.starting_price })
      ] }),
      /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsx7("dt", { children: "\u0627\u0644\u062A\u0648\u0641\u0631" }),
        /* @__PURE__ */ jsx7("dd", { children: p.is_available ? "\u0645\u062A\u0627\u062D \u0644\u0644\u0637\u0644\u0628\u0627\u062A" : "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u062D\u0627\u0644\u064A\u064B\u0627" })
      ] })
    ] }),
    uid && uid !== id && /* @__PURE__ */ jsxs7(Fragment5, { children: [
      /* @__PURE__ */ jsx7(Action, { run: async () => go("chat/" + await rpc("start_conversation", { recipient: id })), children: "\u0625\u0631\u0633\u0627\u0644 \u0631\u0633\u0627\u0644\u0629" }),
      p.is_available && /* @__PURE__ */ jsx7("button", { className: "primary", onClick: () => go("custom/" + id), children: "\u0637\u0644\u0628 \u062A\u0635\u0645\u064A\u0645 \u0645\u062E\u0635\u0635" })
    ] }),
    /* @__PURE__ */ jsx7("h2", { children: "\u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645" }),
    /* @__PURE__ */ jsx7(Cards, { rows: q.data?.designs || [], kind: "design", go, uid }),
    /* @__PURE__ */ jsx7("h2", { children: "\u0627\u0644\u062A\u0642\u064A\u064A\u0645\u0627\u062A" }),
    q.data?.reviews.map((r) => /* @__PURE__ */ jsxs7("article", { className: "card", children: [
      /* @__PURE__ */ jsxs7("b", { children: [
        r.rating,
        "/5"
      ] }),
      /* @__PURE__ */ jsx7("p", { children: r.comment })
    ] }, r.id)),
    uid && /* @__PURE__ */ jsx7(Report, { kind: "engineer", id, uid })
  ] }) });
}

// src/features/Requests.tsx
import { useState as useState9 } from "react";
import { Fragment as Fragment6, jsx as jsx8, jsxs as jsxs8 } from "react/jsx-runtime";
function CustomRequest({ engineer, uid, go }) {
  const q = useLoad(async () => check(await db().from("properties").select("id,title,area,area_unit,width,length").eq("owner_id", uid)), [uid]);
  const [property, setProperty] = useState9("");
  return /* @__PURE__ */ jsxs8(Fragment6, { children: [
    /* @__PURE__ */ jsx8("h1", { children: "\u0637\u0644\u0628 \u062A\u0635\u0645\u064A\u0645 \u0645\u062E\u0635\u0635" }),
    /* @__PURE__ */ jsxs8(LoadState, { query: q, children: [
      /* @__PURE__ */ jsxs8("label", { children: [
        "\u0631\u0628\u0637 \u0628\u0623\u0631\u0636 \u0645\u0646 \u062D\u0633\u0627\u0628\u0643 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
        /* @__PURE__ */ jsxs8("select", { value: property, onChange: (e) => {
          if (canLeave()) setProperty(e.target.value);
        }, children: [
          /* @__PURE__ */ jsx8("option", { value: "", children: "\u062F\u0648\u0646 \u0631\u0628\u0637" }),
          q.data?.map((p) => /* @__PURE__ */ jsx8("option", { value: p.id, children: p.title }, p.id))
        ] })
      ] }),
      /* @__PURE__ */ jsx8(DataForm, { initial: (() => {
        const p = q.data?.find((p2) => p2.id === property);
        return p ? { land_width: p.width, land_length: p.length, land_area: p.area_unit === "feddan" ? p.area * 4200 : p.area } : {};
      })(), fields: [{ name: "title", label: "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0637\u0644\u0628", required: true }, { name: "description", label: "\u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u0645\u0634\u0631\u0648\u0639", type: "textarea", required: true }, { name: "land_width", label: "\u0639\u0631\u0636 \u0627\u0644\u0623\u0631\u0636 \u0645", type: "number", min: 1, required: true }, { name: "land_length", label: "\u0637\u0648\u0644 \u0627\u0644\u0623\u0631\u0636 \u0645", type: "number", min: 1, required: true }, { name: "land_area", label: "\u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0645\xB2", type: "number", min: 1, required: true }, { name: "floors", label: "\u0627\u0644\u0637\u0648\u0627\u0628\u0642", type: "number", min: 1, required: true }, { name: "budget", label: "\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629", type: "number", min: 0, required: true }], submit: async (v) => {
        check(await db().from("custom_design_requests").insert({ ...v, customer_id: uid, engineer_id: engineer, property_id: property || null }));
        go("requests");
      }, label: "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0637\u0644\u0628" }, property)
    ] })
  ] });
}
function Requests({ uid, go }) {
  const [kind, setKind] = useState9("order"), [page, setPage] = useState9(0);
  const tables = { order: "design_orders", custom: "custom_design_requests", modification: "design_modification_requests" };
  const q = useLoad(async () => check(await db().from(tables[kind]).select("*").order("created_at", { ascending: false }).range(page * 12, page * 12 + 11)), [kind, page, uid]);
  return /* @__PURE__ */ jsxs8(Fragment6, { children: [
    /* @__PURE__ */ jsx8("h1", { children: "\u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0648\u0627\u0644\u0645\u0634\u0627\u0631\u064A\u0639" }),
    /* @__PURE__ */ jsx8("div", { className: "toolbar", children: [["order", "\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645"], ["custom", "\u062A\u0635\u0627\u0645\u064A\u0645 \u0645\u062E\u0635\u0635\u0629"], ["modification", "\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062A\u0639\u062F\u064A\u0644"]].map(([k, l]) => /* @__PURE__ */ jsx8("button", { className: kind === k ? "selected" : "", onClick: () => {
      setKind(k);
      setPage(0);
    }, children: l }, k)) }),
    /* @__PURE__ */ jsxs8(LoadState, { query: q, children: [
      !q.data?.length && /* @__PURE__ */ jsx8(Empty, {}),
      q.data?.map((r) => /* @__PURE__ */ jsx8(RequestCard, { r, kind, uid, refresh: q.reload, go }, r.id + kind + r.status)),
      /* @__PURE__ */ jsxs8("div", { className: "toolbar", children: [
        /* @__PURE__ */ jsx8("button", { disabled: !page, onClick: () => setPage((p) => p - 1), children: "\u0627\u0644\u0633\u0627\u0628\u0642" }),
        /* @__PURE__ */ jsx8("button", { disabled: (q.data?.length || 0) < 12, onClick: () => setPage((p) => p + 1), children: "\u0627\u0644\u062A\u0627\u0644\u064A" })
      ] })
    ] })
  ] });
}
function RequestCard({ r, kind, uid, refresh, go }) {
  const customer = r.customer_id === uid;
  const actions = customer ? ["requested", "submitted", "accepted", "awaiting_payment", "in_discussion"].includes(r.status) ? ["cancelled"] : r.status === "delivered" ? ["completed", ...kind === "order" ? ["disputed"] : []] : kind === "order" && ["in_progress", "completed"].includes(r.status) ? ["disputed"] : [] : ["requested", "submitted"].includes(r.status) ? ["accepted", ...kind !== "order" ? ["rejected"] : []] : r.status === "accepted" ? ["in_progress", ...kind === "order" ? ["awaiting_payment"] : []] : r.status === "paid" || r.status === "in_discussion" ? ["in_progress"] : r.status === "in_progress" ? ["delivered"] : [];
  return /* @__PURE__ */ jsxs8("article", { className: "card", children: [
    /* @__PURE__ */ jsx8("h2", { children: r.title || "\u0637\u0644\u0628 " + r.id.slice(0, 8) }),
    /* @__PURE__ */ jsx8("p", { className: "badge", children: text(r.status) }),
    /* @__PURE__ */ jsx8("p", { className: "preserve", children: r.description }),
    kind === "order" && /* @__PURE__ */ jsxs8(Fragment6, { children: [
      /* @__PURE__ */ jsxs8("p", { children: [
        r.agreed_price,
        " ",
        r.license_snapshot.currency,
        " \u2022 ",
        text(r.license_snapshot.type)
      ] }),
      /* @__PURE__ */ jsx8("button", { className: "outline", onClick: () => go("design/" + r.design_id), children: "\u0639\u0631\u0636 \u0627\u0644\u062A\u0635\u0645\u064A\u0645" })
    ] }),
    /* @__PURE__ */ jsx8("p", { children: new Date(r.created_at).toLocaleString("ar") }),
    /* @__PURE__ */ jsx8(Action, { run: async () => go("chat/" + await rpc("start_conversation", { recipient: customer ? r.engineer_id : r.customer_id })), children: "\u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629" }),
    /* @__PURE__ */ jsx8("div", { className: "toolbar", children: actions.map((s) => /* @__PURE__ */ jsx8(Action, { run: async () => {
      if (s === "delivered" && kind === "order" && !confirm("\u0627\u0644\u062A\u0633\u0644\u064A\u0645 \u064A\u0645\u0646\u062D \u0627\u0644\u0639\u0645\u064A\u0644 \u062D\u0642 \u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0623\u0635\u0644\u064A\u0629. \u0647\u0644 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0627\u0644\u062A\u0633\u0644\u064A\u0645\u061F")) return;
      await rpc("request_action", { kind, target: r.id, next_status: s });
      refresh();
    }, children: text(s) }, s)) }),
    kind === "order" && customer && !["cancelled", "disputed"].includes(r.status) && /* @__PURE__ */ jsxs8("details", { children: [
      /* @__PURE__ */ jsx8("summary", { children: "\u0637\u0644\u0628 \u062A\u0639\u062F\u064A\u0644" }),
      /* @__PURE__ */ jsx8(DataForm, { fields: [{ name: "description", label: "\u0627\u0644\u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628", type: "textarea", required: true }], label: "\u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628 \u0627\u0644\u062A\u0639\u062F\u064A\u0644", submit: async (v) => {
        check(await db().from("design_modification_requests").insert({ ...v, order_id: r.id, customer_id: uid, engineer_id: r.engineer_id }));
        refresh();
      } })
    ] }),
    kind === "order" && customer && r.status === "completed" && /* @__PURE__ */ jsxs8("details", { children: [
      /* @__PURE__ */ jsx8("summary", { children: "\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0645\u0647\u0646\u062F\u0633" }),
      /* @__PURE__ */ jsx8(DataForm, { fields: [{ name: "rating", label: "\u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0645\u0646 1 \u0625\u0644\u0649 5", type: "number", min: 1, max: 5, step: "1", required: true }, { name: "comment", label: "\u0631\u0623\u064A\u0643", type: "textarea", required: true }], submit: async (v) => {
        check(await db().from("reviews").insert({ ...v, reviewer_id: uid, engineer_id: r.engineer_id, order_id: r.id }));
        refresh();
      } })
    ] })
  ] });
}

// src/features/Chat.tsx
import { useEffect as useEffect6, useState as useState10 } from "react";
import { Fragment as Fragment7, jsx as jsx9, jsxs as jsxs9 } from "react/jsx-runtime";
function Chat({ thread, uid, go }) {
  const q = useLoad(async () => check(await db().from("conversations").select("id,created_at").order("created_at", { ascending: false }).limit(100)), [uid]);
  return /* @__PURE__ */ jsxs9(Fragment7, { children: [
    /* @__PURE__ */ jsx9("h1", { children: "\u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0627\u062A" }),
    thread ? /* @__PURE__ */ jsx9(Thread, { id: thread, uid }, thread) : /* @__PURE__ */ jsxs9(LoadState, { query: q, children: [
      !q.data?.length && /* @__PURE__ */ jsx9(Empty, { title: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u062D\u0627\u062F\u062B\u0627\u062A", action: () => go("engineers"), actionLabel: "\u0627\u0628\u062D\u062B \u0639\u0646 \u0645\u0647\u0646\u062F\u0633", children: "\u0627\u0628\u062F\u0623 \u0645\u062D\u0627\u062F\u062B\u0629 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0639\u0642\u0627\u0631 \u0623\u0648 \u0645\u0647\u0646\u062F\u0633." }),
      q.data?.map((r) => /* @__PURE__ */ jsxs9("button", { className: "service", onClick: () => go("chat/" + r.id), children: [
        /* @__PURE__ */ jsx9("span", { children: "\u2709" }),
        /* @__PURE__ */ jsxs9("b", { children: [
          "\u0645\u062D\u0627\u062F\u062B\u0629 ",
          r.id.slice(0, 8)
        ] }),
        /* @__PURE__ */ jsx9("span", { children: "\u2039" })
      ] }, r.id))
    ] })
  ] });
}
function Thread({ id, uid }) {
  const [rows, setRows] = useState10([]), [body, setBody] = useState10(""), [error, setError] = useState10(""), [busy, setBusy] = useState10(false), [more, setMore] = useState10(false), [loaded, setLoaded] = useState10(false);
  useUnsaved(Boolean(body.trim()));
  useEffect6(() => {
    let active = true;
    const load = async () => {
      try {
        const r = check(await db().from("messages").select("*").eq("conversation_id", id).order("created_at", { ascending: false }).limit(50));
        if (active) {
          setRows(r.reverse());
          setLoaded(true);
          setMore(r.length === 50);
          setError("");
        }
        await rpc("mark_messages_read", { thread: id });
      } catch (e) {
        if (active) setError(friendlyError(e));
      }
    };
    void load();
    const timer = setInterval(() => {
      if (document.visibilityState === "visible") void load();
    }, 1e4);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [id]);
  return /* @__PURE__ */ jsxs9(Fragment7, { children: [
    /* @__PURE__ */ jsx9("p", { children: "\u0631\u0633\u0627\u0626\u0644 \u0646\u0635\u064A\u0629 \u062E\u0627\u0635\u0629 \u0628\u0623\u0639\u0636\u0627\u0621 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629. \u062A\u062A\u062D\u062F\u062B \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0643\u0644 10 \u062B\u0648\u0627\u0646\u064D." }),
    more && /* @__PURE__ */ jsx9("p", { children: "\u062A\u0638\u0647\u0631 \u0623\u062D\u062F\u062B 50 \u0631\u0633\u0627\u0644\u0629." }),
    !loaded && !error && /* @__PURE__ */ jsx9(Skeleton, { variant: "messages" }),
    /* @__PURE__ */ jsxs9("div", { className: "messages", "aria-live": "polite", children: [
      loaded && !rows.length && /* @__PURE__ */ jsx9(Empty, { children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0631\u0633\u0627\u0626\u0644 \u0628\u0639\u062F." }),
      rows.map((r) => /* @__PURE__ */ jsxs9("article", { className: "message " + (r.sender_id === uid ? "mine" : ""), children: [
        /* @__PURE__ */ jsx9("p", { children: r.body }),
        /* @__PURE__ */ jsxs9("small", { children: [
          new Date(r.created_at).toLocaleString("ar"),
          " ",
          r.sender_id === uid && r.read_at ? "\u2022 \u0645\u0642\u0631\u0648\u0621\u0629" : ""
        ] })
      ] }, r.id))
    ] }),
    /* @__PURE__ */ jsxs9("form", { className: "chat-composer", onSubmit: async (e) => {
      e.preventDefault();
      if (busy || !body.trim()) return;
      setBusy(true);
      setError("");
      try {
        const r = check(await db().from("messages").insert({ conversation_id: id, sender_id: uid, body: body.trim() }).select().single());
        setRows((x) => [...x, r]);
        setBody("");
      } catch (e2) {
        setError(friendlyError(e2));
      } finally {
        setBusy(false);
      }
    }, children: [
      /* @__PURE__ */ jsxs9("label", { children: [
        "\u0631\u0633\u0627\u0644\u0629",
        /* @__PURE__ */ jsx9("textarea", { name: "body", value: body, maxLength: 4e3, required: true, onChange: (e) => setBody(e.target.value) })
      ] }),
      /* @__PURE__ */ jsx9("button", { className: "primary", disabled: busy, children: busy ? "\u062C\u0627\u0631\u064D \u0627\u0644\u0625\u0631\u0633\u0627\u0644\u2026" : "\u0625\u0631\u0633\u0627\u0644" })
    ] }),
    error && /* @__PURE__ */ jsx9("p", { className: "error", role: "alert", children: error })
  ] });
}

// src/features/Workspace.tsx
import { useState as useState11 } from "react";
import { Fragment as Fragment8, jsx as jsx10, jsxs as jsxs10 } from "react/jsx-runtime";
function Dashboard({ engineer, uid, name, go }) {
  const q = useLoad(async () => {
    const queries = engineer ? [
      db().from("engineering_designs").select("*,design_images(thumbnail_path)").eq("engineer_id", uid).order("created_at", { ascending: false }).limit(6),
      db().from("design_orders").select("id,status", { count: "exact" }).eq("engineer_id", uid),
      db().from("reviews").select("id,rating,comment").eq("engineer_id", uid).order("created_at", { ascending: false }).limit(5),
      db().from("design_views").select("id", { count: "exact", head: true }),
      db().from("engineer_profiles").select("verification_status").eq("user_id", uid)
    ] : [
      db().from("properties").select("*,property_images(thumbnail_path)").eq("status", "approved").order("created_at", { ascending: false }).limit(6),
      db().from("engineering_designs").select("*,design_images(thumbnail_path)").eq("status", "approved").order("created_at", { ascending: false }).limit(4),
      db().from("properties").select("*,property_images(thumbnail_path)").eq("featured", true).eq("status", "approved").limit(4),
      db().from("properties").select("id,category", { count: "exact" }).eq("owner_id", uid),
      db().from("public_engineers").select("*").eq("verification_status", "verified").order("average_rating", { ascending: false }).limit(4)
    ];
    const r = await Promise.all(queries);
    r.forEach(check);
    return r;
  }, [uid, engineer]);
  return /* @__PURE__ */ jsxs10(Fragment8, { children: [
    /* @__PURE__ */ jsxs10("div", { className: "welcome", children: [
      /* @__PURE__ */ jsxs10("div", { children: [
        /* @__PURE__ */ jsx10("small", { children: "\u0645\u0631\u062D\u0628\u064B\u0627" }),
        /* @__PURE__ */ jsx10("b", { children: name })
      ] }),
      /* @__PURE__ */ jsx10(Brand, { className: "mini-brand" })
    ] }),
    /* @__PURE__ */ jsx10("h1", { children: engineer ? "\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0645\u0647\u0646\u062F\u0633" : "\u0643\u0644 \u0623\u0631\u0636 \u0642\u0635\u0629 .. \u0641\u064A \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F" }),
    /* @__PURE__ */ jsx10(LoadState, { query: q, children: engineer ? /* @__PURE__ */ jsxs10(Fragment8, { children: [
      /* @__PURE__ */ jsxs10("p", { className: "status-badge " + q.data?.[4].data?.[0]?.verification_status, children: [
        "\u062D\u0627\u0644\u0629 \u0627\u0644\u0645\u0644\u0641: ",
        text(q.data?.[4].data?.[0]?.verification_status)
      ] }),
      /* @__PURE__ */ jsxs10("div", { className: "summary", children: [
        /* @__PURE__ */ jsx10("small", { className: "summary-title", children: "\u0646\u0634\u0627\u0637\u0643" }),
        /* @__PURE__ */ jsxs10("div", { children: [
          /* @__PURE__ */ jsx10("strong", { children: q.data?.[1].count || 0 }),
          /* @__PURE__ */ jsx10("span", { children: "\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062A\u0635\u0645\u064A\u0645" })
        ] }),
        /* @__PURE__ */ jsxs10("div", { children: [
          /* @__PURE__ */ jsx10("strong", { children: q.data?.[3].count || 0 }),
          /* @__PURE__ */ jsx10("span", { children: "\u0645\u0634\u0627\u0647\u062F\u0627\u062A \u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645" })
        ] })
      ] }),
      /* @__PURE__ */ jsx10("div", { className: "quick", children: [["edit-design", "\u0625\u0636\u0627\u0641\u0629 \u062A\u0635\u0645\u064A\u0645"], ["mine-design", "\u062A\u0635\u0627\u0645\u064A\u0645\u064A"], ["requests", "\u0627\u0644\u0637\u0644\u0628\u0627\u062A"], ["chat", "\u0627\u0644\u0631\u0633\u0627\u0626\u0644"]].map(([p, l]) => /* @__PURE__ */ jsx10("button", { onClick: () => go(p), children: l }, p)) }),
      /* @__PURE__ */ jsxs10("div", { className: "toolbar", children: [
        /* @__PURE__ */ jsx10("button", { onClick: () => go("engineer-settings"), children: "\u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0645\u0647\u0646\u064A" }),
        /* @__PURE__ */ jsx10("button", { onClick: () => go("requests"), children: "\u0627\u0644\u0645\u0634\u0627\u0631\u064A\u0639 \u0648\u0627\u0644\u062A\u0639\u062F\u064A\u0644\u0627\u062A" }),
        /* @__PURE__ */ jsx10("button", { onClick: () => go("settings"), children: "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A" })
      ] }),
      /* @__PURE__ */ jsx10("h2", { children: "\u062A\u0635\u0627\u0645\u064A\u0645\u064A" }),
      /* @__PURE__ */ jsx10(Cards, { rows: q.data?.[0].data || [], kind: "design", go, uid }),
      /* @__PURE__ */ jsx10("h2", { children: "\u0622\u062E\u0631 \u0627\u0644\u062A\u0642\u064A\u064A\u0645\u0627\u062A" }),
      q.data?.[2].data?.length ? q.data[2].data.map((r) => /* @__PURE__ */ jsxs10("article", { className: "card", children: [
        r.rating,
        "/5",
        /* @__PURE__ */ jsx10("p", { children: r.comment })
      ] }, r.id)) : /* @__PURE__ */ jsx10(Empty, {})
    ] }) : /* @__PURE__ */ jsxs10(Fragment8, { children: [
      /* @__PURE__ */ jsxs10("div", { className: "summary", children: [
        /* @__PURE__ */ jsx10("small", { className: "summary-title", children: "\u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u0636\u0627\u0641\u0629 \u0641\u064A \u062D\u0633\u0627\u0628\u0643" }),
        /* @__PURE__ */ jsxs10("div", { children: [
          /* @__PURE__ */ jsx10("strong", { children: q.data?.[3].data?.filter((p) => ["land", "farm"].includes(p.category)).length || 0 }),
          /* @__PURE__ */ jsx10("span", { children: "\u0623\u0631\u0627\u0636\u064D" })
        ] }),
        /* @__PURE__ */ jsxs10("div", { children: [
          /* @__PURE__ */ jsx10("strong", { children: q.data?.[3].data?.filter((p) => !["land", "farm"].includes(p.category)).length || 0 }),
          /* @__PURE__ */ jsx10("span", { children: "\u0639\u0642\u0627\u0631\u0627\u062A" })
        ] })
      ] }),
      /* @__PURE__ */ jsx10("div", { className: "quick", children: [["edit-property", "\u0625\u0636\u0627\u0641\u0629 \u0639\u0642\u0627\u0631"], ["map", "\u0627\u0644\u062E\u0631\u064A\u0637\u0629"], ["documents", "\u0648\u062B\u0627\u0626\u0642\u064A"], ["requests", "\u0637\u0644\u0628\u0627\u062A\u064A"]].map(([p, l]) => /* @__PURE__ */ jsx10("button", { onClick: () => go(p), children: l }, p)) }),
      /* @__PURE__ */ jsxs10("div", { className: "toolbar", children: [
        /* @__PURE__ */ jsx10("button", { onClick: () => go("mine-property"), children: "\u0639\u0642\u0627\u0631\u0627\u062A\u064A" }),
        /* @__PURE__ */ jsx10("button", { onClick: () => go("favorites"), children: "\u0627\u0644\u0645\u0641\u0636\u0644\u0629" }),
        /* @__PURE__ */ jsx10("button", { onClick: () => go("services"), children: "\u0627\u0644\u062E\u062F\u0645\u0627\u062A" }),
        /* @__PURE__ */ jsx10("button", { onClick: () => go("engineers"), children: "\u0627\u0644\u0645\u0647\u0646\u062F\u0633\u0648\u0646" })
      ] }),
      /* @__PURE__ */ jsx10("h2", { children: "\u0623\u062D\u062F\u062B \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A" }),
      /* @__PURE__ */ jsx10(Cards, { rows: q.data?.[0].data || [], kind: "property", go, uid }),
      /* @__PURE__ */ jsx10("h2", { children: "\u0639\u0642\u0627\u0631\u0627\u062A \u0645\u0645\u064A\u0632\u0629" }),
      /* @__PURE__ */ jsx10(Cards, { rows: q.data?.[2].data || [], kind: "property", go, uid }),
      /* @__PURE__ */ jsx10("h2", { children: "\u062A\u0635\u0627\u0645\u064A\u0645 \u0645\u0642\u062A\u0631\u062D\u0629" }),
      /* @__PURE__ */ jsx10(Cards, { rows: q.data?.[1].data || [], kind: "design", go, uid }),
      /* @__PURE__ */ jsx10("h2", { children: "\u0645\u0647\u0646\u062F\u0633\u0648\u0646 \u0645\u0648\u062B\u0651\u0642\u0648\u0646" }),
      q.data?.[4].data?.length ? q.data[4].data.map((e) => /* @__PURE__ */ jsx10("button", { className: "outline", onClick: () => go("engineer/" + e.user_id), children: e.professional_name }, e.user_id)) : /* @__PURE__ */ jsx10(Empty, {})
    ] }) })
  ] });
}
function Documents({ uid }) {
  const [file, setFile] = useState11(null);
  const q = useLoad(async () => check(await db().from("documents").select("*").eq("user_id", uid).order("created_at", { ascending: false })), [uid]);
  return /* @__PURE__ */ jsxs10(Fragment8, { children: [
    /* @__PURE__ */ jsx10("h1", { children: "\u0648\u062B\u0627\u0626\u0642\u064A" }),
    /* @__PURE__ */ jsx10("p", { children: "\u0645\u0644\u0641\u0627\u062A \u062E\u0627\u0635\u0629 \u0628\u062D\u0633\u0627\u0628\u0643. PDF \u0623\u0648 JPG \u0623\u0648 PNG\u060C \u062D\u062A\u0649 10 MB." }),
    /* @__PURE__ */ jsxs10("label", { children: [
      "\u0627\u062E\u062A\u0631 \u0645\u0644\u0641\u064B\u0627",
      /* @__PURE__ */ jsx10("input", { type: "file", accept: "application/pdf,image/jpeg,image/png", onChange: (e) => setFile(e.target.files?.[0] || null) })
    ] }),
    file && /* @__PURE__ */ jsxs10(Action, { run: async () => {
      await uploadDocument(file, uid);
      setFile(null);
      q.reload();
    }, children: [
      "\u0631\u0641\u0639 ",
      file.name
    ] }),
    /* @__PURE__ */ jsxs10(LoadState, { query: q, children: [
      !q.data?.length && /* @__PURE__ */ jsx10(Empty, {}),
      q.data?.map((r) => /* @__PURE__ */ jsxs10("article", { className: "card", children: [
        /* @__PURE__ */ jsx10("b", { children: r.name }),
        /* @__PURE__ */ jsxs10("small", { children: [
          (r.file_size / 1048576).toFixed(2),
          " MB"
        ] }),
        /* @__PURE__ */ jsx10(Action, { run: async () => {
          await openPrivateFile("documents", r.path);
        }, children: "\u0641\u062A\u062D / \u062A\u0646\u0632\u064A\u0644" }),
        /* @__PURE__ */ jsx10(Action, { run: async () => {
          if (!confirm("\u062D\u0630\u0641 \u0627\u0644\u0648\u062B\u064A\u0642\u0629\u061F")) return;
          check(await db().storage.from("documents").remove([r.path]));
          check(await db().from("documents").delete().eq("id", r.id));
          q.reload();
        }, children: "\u062D\u0630\u0641" })
      ] }, r.id))
    ] })
  ] });
}
function Notifications({ uid, go }) {
  const q = useLoad(async () => check(await db().from("notifications").select("*").eq("user_id", uid).order("created_at", { ascending: false }).limit(100)), [uid]);
  return /* @__PURE__ */ jsxs10(Fragment8, { children: [
    /* @__PURE__ */ jsx10("h1", { children: "\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A" }),
    /* @__PURE__ */ jsxs10(LoadState, { query: q, children: [
      !q.data?.length && /* @__PURE__ */ jsx10(Empty, { title: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0625\u0634\u0639\u0627\u0631\u0627\u062A", action: () => go("home"), actionLabel: "\u0627\u0644\u0639\u0648\u062F\u0629 \u0644\u0644\u0631\u0626\u064A\u0633\u064A\u0629", children: "\u0633\u062A\u0638\u0647\u0631 \u0647\u0646\u0627 \u062A\u062D\u062F\u064A\u062B\u0627\u062A \u0637\u0644\u0628\u0627\u062A\u0643 \u0648\u0631\u0633\u0627\u0626\u0644\u0643." }),
      q.data?.map((n) => /* @__PURE__ */ jsx10("article", { className: "notification " + (!n.read ? "unread" : ""), children: /* @__PURE__ */ jsxs10("div", { children: [
        /* @__PURE__ */ jsx10("b", { children: n.title }),
        /* @__PURE__ */ jsx10("p", { children: n.body }),
        /* @__PURE__ */ jsx10("small", { children: new Date(n.created_at).toLocaleString("ar") }),
        /* @__PURE__ */ jsx10(Action, { run: async () => {
          check(await db().from("notifications").update({ read: true }).eq("id", n.id));
          const route = n.type === "conversation" ? "chat/" + n.related_id : n.type === "properties" ? "property/" + n.related_id : n.type === "engineering_designs" ? "design/" + n.related_id : n.type === "engineer_profiles" ? "engineer-settings" : "requests";
          go(route);
        }, children: "\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644" })
      ] }) }, n.id))
    ] })
  ] });
}
function Services({ uid }) {
  const q = useLoad(async () => check(await db().from("service_requests").select("*").eq("user_id", uid).order("created_at", { ascending: false }).limit(100)), [uid]);
  return /* @__PURE__ */ jsxs10(Fragment8, { children: [
    /* @__PURE__ */ jsx10("h1", { children: "\u0627\u0644\u062F\u0639\u0645 \u0648\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062E\u062F\u0645\u0627\u062A" }),
    /* @__PURE__ */ jsx10("p", { children: "\u0623\u0631\u0636\u0646\u0627 \u0644\u064A\u0633\u062A \u062C\u0647\u0629 \u062D\u0643\u0648\u0645\u064A\u0629\u060C \u0648\u0644\u0627 \u062A\u0635\u062F\u0631 \u0634\u0647\u0627\u062F\u0627\u062A \u0645\u0644\u0643\u064A\u0629 \u0623\u0648 \u062A\u0646\u0641\u0630 \u0646\u0642\u0644 \u0645\u0644\u0643\u064A\u0629 \u0631\u0633\u0645\u064A\u064B\u0627." }),
    /* @__PURE__ */ jsx10(DataForm, { fields: [{ name: "title", label: "\u0645\u0648\u0636\u0648\u0639 \u0627\u0644\u0637\u0644\u0628", required: true }, { name: "description", label: "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644", type: "textarea", required: true }], label: "\u0625\u0631\u0633\u0627\u0644 \u0644\u0644\u0625\u062F\u0627\u0631\u0629", submit: async (v) => {
      check(await db().from("service_requests").insert({ ...v, user_id: uid }));
      q.reload();
    } }),
    /* @__PURE__ */ jsx10("h2", { children: "\u0637\u0644\u0628\u0627\u062A\u0643" }),
    /* @__PURE__ */ jsx10(LoadState, { query: q, children: q.data?.map((r) => /* @__PURE__ */ jsxs10("article", { className: "card", children: [
      /* @__PURE__ */ jsx10("b", { children: r.title }),
      /* @__PURE__ */ jsx10("p", { children: r.description }),
      /* @__PURE__ */ jsx10("span", { children: text(r.status) })
    ] }, r.id)) })
  ] });
}
var adminTabs = { properties: ["\u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A", "property", ["approved", "rejected", "archived", "feature", "unfeature"]], engineering_designs: ["\u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645", "design", ["approved", "rejected", "archived", "feature", "unfeature"]], engineer_profiles: ["\u062A\u0648\u062B\u064A\u0642 \u0627\u0644\u0645\u0647\u0646\u062F\u0633\u064A\u0646", "engineer", ["verified", "rejected"]], profiles: ["\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u0648\u0646", "user", ["suspend", "unsuspend"]], design_orders: ["\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645", "order", []], custom_design_requests: ["\u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0645\u062E\u0635\u0635\u0629", "custom", []], reports: ["\u0627\u0644\u0628\u0644\u0627\u063A\u0627\u062A", "report", ["reviewed", "resolved"]], service_requests: ["\u0627\u0644\u062E\u062F\u0645\u0627\u062A", "service", ["in_progress", "completed", "cancelled"]], audit_logs: ["\u0633\u062C\u0644 \u0627\u0644\u0625\u062F\u0627\u0631\u0629", "audit", []] };
function Admin({ go }) {
  const [tab, setTab] = useState11("properties"), [pending, setPending] = useState11(false), [page, setPage] = useState11(0);
  const q = useLoad(async () => {
    let b = db().from(tab).select("*", { count: "exact" });
    if (pending && ["properties", "engineering_designs"].includes(tab)) b = b.eq("status", "pending");
    const r = await b.order("created_at", { ascending: false }).range(page * 20, page * 20 + 19);
    check(r);
    return { rows: r.data, count: r.count || 0 };
  }, [tab, pending, page]);
  return /* @__PURE__ */ jsxs10(Fragment8, { children: [
    /* @__PURE__ */ jsx10("h1", { children: "\u0644\u0648\u062D\u0629 \u0627\u0644\u0625\u062F\u0627\u0631\u0629" }),
    /* @__PURE__ */ jsx10("div", { className: "toolbar", children: Object.entries(adminTabs).map(([k, [l]]) => /* @__PURE__ */ jsx10("button", { className: tab === k ? "selected" : "", onClick: () => {
      setTab(k);
      setPage(0);
    }, children: l }, k)) }),
    ["properties", "engineering_designs"].includes(tab) && /* @__PURE__ */ jsxs10("label", { className: "check", children: [
      /* @__PURE__ */ jsx10("input", { type: "checkbox", checked: pending, onChange: (e) => {
        setPending(e.target.checked);
        setPage(0);
      } }),
      "\u0642\u064A\u062F \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629 \u0641\u0642\u0637"
    ] }),
    /* @__PURE__ */ jsxs10(LoadState, { query: q, children: [
      /* @__PURE__ */ jsxs10("p", { children: [
        "\u0639\u062F\u062F \u0627\u0644\u0633\u062C\u0644\u0627\u062A: ",
        q.data?.count || 0
      ] }),
      q.data?.rows.map((r) => /* @__PURE__ */ jsxs10("article", { className: "card", children: [
        /* @__PURE__ */ jsx10("h2", { children: r.title || r.professional_name || r.full_name || r.action || r.id?.slice(0, 8) }),
        ["properties", "engineering_designs"].includes(tab) && /* @__PURE__ */ jsx10("button", { className: "outline", onClick: () => go((tab === "properties" ? "property/" : "design/") + r.id), children: "\u0641\u062A\u062D \u0627\u0644\u0635\u0648\u0631 \u0648\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644" }),
        /* @__PURE__ */ jsx10("p", { children: text(r.status || r.verification_status || (r.suspended ? "\u0645\u0648\u0642\u0648\u0641" : "")) }),
        /* @__PURE__ */ jsxs10("details", { children: [
          /* @__PURE__ */ jsx10("summary", { children: "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644" }),
          /* @__PURE__ */ jsx10("dl", { children: Object.entries(r).filter(([k]) => !["id", "user_id"].includes(k)).map(([k, v]) => /* @__PURE__ */ jsxs10("div", { children: [
            /* @__PURE__ */ jsx10("dt", { children: k }),
            /* @__PURE__ */ jsx10("dd", { children: typeof v === "object" ? JSON.stringify(v) : String(v ?? "\u2014") })
          ] }, k)) })
        ] }),
        /* @__PURE__ */ jsx10("div", { className: "toolbar", children: adminTabs[tab][2].map((action) => /* @__PURE__ */ jsx10(Action, { run: async () => {
          await rpc("admin_action", { kind: adminTabs[tab][1], target: r.id || r.user_id, action });
          q.reload();
        }, children: { feature: "\u062A\u0645\u064A\u064A\u0632", unfeature: "\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u062A\u0645\u064A\u064A\u0632", suspend: "\u0625\u064A\u0642\u0627\u0641", unsuspend: "\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0625\u064A\u0642\u0627\u0641" }[action] || text(action) }, action)) })
      ] }, r.id || r.user_id)),
      /* @__PURE__ */ jsxs10("div", { className: "toolbar", children: [
        /* @__PURE__ */ jsx10("button", { disabled: !page, onClick: () => setPage((p) => p - 1), children: "\u0627\u0644\u0633\u0627\u0628\u0642" }),
        /* @__PURE__ */ jsx10("button", { disabled: (page + 1) * 20 >= (q.data?.count || 0), onClick: () => setPage((p) => p + 1), children: "\u0627\u0644\u062A\u0627\u0644\u064A" })
      ] })
    ] })
  ] });
}

// src/App.tsx
import { Fragment as Fragment9, jsx as jsx11, jsxs as jsxs11 } from "react/jsx-runtime";
function App2() {
  const [session, setSession] = useState12(null), [loading, setLoading] = useState12(true), [error, setError] = useState12(""), [recovery, setRecovery] = useState12(false);
  const { route, go, back } = useNavigation();
  useViewport();
  const [dark, setDark] = useState12(() => localStorage.getItem("ardna-theme") === "dark");
  useEffect7(() => {
    localStorage.setItem("ardna-theme", dark ? "dark" : "light");
    document.documentElement.style.colorScheme = dark ? "dark" : "light";
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#10231d" : "#f6f4ed");
  }, [dark]);
  useEffect7(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }
    let live = true;
    supabase.auth.getSession().then((r) => {
      if (live) {
        if (r.error) setError(r.error.message);
        setSession(r.data.session);
        setLoading(false);
      }
    }).catch((e) => {
      if (live) {
        setError(e.message);
        setLoading(false);
      }
    });
    const sub = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s);
      if (event === "SIGNED_OUT") clearViews();
      if (event === "PASSWORD_RECOVERY") setRecovery(true);
    }).data.subscription;
    const listener = App.addListener("appUrlOpen", async ({ url }) => {
      try {
        const u = new URL(url);
        if (u.protocol !== "com.ardna.app:" || u.host !== "auth" || u.pathname !== "/callback") return;
        const code = u.searchParams.get("code");
        if (code) {
          check(await db().auth.exchangeCodeForSession(code));
          await Browser.close().catch(() => {
          });
        }
      } catch (e) {
        setError(e.message);
      }
    });
    const state2 = App.addListener("appStateChange", ({ isActive }) => {
      if (isActive) db().auth.startAutoRefresh();
      else db().auth.stopAutoRefresh();
    });
    const back2 = App.addListener("backButton", () => {
      if (Number(history.state?.ardnaIndex) > 0) history.back();
      else void App.minimizeApp();
    });
    return () => {
      live = false;
      sub.unsubscribe();
      void listener.then((h) => h.remove());
      void state2.then((h) => h.remove());
      void back2.then((h) => h.remove());
    };
  }, []);
  return /* @__PURE__ */ jsx11("main", { className: "app " + (dark ? "dark" : ""), dir: "rtl", children: /* @__PURE__ */ jsx11("section", { className: "page shell", children: /* @__PURE__ */ jsxs11("div", { className: "content", children: [
    /* @__PURE__ */ jsx11(ToastHost, {}),
    /* @__PURE__ */ jsxs11("header", { children: [
      /* @__PURE__ */ jsx11("button", { className: "icon-btn", "aria-label": "\u0631\u062C\u0648\u0639", onClick: back, children: /* @__PURE__ */ jsx11(ChevronRight2, {}) }),
      /* @__PURE__ */ jsxs11("button", { className: "header-home", "aria-label": "\u0623\u0631\u0636\u0646\u0627 \u2014 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629", onClick: () => go("home"), children: [
        /* @__PURE__ */ jsx11(Brand, { className: "header-brand" }),
        /* @__PURE__ */ jsx11("b", { children: "\u0623\u0631\u0636\u0646\u0627" })
      ] }),
      session && /* @__PURE__ */ jsx11("button", { className: "icon-btn", "aria-label": "\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A", onClick: () => go("notifications"), children: /* @__PURE__ */ jsx11(Bell, {}) })
    ] }),
    error && /* @__PURE__ */ jsx11("p", { role: "alert", className: "error", children: friendlyError(error) }),
    !configured ? /* @__PURE__ */ jsxs11("section", { className: "unavailable", children: [
      /* @__PURE__ */ jsx11(Brand, {}),
      /* @__PURE__ */ jsx11("h1", { children: "\u0623\u0631\u0636\u0646\u0627" }),
      /* @__PURE__ */ jsx11("p", { children: "\u0627\u0644\u062E\u062F\u0645\u0629 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629 \u0645\u0624\u0642\u062A\u064B\u0627. \u064A\u0631\u062C\u0649 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0644\u0627\u062D\u0642\u064B\u0627." }),
      /* @__PURE__ */ jsx11("small", { children: "\u0627\u0644\u0625\u0635\u062F\u0627\u0631 3.0.1 \u2022 UX" })
    ] }) : loading ? /* @__PURE__ */ jsx11(Skeleton, { variant: "form" }) : recovery ? /* @__PURE__ */ jsx11(Auth, { recovery: true }) : !session ? /* @__PURE__ */ jsx11(Guest, { route, go }) : /* @__PURE__ */ jsx11(Workspace, { uid: session.user.id, route, go, dark, setDark }, session.user.id)
  ] }) }) });
}
function Guest({ route, go }) {
  const [page, id] = route.split("/");
  let content;
  if (page === "properties" || page === "designs") content = /* @__PURE__ */ jsx11(Catalog, { kind: page === "properties" ? "property" : "design", uid: "", go }, page);
  else if ((page === "property" || page === "design") && id) content = /* @__PURE__ */ jsx11(Details, { kind: page, id, uid: "", go, match: () => go("designs") }, route);
  else if (page === "engineers") content = /* @__PURE__ */ jsx11(Engineers, { go });
  else if (page === "engineer" && id) content = /* @__PURE__ */ jsx11(EngineerProfile, { id, uid: "", go });
  else content = /* @__PURE__ */ jsx11(Auth, {});
  return /* @__PURE__ */ jsxs11(Fragment9, { children: [
    /* @__PURE__ */ jsx11("div", { className: "toolbar", children: [["properties", "\u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A"], ["designs", "\u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645"], ["engineers", "\u0627\u0644\u0645\u0647\u0646\u062F\u0633\u0648\u0646"], ["login", "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644"]].map(([p, l]) => /* @__PURE__ */ jsx11("button", { onClick: () => go(p), children: l }, p)) }),
    content
  ] });
}
function Workspace({ uid, route, go, dark, setDark }) {
  const q = useLoad(async () => ({ profile: check(await db().from("profiles").select("*").eq("id", uid).single()), roles: check(await db().from("user_roles").select("role").eq("user_id", uid)).map((r) => r.role) }), [uid]);
  const [mode, setMode] = useState12(localStorage.getItem("ardna-mode") || "customer"), [matching, setMatching] = useState12({});
  const roles = q.data?.roles || [], engineer = roles.includes("engineer") && (mode === "engineer" || !roles.includes("customer"));
  const path = route.split("?")[0], parts = path.split("/"), page = parts[0], id = parts[1];
  function switchMode(next) {
    setMode(next);
    localStorage.setItem("ardna-mode", next);
    go("home");
  }
  const engineerQ = useLoad(async () => page === "engineer-settings" ? check(await db().from("engineer_profiles").select("*").eq("user_id", uid).maybeSingle()) : null, [page, uid]);
  let content = null;
  if (page === "home") content = /* @__PURE__ */ jsx11(Dashboard, { uid, engineer, name: q.data?.profile.full_name || "", go });
  else if (["properties", "map", "mine-property"].includes(page)) content = /* @__PURE__ */ jsx11(Catalog, { kind: "property", uid, go, map: page === "map", mine: page === "mine-property" }, page + "-property");
  else if (["designs", "mine-design", "matching"].includes(page)) content = /* @__PURE__ */ jsx11(Catalog, { kind: "design", uid, go, mine: page === "mine-design", initial: page === "matching" ? matching : {} }, page);
  else if (page === "favorites") content = /* @__PURE__ */ jsxs11(Fragment9, { children: [
    /* @__PURE__ */ jsx11(Catalog, { kind: "property", uid, go, favorites: true }, page + "-property"),
    /* @__PURE__ */ jsx11(Catalog, { kind: "design", uid, go, favorites: true })
  ] });
  else if (["property", "design"].includes(page) && id) content = /* @__PURE__ */ jsx11(Details, { kind: page, id, uid, go, match: (v) => {
    setMatching(v);
    go("matching");
  } }, route);
  else if (page === "edit-property" || page === "edit-design") content = page === "edit-design" && !roles.includes("engineer") ? /* @__PURE__ */ jsx11(Empty, { children: "\u0623\u0636\u0641 \u0645\u0644\u0641\u064B\u0627 \u0645\u0647\u0646\u064A\u064B\u0627 \u0623\u0648\u0644\u064B\u0627 \u0645\u0646 \u062D\u0633\u0627\u0628\u0643." }) : /* @__PURE__ */ jsx11(Editor, { kind: page === "edit-property" ? "property" : "design", id, uid, go }, route);
  else if (page === "engineers") content = /* @__PURE__ */ jsx11(Engineers, { go });
  else if (page === "engineer" && id) content = /* @__PURE__ */ jsx11(EngineerProfile, { id, uid, go });
  else if (page === "custom" && id) content = /* @__PURE__ */ jsx11(CustomRequest, { engineer: id, uid, go });
  else if (page === "requests") content = /* @__PURE__ */ jsx11(Requests, { uid, go });
  else if (page === "chat") content = /* @__PURE__ */ jsx11(Chat, { thread: id, uid, go });
  else if (page === "documents") content = /* @__PURE__ */ jsx11(Documents, { uid });
  else if (page === "notifications") content = /* @__PURE__ */ jsx11(Notifications, { uid, go });
  else if (page === "services") content = /* @__PURE__ */ jsx11(Services, { uid });
  else if (page === "admin") content = roles.includes("admin") ? /* @__PURE__ */ jsx11(Admin, { go }) : /* @__PURE__ */ jsx11(Empty, { children: "\u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629 \u0644\u0644\u0625\u062F\u0627\u0631\u0629 \u0641\u0642\u0637." });
  else if (page === "engineer-settings") content = /* @__PURE__ */ jsx11(LoadState, { query: engineerQ, children: /* @__PURE__ */ jsx11(EngineerSetup, { initial: engineerQ.data || void 0, done: () => {
    q.reload();
    go("account");
  } }) });
  else if (page === "settings") content = /* @__PURE__ */ jsxs11(Fragment9, { children: [
    /* @__PURE__ */ jsx11("h1", { children: "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A" }),
    /* @__PURE__ */ jsxs11("section", { className: "settings-row", children: [
      /* @__PURE__ */ jsx11("label", { htmlFor: "night-mode", children: "\u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u0644\u064A\u0644\u064A" }),
      /* @__PURE__ */ jsx11("input", { id: "night-mode", type: "checkbox", role: "switch", checked: dark, onChange: (e) => setDark(e.target.checked) })
    ] }),
    /* @__PURE__ */ jsx11("p", { children: "\u0627\u0644\u0625\u0635\u062F\u0627\u0631 3.0.1 \u2022 UX" })
  ] });
  else if (page === "account") content = /* @__PURE__ */ jsxs11(Fragment9, { children: [
    /* @__PURE__ */ jsx11("h1", { children: "\u062D\u0633\u0627\u0628\u064A" }),
    /* @__PURE__ */ jsx11(DataForm, { initial: q.data?.profile, fields: [{ name: "full_name", label: "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644", required: true }, { name: "phone", label: "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641", type: "tel" }, { name: "city", label: "\u0627\u0644\u0645\u062F\u064A\u0646\u0629" }, { name: "country", label: "\u0627\u0644\u062F\u0648\u0644\u0629" }], submit: async (v) => {
      check(await db().from("profiles").update({ full_name: v.full_name, phone: v.phone, city: v.city, country: v.country }).eq("id", uid));
      q.reload();
    } }, q.data?.profile.updated_at),
    /* @__PURE__ */ jsxs11("div", { className: "service-list", children: [
      roles.includes("engineer") ? /* @__PURE__ */ jsxs11(Fragment9, { children: [
        /* @__PURE__ */ jsx11("button", { className: "outline", onClick: () => switchMode("engineer"), children: "\u0648\u0636\u0639 \u0627\u0644\u0645\u0647\u0646\u062F\u0633" }),
        roles.includes("customer") ? /* @__PURE__ */ jsx11("button", { className: "outline", onClick: () => switchMode("customer"), children: "\u0648\u0636\u0639 \u0627\u0644\u0639\u0645\u064A\u0644" }) : /* @__PURE__ */ jsx11(Action, { run: async () => {
          await rpc("choose_role", { chosen: "customer" });
          q.reload();
          switchMode("customer");
        }, children: "\u0625\u0636\u0627\u0641\u0629 \u0648\u0636\u0639 \u0627\u0644\u0639\u0645\u064A\u0644" })
      ] }) : /* @__PURE__ */ jsx11("button", { className: "outline", onClick: () => go("engineer-settings"), children: "\u0625\u0636\u0627\u0641\u0629 \u062D\u0633\u0627\u0628 \u0645\u0647\u0646\u062F\u0633" }),
      [["settings", "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A"], ["documents", "\u0648\u062B\u0627\u0626\u0642\u064A"], ["services", "\u0627\u0644\u062F\u0639\u0645 \u0648\u0627\u0644\u062E\u062F\u0645\u0627\u062A"], ["mine-property", "\u0639\u0642\u0627\u0631\u0627\u062A\u064A"], ["favorites", "\u0627\u0644\u0645\u0641\u0636\u0644\u0629"], ["requests", "\u0637\u0644\u0628\u0627\u062A\u064A"]].map(([p, l]) => /* @__PURE__ */ jsx11("button", { className: "outline", onClick: () => go(p), children: l }, p)),
      roles.includes("admin") && /* @__PURE__ */ jsx11("button", { className: "outline", onClick: () => go("admin"), children: "\u0644\u0648\u062D\u0629 \u0627\u0644\u0625\u062F\u0627\u0631\u0629" }),
      /* @__PURE__ */ jsx11(Action, { run: async () => {
        check(await db().auth.signOut());
        go("home");
      }, children: "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C" })
    ] })
  ] });
  else content = /* @__PURE__ */ jsx11(Empty, { children: "\u0627\u0644\u0635\u0641\u062D\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629. \u0627\u0633\u062A\u062E\u062F\u0645 \u0632\u0631 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629." });
  return /* @__PURE__ */ jsx11(LoadState, { query: q, children: !roles.length ? /* @__PURE__ */ jsx11(Onboarding, { done: q.reload }) : /* @__PURE__ */ jsxs11(Fragment9, { children: [
    /* @__PURE__ */ jsx11("div", { className: "page-transition", children: content }, route),
    !["edit-property", "edit-design", "engineer-settings", "custom"].includes(page) && /* @__PURE__ */ jsx11("nav", { "aria-label": "\u0627\u0644\u062A\u0646\u0642\u0644 \u0627\u0644\u0631\u0626\u064A\u0633\u064A", children: [[Home, "home", "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629"], [Search, "properties", "\u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A"], [Building22, "designs", "\u0627\u0644\u062A\u0635\u0627\u0645\u064A\u0645"], [MessageCircle, "chat", "\u0627\u0644\u0631\u0633\u0627\u0626\u0644"], [UserRound, "account", "\u062D\u0633\u0627\u0628\u064A"]].map(([Icon, p, l]) => {
      const I = Icon;
      return /* @__PURE__ */ jsxs11("button", { "aria-current": page === p || p === "properties" && ["property", "map", "mine-property"].includes(page) || p === "designs" && ["design", "matching", "mine-design"].includes(page) || p === "account" && ["settings", "documents", "services", "engineer-settings"].includes(page) ? "page" : void 0, className: page === p || p === "properties" && ["property", "map", "mine-property"].includes(page) || p === "designs" && ["design", "matching", "mine-design"].includes(page) || p === "account" && ["settings", "documents", "services", "engineer-settings"].includes(page) ? "active" : "", onClick: () => go(String(p)), children: [
        /* @__PURE__ */ jsx11(I, {}),
        /* @__PURE__ */ jsx11("span", { children: String(l) })
      ] }, String(p));
    }) })
  ] }) });
}
export {
  Action,
  App2 as App,
  Brand,
  DataForm,
  Empty,
  Fields,
  Gallery,
  LoadState,
  Media,
  Skeleton,
  ToastHost,
  canLeave,
  clearViews,
  friendlyError,
  labels,
  reset,
  state,
  text,
  toast,
  useLoad,
  useNavigation,
  useUnsaved,
  useViewState,
  useViewport
};
